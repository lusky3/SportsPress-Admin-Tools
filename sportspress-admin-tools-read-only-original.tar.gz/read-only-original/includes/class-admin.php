<?php
/**
 * Admin functionality
 * 
 * @author Cody (lusky3)
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    wp_die();
}

class SPAT_Admin {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'init_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }
    
    public function add_admin_menu() {
        add_options_page(
            __('SportsPress Admin Tools', 'sportspress-admin-tools'),
            __('SportsPress Admin Tools', 'sportspress-admin-tools'),
            'manage_options',
            'sportspress-admin-tools',
            array($this, 'settings_page')
        );
        
        // Add shortcut under SportsPress menu if it exists
        if (class_exists('SportsPress')) {
            add_submenu_page(
                'sportspress',
                __('Admin Tools', 'sportspress-admin-tools'),
                __('Admin Tools', 'sportspress-admin-tools'),
                'manage_options',
                'sportspress-admin-tools-shortcut',
                array($this, 'redirect_to_settings')
            );
        }
    }
    
    public function redirect_to_settings() {
        wp_safe_redirect(admin_url('options-general.php?page=sportspress-admin-tools'));
        wp_die();
    }
    
    private function check_permissions() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'sportspress-admin-tools'));
        }
    }
    
    public function enqueue_admin_scripts($hook) {
        // Only load on our specific settings page
        if ($hook !== 'settings_page_sportspress-admin-tools') {
            return;
        }
        
        // Double check we're on the right page
        if (!isset($_GET['page']) || $_GET['page'] !== 'sportspress-admin-tools') {
            return;
        }
        
        wp_enqueue_script('jquery');
        
        // Enqueue Select2 if enabled
        if (get_option('spat_use_select2', '0')) {
            wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array('jquery'), '4.1.0', true);
            wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', array(), '4.1.0');
        }
        
        wp_add_inline_script('jquery', '
            jQuery(document).ready(function($) {
                var hasUnsavedChanges = false;
                var initialFormData = {};
                
                // Store initial form data for each tab
                function storeInitialData() {
                    $(".tab-content form").each(function() {
                        var tabId = $(this).closest(".tab-content").attr("id");
                        initialFormData[tabId] = $(this).serialize();
                    });
                }
                
                // Check if current tab has unsaved changes
                function hasChangesInCurrentTab() {
                    var currentTab = $(".nav-tab-active").attr("href").substring(1);
                    var currentForm = $("#" + currentTab + " form");
                    if (currentForm.length) {
                        return initialFormData[currentTab] !== currentForm.serialize();
                    }
                    return false;
                }
                
                // Track form changes
                $(document).on("input change", ".tab-content form input, .tab-content form select, .tab-content form textarea", function() {
                    hasUnsavedChanges = hasChangesInCurrentTab();
                });
                
                $(".nav-tab").click(function(e) {
                    e.preventDefault();
                    
                    // Check for unsaved changes before switching
                    if (hasUnsavedChanges && hasChangesInCurrentTab()) {
                        if (!confirm("You have unsaved changes that will be lost. Do you want to continue?")) {
                            return;
                        }
                    }
                    
                    $(".nav-tab").removeClass("nav-tab-active");
                    $(".tab-content").hide();
                    $(this).addClass("nav-tab-active");
                    $($(this).attr("href")).show();
                    
                    // Store current tab and reset change tracking
                    var tabId = $(this).attr("href").substring(1);
                    $("input[name=current_tab]").val(tabId);
                    hasUnsavedChanges = false;
                });
                
                // Reset change tracking after form submission
                $(".tab-content form").on("submit", function() {
                    hasUnsavedChanges = false;
                });
                
                // Warn on page unload if there are unsaved changes
                $(window).on("beforeunload", function() {
                    if (hasUnsavedChanges && hasChangesInCurrentTab()) {
                        return "You have unsaved changes that will be lost.";
                    }
                });
                
                // Initialize
                storeInitialData();
                
                // Check for active tab from URL param, hash, or default
                var urlParams = new URLSearchParams(window.location.search);
                var activeTab = urlParams.get("tab") || window.location.hash.substring(1) || "general";
                
                if ($("a[href=\"#" + activeTab + "\"]").length) {
                    $("a[href=\"#" + activeTab + "\"]").click();
                } else {
                    $(".nav-tab:first").click();
                }
            });
        ');
    }
    
    public function init_settings() {
        // General settings
        register_setting('spat_general_settings', 'spat_enabled_modules');
        register_setting('spat_general_settings', 'spat_remove_data_on_uninstall');
        register_setting('spat_general_settings', 'spat_use_select2');
        register_setting('spat_general_settings', 'spat_debug_show_sensitive');
        register_setting('spat_general_settings', 'spat_debug_verbose_logging');
        
        // e-Transfer settings
        register_setting('spat_etransfer_settings', 'spat_etransfer_webhook_secret');
        register_setting('spat_etransfer_settings', 'spat_etransfer_service_provider');
        register_setting('spat_etransfer_settings', 'spat_etransfer_custom_secret');
        
        // Player Registration settings
        register_setting('spat_player_registration_settings', 'spat_player_registration_auto_role');
        register_setting('spat_player_registration_settings', 'spat_player_registration_auto_create');
        
        // Player Stats Enabler settings
        register_setting('spat_player_stats_settings', 'spat_player_stats_auto_enable');
        
        // Player Modifications settings
        register_setting('spat_player_modifications_settings', 'spat_player_modifications_email_meta');
        register_setting('spat_player_modifications_settings', 'spat_player_modifications_squad_number_edit');
        register_setting('spat_player_modifications_settings', 'spat_player_modifications_captain_role');
        register_setting('spat_player_modifications_settings', 'spat_player_modifications_roster_upload');
        
        // Events Management settings
        register_setting('spat_events_settings', 'spat_events_auto_calendar_creation');
        register_setting('spat_events_settings', 'spat_events_calendar_type');
        register_setting('spat_events_settings', 'spat_events_naming_prefix');
        register_setting('spat_events_settings', 'spat_events_naming_suffix');
        register_setting('spat_events_settings', 'spat_events_naming_separator');
        register_setting('spat_events_settings', 'spat_events_include_team_name');
        register_setting('spat_events_settings', 'spat_events_include_division');
        
        add_settings_section(
            'spat_modules_section',
            __('Modules', 'sportspress-admin-tools'),
            array($this, 'modules_section_callback'),
            'spat_general_settings'
        );
        
        add_settings_section(
            'spat_settings_section',
            __('Settings', 'sportspress-admin-tools'),
            array($this, 'settings_section_callback'),
            'spat_general_settings'
        );
        
        add_settings_section(
            'spat_debug_section',
            __('Debug', 'sportspress-admin-tools'),
            array($this, 'debug_section_callback'),
            'spat_general_settings'
        );
        
        add_settings_field(
            'etransfer_automation',
            __('e-Transfer Automation', 'sportspress-admin-tools'),
            array($this, 'module_checkbox_callback'),
            'spat_general_settings',
            'spat_modules_section',
            array('module' => 'etransfer_automation')
        );
        
        add_settings_field(
            'player_registration',
            sprintf(__('%s Registration', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')),
            array($this, 'module_checkbox_callback'),
            'spat_general_settings',
            'spat_modules_section',
            array('module' => 'player_registration')
        );
        
        add_settings_field(
            'league_table_generator',
            sprintf(__('%s Table Generator', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('League')),
            array($this, 'module_checkbox_callback'),
            'spat_general_settings',
            'spat_modules_section',
            array('module' => 'league_table_generator')
        );
        
        add_settings_field(
            'player_stats_enabler',
            sprintf(__('%s Stats Enabler', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')),
            array($this, 'module_checkbox_callback'),
            'spat_general_settings',
            'spat_modules_section',
            array('module' => 'player_stats_enabler')
        );
        
        add_settings_field(
            'player_modifications',
            sprintf(__('%s Modifications', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')),
            array($this, 'module_checkbox_callback'),
            'spat_general_settings',
            'spat_modules_section',
            array('module' => 'player_modifications')
        );
        
        add_settings_field(
            'events_management',
            __('Events Management', 'sportspress-admin-tools'),
            array($this, 'module_checkbox_callback'),
            'spat_general_settings',
            'spat_modules_section',
            array('module' => 'events_management')
        );
        
        add_settings_field(
            'spat_remove_data_on_uninstall',
            __('Remove Data on Uninstall', 'sportspress-admin-tools'),
            array($this, 'remove_data_setting_callback'),
            'spat_general_settings',
            'spat_settings_section'
        );
        
        add_settings_field(
            'spat_use_select2',
            __('Enhanced Dropdowns (Select2)', 'sportspress-admin-tools'),
            array($this, 'select2_setting_callback'),
            'spat_general_settings',
            'spat_settings_section'
        );
        
        add_settings_field(
            'spat_debug_show_sensitive',
            __('Show Sensitive Information in Debug Logs', 'sportspress-admin-tools'),
            array($this, 'debug_sensitive_callback'),
            'spat_general_settings',
            'spat_debug_section'
        );
        
        add_settings_field(
            'spat_debug_verbose_logging',
            __('Verbose Debug Logging', 'sportspress-admin-tools'),
            array($this, 'debug_verbose_callback'),
            'spat_general_settings',
            'spat_debug_section'
        );
        
        // e-Transfer settings section
        add_settings_section(
            'spat_etransfer_section',
            __('Webhook Configuration', 'sportspress-admin-tools'),
            array($this, 'etransfer_section_callback'),
            'spat_etransfer_settings'
        );
        
        add_settings_field(
            'webhook_url',
            __('Webhook URL', 'sportspress-admin-tools'),
            array($this, 'webhook_url_callback'),
            'spat_etransfer_settings',
            'spat_etransfer_section'
        );
        
        add_settings_field(
            'service_provider',
            __('Service Provider', 'sportspress-admin-tools'),
            array($this, 'service_provider_callback'),
            'spat_etransfer_settings',
            'spat_etransfer_section'
        );
        
        add_settings_field(
            'webhook_secret',
            __('Webhook Secret', 'sportspress-admin-tools'),
            array($this, 'webhook_secret_callback'),
            'spat_etransfer_settings',
            'spat_etransfer_section'
        );
        
        // Player Registration settings
        add_settings_section(
            'spat_player_registration_section',
            sprintf(__('%s Registration Settings', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')),
            array($this, 'player_registration_section_callback'),
            'spat_player_registration_settings'
        );
        
        add_settings_field(
            'auto_role_assignment',
            __('Automatic Role Assignment', 'sportspress-admin-tools'),
            array($this, 'auto_role_assignment_callback'),
            'spat_player_registration_settings',
            'spat_player_registration_section'
        );
        
        add_settings_field(
            'auto_player_creation',
            __('Automatic Player Creation', 'sportspress-admin-tools'),
            array($this, 'auto_player_creation_callback'),
            'spat_player_registration_settings',
            'spat_player_registration_section'
        );
        
        // Player Stats Enabler settings
        add_settings_section(
            'spat_player_stats_section',
            sprintf(__('%s Stats Settings', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')),
            array($this, 'player_stats_section_callback'),
            'spat_player_stats_settings'
        );
        
        add_settings_field(
            'auto_stats_enable',
            __('Automatic Stats Enable', 'sportspress-admin-tools'),
            array($this, 'auto_stats_enable_callback'),
            'spat_player_stats_settings',
            'spat_player_stats_section'
        );
        
        // Player Modifications settings
        add_settings_section(
            'spat_player_modifications_section',
            sprintf(__('%s Modifications Settings', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')),
            array($this, 'player_modifications_section_callback'),
            'spat_player_modifications_settings'
        );
        
        add_settings_field(
            'email_meta_enable',
            __('Email Meta Box', 'sportspress-admin-tools'),
            array($this, 'email_meta_enable_callback'),
            'spat_player_modifications_settings',
            'spat_player_modifications_section'
        );
        
        add_settings_field(
            'squad_number_edit_enable',
            __('Front-end Squad Number Editing', 'sportspress-admin-tools'),
            array($this, 'squad_number_edit_enable_callback'),
            'spat_player_modifications_settings',
            'spat_player_modifications_section'
        );
        
        add_settings_field(
            'captain_role_enable',
            __('Captain Role Selection', 'sportspress-admin-tools'),
            array($this, 'captain_role_enable_callback'),
            'spat_player_modifications_settings',
            'spat_player_modifications_section'
        );
        
        add_settings_field(
            'roster_upload_enable',
            __('Roster Upload', 'sportspress-admin-tools'),
            array($this, 'roster_upload_enable_callback'),
            'spat_player_modifications_settings',
            'spat_player_modifications_section'
        );
        
        // Events Management settings
        add_settings_section(
            'spat_events_section',
            __('Events Management Settings', 'sportspress-admin-tools'),
            array($this, 'events_section_callback'),
            'spat_events_settings'
        );
        
        add_settings_field(
            'auto_calendar_creation',
            __('Auto-Create Calendars', 'sportspress-admin-tools'),
            array($this, 'auto_calendar_creation_callback'),
            'spat_events_settings',
            'spat_events_section'
        );
        
        add_settings_field(
            'calendar_type',
            __('Calendar Type', 'sportspress-admin-tools'),
            array($this, 'calendar_type_callback'),
            'spat_events_settings',
            'spat_events_section'
        );
        
        add_settings_field(
            'calendar_naming',
            __('Calendar Naming Scheme', 'sportspress-admin-tools'),
            array($this, 'calendar_naming_callback'),
            'spat_events_settings',
            'spat_events_section'
        );
    }
    
    public function modules_section_callback() {
        echo '<p>' . __('Enable or disable plugin modules:', 'sportspress-admin-tools') . '</p>';
    }
    
    public function settings_section_callback() {
        echo '<p>' . __('Configure global plugin settings:', 'sportspress-admin-tools') . '</p>';
    }
    
    public function etransfer_section_callback() {
        echo '<p>' . __('Configure webhook settings for e-Transfer automation. Choose your service provider and follow the setup instructions below.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function module_checkbox_callback($args) {
        $enabled_modules = get_option('spat_enabled_modules', array());
        $checked = in_array($args['module'], $enabled_modules) ? 'checked' : '';
        $disabled = '';
        
        // Check dependencies
        if ($args['module'] === 'etransfer_automation' && !class_exists('WooCommerce')) {
            $disabled = 'disabled';
            $checked = '';
        }
        
        if ($args['module'] === 'player_registration' && (!class_exists('WooCommerce') || !class_exists('SportsPress'))) {
            $disabled = 'disabled';
            $checked = '';
        }
        
        if ($args['module'] === 'league_table_generator' && !class_exists('SportsPress')) {
            $disabled = 'disabled';
            $checked = '';
        }
        
        if ($args['module'] === 'player_stats_enabler' && !class_exists('SportsPress')) {
            $disabled = 'disabled';
            $checked = '';
        }
        
        if ($args['module'] === 'player_modifications' && (!class_exists('SportsPress') || !class_exists('WooCommerce'))) {
            $disabled = 'disabled';
            $checked = '';
        }
        
        if ($args['module'] === 'events_management' && !class_exists('SportsPress')) {
            $disabled = 'disabled';
            $checked = '';
        }
        
        echo '<input type="checkbox" name="spat_enabled_modules[]" value="' . esc_attr($args['module']) . '" ' . $checked . ' ' . $disabled . '>';
        
        if ($args['module'] === 'etransfer_automation') {
            if (class_exists('WooCommerce')) {
                echo '<p class="description">' . __('Automatically process e-Transfer payments for WooCommerce orders.', 'sportspress-admin-tools') . '</p>';
            } else {
                echo '<p class="description" style="color: #d63638;">' . __('Requires WooCommerce to be installed and activated.', 'sportspress-admin-tools') . '</p>';
            }
        }
        
        if ($args['module'] === 'player_registration') {
            if (class_exists('WooCommerce') && class_exists('SportsPress')) {
                echo '<p class="description">' . sprintf(__('Automatically create %s records from WooCommerce registration orders.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
            } else {
                echo '<p class="description" style="color: #d63638;">' . __('Requires WooCommerce and SportsPress to be installed and activated.', 'sportspress-admin-tools') . '</p>';
            }
        }
        
        if ($args['module'] === 'league_table_generator') {
            if (class_exists('SportsPress')) {
                echo '<p class="description">' . sprintf(__('Generate %s tables for teams organized by divisions and seasons.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('League'))) . '</p>';
            } else {
                echo '<p class="description" style="color: #d63638;">' . __('Requires SportsPress to be installed and activated.', 'sportspress-admin-tools') . '</p>';
            }
        }
        
        if ($args['module'] === 'player_stats_enabler') {
            if (class_exists('SportsPress')) {
                echo '<p class="description">' . sprintf(__('Automatically enable frontend statistics display for %s records.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
            } else {
                echo '<p class="description" style="color: #d63638;">' . __('Requires SportsPress to be installed and activated.', 'sportspress-admin-tools') . '</p>';
            }
        }
        
        if ($args['module'] === 'player_modifications') {
            if (class_exists('SportsPress') && class_exists('WooCommerce')) {
                echo '<p class="description">' . sprintf(__('Add email metadata to %s and allow front-end squad number editing.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Players'))) . '</p>';
            } else {
                echo '<p class="description" style="color: #d63638;">' . __('Requires SportsPress and WooCommerce to be installed and activated.', 'sportspress-admin-tools') . '</p>';
            }
        }
        
        if ($args['module'] === 'events_management') {
            if (class_exists('SportsPress')) {
                echo '<p class="description">' . __('Reset calendars to current season, auto-create calendars for new teams, and import events from XLSX files.', 'sportspress-admin-tools') . '</p>';
            } else {
                echo '<p class="description" style="color: #d63638;">' . __('Requires SportsPress to be installed and activated.', 'sportspress-admin-tools') . '</p>';
            }
        }
    }
    
    public function webhook_url_callback() {
        $webhook_url = rest_url('spat/v1/etransfer-webhook');
        echo '<input type="text" value="' . esc_attr($webhook_url) . '" readonly class="regular-text" />';
        echo '<button type="button" class="button" onclick="navigator.clipboard.writeText(this.previousElementSibling.value)">' . __('Copy', 'sportspress-admin-tools') . '</button>';
        echo '<p class="description">' . __('Use this URL in your chosen service provider configuration.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function service_provider_callback() {
        $provider = get_option('spat_etransfer_service_provider', 'generic');
        echo '<label><input type="radio" name="spat_etransfer_service_provider" value="generic" ' . checked($provider, 'generic', false) . '> ' . __('Generic (Bring Your Own Service)', 'sportspress-admin-tools') . '</label><br>';
        echo '<label><input type="radio" name="spat_etransfer_service_provider" value="deliverhook" ' . checked($provider, 'deliverhook', false) . '> ' . __('deliverhook.com', 'sportspress-admin-tools') . '</label><br>';
        echo '<label><input type="radio" name="spat_etransfer_service_provider" value="cloudflare" ' . checked($provider, 'cloudflare', false) . '> ' . __('Cloudflare Email Routing', 'sportspress-admin-tools') . '</label>';
        echo '<p class="description">' . __('Choose your email forwarding service provider.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function webhook_secret_callback() {
        $provider = get_option('spat_etransfer_service_provider', 'generic');
        $generated_secret = get_option('spat_etransfer_webhook_secret', '');
        $custom_secret = get_option('spat_etransfer_custom_secret', '');
        
        if (empty($generated_secret)) {
            $generated_secret = wp_generate_password(32, false);
            update_option('spat_etransfer_webhook_secret', $generated_secret);
        }
        
        echo '<div id="generic-secret" style="display:' . ($provider === 'generic' ? 'block' : 'none') . ';">';
        echo '<input type="text" name="spat_etransfer_webhook_secret" value="' . esc_attr($generated_secret) . '" class="regular-text" readonly />';
        echo '<button type="button" class="button" onclick="this.previousElementSibling.value=\'' . wp_generate_password(32, false) . '\'; this.previousElementSibling.name=\'spat_etransfer_webhook_secret\';">' . __('Generate New', 'sportspress-admin-tools') . '</button>';
        echo '<button type="button" class="button" onclick="navigator.clipboard.writeText(this.previousElementSibling.previousElementSibling.value)">' . __('Copy', 'sportspress-admin-tools') . '</button>';
        echo '</div>';
        
        echo '<div id="deliverhook-secret" style="display:' . ($provider === 'deliverhook' ? 'block' : 'none') . ';">';
        echo '<input type="text" name="spat_etransfer_custom_secret" value="' . esc_attr($custom_secret) . '" class="regular-text" placeholder="' . __('Enter secret from deliverhook Security tab', 'sportspress-admin-tools') . '" />';
        echo '<button type="button" class="button" onclick="navigator.clipboard.writeText(this.previousElementSibling.value)">' . __('Copy', 'sportspress-admin-tools') . '</button>';
        echo '</div>';
        
        echo '<div id="cloudflare-secret" style="display:' . ($provider === 'cloudflare' ? 'block' : 'none') . ';">';
        echo '<input type="text" name="spat_etransfer_webhook_secret" value="' . esc_attr($generated_secret) . '" class="regular-text" readonly />';
        echo '<button type="button" class="button" onclick="this.previousElementSibling.value=\'' . wp_generate_password(32, false) . '\'; this.previousElementSibling.name=\'spat_etransfer_webhook_secret\';">' . __('Generate New', 'sportspress-admin-tools') . '</button>';
        echo '<button type="button" class="button" onclick="navigator.clipboard.writeText(this.previousElementSibling.previousElementSibling.value)">' . __('Copy', 'sportspress-admin-tools') . '</button>';
        echo '</div>';
        
        echo '<p class="description">' . __('HMAC SHA256 signing secret for webhook security.', 'sportspress-admin-tools') . '</p>';
        
        echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            const radios = document.querySelectorAll("input[name=spat_etransfer_service_provider]");
            radios.forEach(function(radio) {
                radio.addEventListener("change", function() {
                    document.getElementById("generic-secret").style.display = this.value === "generic" ? "block" : "none";
                    document.getElementById("deliverhook-secret").style.display = this.value === "deliverhook" ? "block" : "none";
                    document.getElementById("cloudflare-secret").style.display = this.value === "cloudflare" ? "block" : "none";
                    document.getElementById("setup-instructions").innerHTML = getSetupInstructions(this.value);
                });
            });
            
            // Initialize setup instructions
            const selectedProvider = document.querySelector("input[name=spat_etransfer_service_provider]:checked").value;
            document.getElementById("setup-instructions").innerHTML = getSetupInstructions(selectedProvider);
        });
        
        function getSetupInstructions(provider) {
            const webhookUrl = "' . esc_js(rest_url('spat/v1/etransfer-webhook')) . '";
            const downloadNonce = "' . wp_create_nonce('spat_file_download') . '";
            
            switch(provider) {
                case "generic":
                    return `<h3>Generic Setup Instructions</h3>
                    <p>Configure your email forwarding service to:</p>
                    <ol>
                        <li>Forward emails from <code>notify@payments.interac.ca</code> to the webhook URL above</li>
                        <li>Send POST requests with <code>Content-Type: application/json</code></li>
                        <li>Include JSON payload with this structure:</li>
                    </ol>
                    <pre style="background: #f0f0f0; padding: 10px; border-radius: 4px; overflow-x: auto;">{
  "from": {
    "address": "notify@payments.interac.ca",
    "name": "Interac e-Transfer"
  },
  "subject": "Email subject line",
  "date": "RFC 2822 formatted date",
  "text": "Full email body content"
}</pre>
                    <ol start="4">
                        <li>Include <code>X-Signature</code> header with HMAC SHA256 signature</li>
                        <li>Calculate signature using the secret above and the JSON payload</li>
                        <li>Test with a sample e-Transfer email to verify parsing</li>
                    </ol>
                    <p><strong>Note:</strong> The plugin extracts payment details from the email body text using regex patterns.</p>`;
                    
                case "deliverhook":
                    return `<h3>deliverhook.com Setup Instructions</h3>
                    <p>Follow these steps to configure deliverhook:</p>
                    <ol>
                        <li>Sign up at <a href="https://deliverhook.com" target="_blank">deliverhook.com</a></li>
                        <li>Go to <strong>Email Forwarding</strong> section</li>
                        <li>Add a new forwarding rule:
                            <ul>
                                <li><strong>From:</strong> <code>notify@payments.interac.ca</code></li>
                                <li><strong>To:</strong> <code>${webhookUrl}</code></li>
                                <li><strong>Method:</strong> POST</li>
                                <li><strong>Content-Type:</strong> application/json</li>
                            </ul>
                        </li>
                        <li>Go to <strong>Security</strong> tab</li>
                        <li>Enable <strong>HMAC SHA256 signature</strong></li>
                        <li>Copy the generated webhook secret and paste it in the field above</li>
                        <li>Save your configuration</li>
                    </ol>
                    <p><strong>Important:</strong> deliverhook automatically formats emails as JSON and includes the required signature headers.</p>
                    <p>For detailed instructions, visit: <a href="https://deliverhook.com/docs" target="_blank">deliverhook.com/docs</a></p>`;
                    
                case "cloudflare":
                    return `<h3>Cloudflare Email Routing Setup Instructions</h3>
                    <p>Set up Cloudflare Email Routing with a custom Worker:</p>
                    <div style="margin: 15px 0;">
                        <a href="?spat_download=1&file=cloudflare-worker.js&_wpnonce=" + downloadNonce + "" class="button">Download Worker Code</a>
                        <a href="?spat_download=1&file=wrangler.toml&_wpnonce=" + downloadNonce + "" class="button">Download Wrangler Config</a>
                        <a href="?spat_download=1&file=README-cloudflare.md&_wpnonce=" + downloadNonce + "" class="button">Download Setup Guide</a>
                    </div>
                    <ol>
                        <li>Enable Email Routing in your Cloudflare dashboard</li>
                        <li>Add your domain and verify DNS records</li>
                        <li>Install Wrangler CLI: <code>npm install -g wrangler</code></li>
                        <li>Download the files above and deploy the Worker</li>
                        <li>Set Worker environment variables:
                            <ul>
                                <li><code>WEBHOOK_URL</code>: <code>${webhookUrl}</code></li>
                                <li><code>WEBHOOK_SECRET</code>: Use the secret generated above</li>
                                <li><code>FORWARD_EMAIL</code>: Your admin email (optional)</li>
                                <li><code>CUSTOM_HEADERS</code>: JSON object for additional headers (optional)</li>
                            </ul>
                        </li>
                        <li>Configure Email Routing to forward emails to the Worker</li>
                    </ol>
                    <p><strong>For detailed instructions, download the Setup Guide above.</strong></p>`;
                    
                default:
                    return "";
            }
        }
        </script>';
    }
    
    public function display_webhook_logs() {
        $logs = SPAT_Database::get_etransfer_logs();
        
        if (empty($logs)) {
            echo '<p>' . __('No webhook activity recorded yet.', 'sportspress-admin-tools') . '</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr>';
        echo '<th>' . __('Timestamp', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('From', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Amount', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Reference', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Match Criteria', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Order', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Result', 'sportspress-admin-tools') . '</th>';
        echo '</tr></thead><tbody>';
        
        foreach ($logs as $log) {
            $status_class = strpos($log->result, 'successfully') !== false ? 'success' : 'error';
            echo '<tr>';
            echo '<td>' . esc_html($log->timestamp) . '</td>';
            echo '<td>' . esc_html($log->from_name) . '<br><small>' . esc_html($log->from_email) . '</small></td>';
            echo '<td>$' . number_format($log->amount, 2) . '</td>';
            echo '<td>' . esc_html($log->reference_number ?: 'N/A') . '</td>';
            echo '<td>' . esc_html($log->match_criteria ?: 'N/A') . '</td>';
            echo '<td>' . ($log->order_id ? '<a href="' . admin_url('post.php?post=' . $log->order_id . '&action=edit') . '">#' . $log->order_id . '</a>' : 'N/A') . '</td>';
            echo '<td><span class="' . $status_class . '">' . esc_html($log->result) . '</span></td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
        echo '<style>.success{color:#00a32a}.error{color:#d63638}</style>';
    }
    
    public function player_registration_section_callback() {
        echo '<p>' . sprintf(__('Configure %s registration automation settings:', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
    }
    
    public function auto_role_assignment_callback() {
        $enabled = get_option('spat_player_registration_auto_role', '1');
        echo '<input type="checkbox" name="spat_player_registration_auto_role" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . sprintf(__('Automatically assign "%s" role to customers who complete registration orders.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
    }
    
    public function auto_player_creation_callback() {
        $enabled = get_option('spat_player_registration_auto_create', '1');
        echo '<input type="checkbox" name="spat_player_registration_auto_create" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . sprintf(__('Automatically create new %s records when no existing %s is found for a customer.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player')), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
    }
    
    public function player_stats_section_callback() {
        echo '<p>' . sprintf(__('Configure automatic %s statistics display settings:', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
    }
    
    public function auto_stats_enable_callback() {
        $enabled = get_option('spat_player_stats_auto_enable', '1');
        echo '<input type="checkbox" name="spat_player_stats_auto_enable" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . sprintf(__('Automatically enable frontend statistics display when %s records are saved.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
    }
    
    public function player_modifications_section_callback() {
        echo '<p>' . sprintf(__('Configure %s modification features:', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
    }
    
    public function email_meta_enable_callback() {
        $enabled = get_option('spat_player_modifications_email_meta', '1');
        echo '<input type="checkbox" name="spat_player_modifications_email_meta" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . sprintf(__('Add email meta box to %s edit pages (admin only).', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
    }
    
    public function squad_number_edit_enable_callback() {
        $enabled = get_option('spat_player_modifications_squad_number_edit', '1');
        echo '<input type="checkbox" name="spat_player_modifications_squad_number_edit" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . __('Allow front-end squad number editing on WooCommerce account dashboard.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function captain_role_enable_callback() {
        $enabled = get_option('spat_player_modifications_captain_role', '1');
        echo '<input type="checkbox" name="spat_player_modifications_captain_role" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . __('Add captain selection to player lists with "C" display on frontend.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function roster_upload_enable_callback() {
        $enabled = get_option('spat_player_modifications_roster_upload', '1');
        echo '<input type="checkbox" name="spat_player_modifications_roster_upload" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . __('Add roster upload functionality to player lists for bulk CSV/XLSX imports.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function events_section_callback() {
        echo '<p>' . __('Configure automatic calendar creation and naming settings:', 'sportspress-admin-tools') . '</p>';
    }
    
    public function auto_calendar_creation_callback() {
        $enabled = get_option('spat_events_auto_calendar_creation', '1');
        echo '<input type="checkbox" name="spat_events_auto_calendar_creation" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . __('Automatically create calendars when new teams are added.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function calendar_type_callback() {
        $type = get_option('spat_events_calendar_type', 'list');
        $types = array(
            'calendar' => __('Calendar', 'sportspress-admin-tools'),
            'list' => __('List', 'sportspress-admin-tools'),
            'blocks' => __('Blocks', 'sportspress-admin-tools'),
            'matrix' => __('Matrix', 'sportspress-admin-tools'),
            'scoreboard' => __('Scoreboard', 'sportspress-admin-tools')
        );
        
        echo '<select name="spat_events_calendar_type">';
        foreach ($types as $value => $label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected($type, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . __('Select the display format for auto-created calendars.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function calendar_naming_callback() {
        $include_team = get_option('spat_events_include_team_name', '1');
        $include_division = get_option('spat_events_include_division', '0');
        $prefix = get_option('spat_events_naming_prefix', '');
        $suffix = get_option('spat_events_naming_suffix', 'ARL');
        $separator = get_option('spat_events_naming_separator', ' | ');
        
        echo '<table class="form-table"><tbody>';
        
        echo '<tr><th scope="row">' . sprintf(__('Include %s Name', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Team')) . '</th><td>';
        echo '<input type="checkbox" name="spat_events_include_team_name" value="1" ' . checked($include_team, '1', false) . '>';
        echo '</td></tr>';
        
        echo '<tr><th scope="row">' . __('Include Division', 'sportspress-admin-tools') . '</th><td>';
        echo '<input type="checkbox" name="spat_events_include_division" value="1" ' . checked($include_division, '1', false) . '>';
        echo '</td></tr>';
        
        echo '<tr><th scope="row">' . __('Prefix', 'sportspress-admin-tools') . '</th><td>';
        echo '<input type="text" name="spat_events_naming_prefix" value="' . esc_attr($prefix) . '" class="regular-text" placeholder="' . __('Optional prefix', 'sportspress-admin-tools') . '">';
        echo '</td></tr>';
        
        echo '<tr><th scope="row">' . __('Suffix', 'sportspress-admin-tools') . '</th><td>';
        echo '<input type="text" name="spat_events_naming_suffix" value="' . esc_attr($suffix) . '" class="regular-text" placeholder="' . __('Optional suffix', 'sportspress-admin-tools') . '">';
        echo '</td></tr>';
        
        echo '<tr><th scope="row">' . __('Separator', 'sportspress-admin-tools') . '</th><td>';
        $separators = array(
            '' => __('None', 'sportspress-admin-tools'),
            '::' => '::',
            '●' => '●',
            '◉' => '◉',
            '★' => '★',
            '⋆' => '⋆',
            '⋅' => '⋅',
            '☆' => '☆',
            '|' => '|',
            ':' => ':'
        );
        echo '<select name="spat_events_naming_separator">';
        foreach ($separators as $value => $label) {
            $current_sep = trim($separator);
            $selected = ($current_sep === $value) ? 'selected' : '';
            echo '<option value="' . esc_attr($value) . '" ' . $selected . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . __('Character to separate name components. Spaces are added automatically.', 'sportspress-admin-tools') . '</p>';
        echo '</td></tr>';
        
        echo '</tbody></table>';
        
        echo '<p><strong>' . __('Preview:', 'sportspress-admin-tools') . '</strong> <span id="naming-preview"></span></p>';
        
        echo '<script>
        function updateNamingPreview() {
            var parts = [];
            var prefix = document.querySelector("input[name=spat_events_naming_prefix]").value;
            var suffix = document.querySelector("input[name=spat_events_naming_suffix]").value;
            var separatorSelect = document.querySelector("select[name=spat_events_naming_separator]");
            var separator = separatorSelect.value ? " " + separatorSelect.value + " " : " ";
            var includeTeam = document.querySelector("input[name=spat_events_include_team_name]").checked;
            var includeDivision = document.querySelector("input[name=spat_events_include_division]").checked;
            
            if (prefix) parts.push(prefix);
            if (includeTeam) parts.push("' . esc_js(SPAT_Text_Helper::get_text('Team')) . ' Name");
            if (includeDivision) parts.push("Division");
            if (suffix) parts.push(suffix);
            
            document.getElementById("naming-preview").textContent = parts.join(separator);
        }
        
        document.addEventListener("DOMContentLoaded", function() {
            updateNamingPreview();
            document.querySelectorAll("input[name^=spat_events_naming], input[name^=spat_events_include], select[name^=spat_events_naming]").forEach(function(input) {
                input.addEventListener("input", updateNamingPreview);
                input.addEventListener("change", updateNamingPreview);
            });
        });
        </script>';
    }
    
    public function remove_data_setting_callback() {
        $enabled = get_option('spat_remove_data_on_uninstall', '0');
        echo '<input type="checkbox" name="spat_remove_data_on_uninstall" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . __('Remove all plugin data (settings, logs, database tables) when the plugin is uninstalled. Leave unchecked to preserve data.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function select2_setting_callback() {
        $enabled = get_option('spat_use_select2', '0');
        echo '<input type="checkbox" name="spat_use_select2" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . __('Use enhanced Select2 dropdowns with search functionality throughout the plugin. Requires page refresh to take effect.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function debug_section_callback() {
        echo '<p>' . __('Configure debug logging options:', 'sportspress-admin-tools') . '</p>';
    }
    
    public function debug_sensitive_callback() {
        $enabled = get_option('spat_debug_show_sensitive', '0');
        echo '<input type="checkbox" name="spat_debug_show_sensitive" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . __('Include sensitive information like webhook secrets in debug logs. Disable for production.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function debug_verbose_callback() {
        $enabled = get_option('spat_debug_verbose_logging', '0');
        echo '<input type="checkbox" name="spat_debug_verbose_logging" value="1" ' . checked($enabled, '1', false) . '>';
        echo '<p class="description">' . __('Enable verbose debug logging with full headers and email content. Disable for cleaner logs.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function display_bulk_stats_tool() {
        if (!current_user_can('manage_options')) {
            echo '<div class="notice notice-error"><p>' . __('You need administrator permissions to use this tool.', 'sportspress-admin-tools') . '</p></div>';
            return;
        }
        
        $enabled_modules = get_option('spat_enabled_modules', array());
        
        if (!in_array('player_stats_enabler', $enabled_modules)) {
            return;
        }
        
        if (isset($_POST['bulk_enable_stats']) && wp_verify_nonce($_POST['_wpnonce'], 'bulk_enable_stats')) {
            if (!class_exists('SPAT_Player_Stats_Enabler')) {
                require_once plugin_dir_path(dirname(__FILE__)) . 'modules/class-player-stats-enabler.php';
            }
            $stats_enabler = new SPAT_Player_Stats_Enabler();
            $processed = $stats_enabler->bulk_enable_stats();
            
            echo '<div style="background: #d1edff; border-left: 4px solid #00a32a; padding: 12px; margin: 5px 0 15px;"><p><strong>' . sprintf(__('Successfully enabled stats for %d %s!', 'sportspress-admin-tools'), $processed, strtolower(SPAT_Text_Helper::get_text('Players'))) . '</strong></p></div>';
        }
        
        echo '<form method="post" action="' . admin_url('options-general.php?page=sportspress-admin-tools#player-stats') . '" onsubmit="return confirm(\'' . esc_js(__('This will modify the database to enable stats for all players without configured statistics. A backup is highly recommended before proceeding. Continue?', 'sportspress-admin-tools')) . '\')">';
        wp_nonce_field('bulk_enable_stats');
        echo '<p>' . sprintf(__('Enable frontend statistics display for all existing %s that don\'t have it configured yet.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Players'))) . '</p>';
        submit_button(sprintf(__('Bulk Enable %s Stats', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')), 'secondary', 'bulk_enable_stats');
        echo '</form>';
    }
    
    public function display_player_sync_tool() {
        if (!current_user_can('manage_options')) {
            echo '<div class="notice notice-error"><p>' . __('You need administrator permissions to use this tool.', 'sportspress-admin-tools') . '</p></div>';
            return;
        }
        
        $enabled_modules = get_option('spat_enabled_modules', array());
        
        if (!in_array('player_registration', $enabled_modules)) {
            echo '<div class="notice notice-warning"><p>' . __('Player Registration module must be enabled to use this tool.', 'sportspress-admin-tools') . '</p></div>';
            return;
        }
        
        if (isset($_POST['confirm_sync'])) {
            $player_registration = new SPAT_Player_Registration();
            $matches = $player_registration->sync_players_to_users();
            
            if (empty($matches)) {
                echo '<div class="notice notice-success"><p>' . __('All players have been synced successfully!', 'sportspress-admin-tools') . '</p></div>';
            } else {
                echo '<div class="notice notice-warning"><p>' . __('Multiple matches found. Please manually select:', 'sportspress-admin-tools') . '</p></div>';
                $this->display_manual_matches($matches);
            }
        } elseif (isset($_POST['preview_sync'])) {
            $this->display_sync_preview();
            return;
        }
        
        echo '<form method="post" action="' . admin_url('options-general.php?page=sportspress-admin-tools#player-registration') . '">';
        echo '<p>' . sprintf(__('Sync unlinked %s records with user accounts based on matching names.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Player'))) . '</p>';
        submit_button(__('Preview Sync Changes', 'sportspress-admin-tools'), 'secondary', 'preview_sync');
        echo '</form>';
    }
    
    private function display_manual_matches($matches) {
        foreach ($matches as $match) {
            echo '<div style="border:1px solid #ccc;padding:10px;margin:10px 0;">';
            echo '<h4>' . SPAT_Text_Helper::get_text('Player') . ': ' . esc_html($match['player']->post_title) . ' (ID: ' . $match['player']->ID . ')</h4>';
            echo '<p>Matching Users:</p><ul>';
            
            foreach ($match['users'] as $user) {
                echo '<li>' . esc_html($user->display_name) . ' (' . esc_html($user->user_email) . ') - ID: ' . $user->ID . '</li>';
            }
            
            echo '</ul></div>';
        }
    }
    
    private function display_sync_preview() {
        $enabled_modules = get_option('spat_enabled_modules', array());
        
        if (!in_array('player_registration', $enabled_modules)) {
            echo '<div class="notice notice-error"><p>' . __('Player Registration module must be enabled to use this feature.', 'sportspress-admin-tools') . '</p></div>';
            return;
        }
        
        // Use the existing sync method to get matches efficiently
        $player_registration = new SPAT_Player_Registration();
        $matches = $player_registration->get_sync_preview_data();
        
        $preview_data = $matches;
        
        echo '<h3>' . __('Sync Preview', 'sportspress-admin-tools') . '</h3>';
        
        if (empty($preview_data)) {
            echo '<p>' . sprintf(__('No unlinked %s found.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Players'))) . '</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped sync-preview-table">';
        echo '<thead><tr>';
        echo '<th>' . SPAT_Text_Helper::get_text('Player') . '</th>';
        echo '<th>' . __('User Account', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Action', 'sportspress-admin-tools') . '</th>';
        echo '</tr></thead><tbody>';
        
        foreach ($preview_data as $item) {
            echo '<tr>';
            echo '<td>' . $this->format_player_info($item['player']) . '</td>';
            
            if ($item['action'] === 'auto_link') {
                echo '<td>' . $this->format_user_info($item['user']) . '</td>';
                echo '<td><span class="sync-action auto-link">' . __('Will be linked automatically', 'sportspress-admin-tools') . '</span></td>';
            } elseif ($item['action'] === 'manual_select') {
                echo '<td>' . $this->format_multiple_users($item['users']) . '</td>';
                echo '<td><span class="sync-action manual-select">' . __('Requires manual selection', 'sportspress-admin-tools') . '</span></td>';
            } else {
                echo '<td>-</td>';
                echo '<td><span class="sync-action no-match">' . __('No matching user found', 'sportspress-admin-tools') . '</span></td>';
            }
            
            echo '</tr>';
        }
        
        echo '</tbody></table>';
        
        echo '<style>
        .sync-preview-table .player-info, .sync-preview-table .user-info { max-width: 300px; }
        .sync-preview-table .expandable { cursor: pointer; color: #0073aa; }
        .sync-preview-table .expanded { display: none; }
        .sync-action.auto-link { color: #00a32a; font-weight: bold; }
        .sync-action.manual-select { color: #dba617; font-weight: bold; }
        .sync-action.no-match { color: #d63638; font-weight: bold; }
        </style>';
        
        echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelectorAll(".expandable").forEach(function(el) {
                el.addEventListener("click", function() {
                    const expanded = this.nextElementSibling;
                    if (expanded.style.display === "none" || !expanded.style.display) {
                        expanded.style.display = "block";
                        this.textContent = this.textContent.replace("...", "");
                    } else {
                        expanded.style.display = "none";
                        this.textContent += "...";
                    }
                });
            });
        });
        </script>';
        
        echo '<form method="post" action="' . admin_url('options-general.php?page=sportspress-admin-tools#player-registration') . '" style="margin-top: 20px;">';
        submit_button(__('Confirm and Execute Sync', 'sportspress-admin-tools'), 'primary', 'confirm_sync');
        echo '<a href="' . admin_url('options-general.php?page=sportspress-admin-tools#player-registration') . '" class="button" style="margin-left: 10px;">' . __('Cancel', 'sportspress-admin-tools') . '</a>';
        echo '</form>';
    }
    
    private function format_player_info($player) {
        $info = '<div class="player-info">';
        $info .= '<strong>' . esc_html($player->post_title) . '</strong><br>';
        $info .= '<small>ID: <a href="' . admin_url('post.php?post=' . $player->ID . '&action=edit') . '" target="_blank">' . $player->ID . '</a></small>';
        $info .= '</div>';
        return $info;
    }
    
    private function format_user_info($user) {
        $info = '<div class="user-info">';
        $info .= '<strong>' . esc_html($user->display_name) . '</strong><br>';
        $info .= '<small>';
        $info .= 'Username: ' . esc_html($user->user_login) . '<br>';
        $info .= 'Email: ' . esc_html($user->user_email) . '<br>';
        $info .= 'Name: ' . esc_html($user->first_name . ' ' . $user->last_name);
        $info .= '</small>';
        $info .= '</div>';
        return $info;
    }
    
    private function format_multiple_users($users) {
        $info = '<div class="user-info">';
        $info .= '<strong>' . count($users) . ' matches found:</strong><br>';
        
        $user_list = array();
        foreach ($users as $user) {
            $user_list[] = $user->display_name . ' (' . $user->user_email . ')';
        }
        
        $users_text = implode(', ', $user_list);
        
        if (strlen($users_text) > 80) {
            $info .= '<span class="expandable">' . substr($users_text, 0, 80) . '...</span>';
            $info .= '<div class="expanded">' . $users_text . '</div>';
        } else {
            $info .= '<small>' . $users_text . '</small>';
        }
        
        $info .= '</div>';
        return $info;
    }
    

    
    public function display_registration_logs() {
        $logs = SPAT_Database::get_registration_logs();
        
        if (empty($logs)) {
            echo '<p>' . __('No registration activity recorded yet.', 'sportspress-admin-tools') . '</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr>';
        echo '<th>' . __('Timestamp', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Order', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Customer', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . sprintf(__('%s Record', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')) . '</th>';
        echo '<th>' . SPAT_Text_Helper::get_text('Season') . '</th>';
        echo '<th>' . __('Position', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Match Criteria', 'sportspress-admin-tools') . '</th>';
        echo '</tr></thead><tbody>';
        
        foreach ($logs as $log) {
            if (is_object($log)) {
                $log = (array) $log;
            }
            $match_criteria = 'Unknown';
            if ($log['action'] === 'player_found_by_email') {
                $match_criteria = 'Email Match';
            } elseif ($log['action'] === 'player_found_by_name') {
                $match_criteria = 'Name Match';
            } elseif ($log['action'] === 'player_created') {
                $match_criteria = 'New Player';
            } elseif ($log['action'] === 'multiple_players_found_name_match_requires_email') {
                $match_criteria = 'Multiple Names - Email Required';
            } elseif ($log['action'] === 'player_creation_disabled') {
                $match_criteria = 'Creation Disabled';
            }
            
            echo '<tr>';
            echo '<td>' . esc_html($log['timestamp']) . '</td>';
            echo '<td><a href="' . admin_url('post.php?post=' . $log['order_id'] . '&action=edit') . '">#' . $log['order_id'] . '</a></td>';
            echo '<td>' . esc_html($log['customer_name']) . '</td>';
            echo '<td>' . ($log['player_id'] ? '<a href="' . admin_url('post.php?post=' . $log['player_id'] . '&action=edit') . '">' . get_the_title($log['player_id']) . '</a>' : 'N/A') . '</td>';
            echo '<td>' . esc_html($log['season']) . '</td>';
            echo '<td>' . esc_html($log['position']) . '</td>';
            echo '<td>' . $match_criteria . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
    }
    
    public function display_role_logs() {
        $logs = SPAT_Database::get_role_logs();
        
        if (empty($logs)) {
            echo '<p>' . __('No role assignments recorded yet.', 'sportspress-admin-tools') . '</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr>';
        echo '<th>' . __('Timestamp', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('User', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Action', 'sportspress-admin-tools') . '</th>';
        echo '</tr></thead><tbody>';
        
        foreach ($logs as $log) {
            if (is_object($log)) {
                $log = (array) $log;
            }
            
            $action_text = 'Player role added';
            if ($log['action'] === 'role_already_exists') {
                $action_text = 'Player role already present';
            } elseif ($log['action'] === 'role_assignment_disabled') {
                $action_text = 'Role assignment disabled';
            } elseif ($log['action'] === 'guest_checkout_skipped') {
                $action_text = 'Guest checkout - skipped';
            }
            
            echo '<tr>';
            echo '<td>' . esc_html($log['timestamp']) . '</td>';
            echo '<td><a href="' . admin_url('user-edit.php?user_id=' . $log['user_id']) . '">' . esc_html($log['user_name']) . '</a></td>';
            echo '<td>' . $action_text . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
    }
    
    public function settings_page() {
        $this->check_permissions();
        
        // Handle tab persistence after form submission
        if (isset($_POST['current_tab']) && isset($_GET['settings-updated'])) {
            $tab = sanitize_text_field($_POST['current_tab']);
            wp_redirect(admin_url('options-general.php?page=sportspress-admin-tools&settings-updated=true&tab=' . $tab));
            exit;
        }
        
        if (isset($_GET['settings-updated'])) {
            add_settings_error('spat_messages', 'spat_message', __('Settings Saved', 'sportspress-admin-tools'), 'updated');
        }
        
        settings_errors('spat_messages');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <nav class="nav-tab-wrapper">
                <a href="#general" class="nav-tab"><?php _e('General', 'sportspress-admin-tools'); ?></a>
                <a href="#etransfer" class="nav-tab"><?php _e('e-Transfer', 'sportspress-admin-tools'); ?></a>
                <a href="#player-registration" class="nav-tab"><?php printf(__('%s Registration', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')); ?></a>
                <a href="#player-stats" class="nav-tab"><?php printf(__('%s Stats', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')); ?></a>
                <a href="#player-modifications" class="nav-tab"><?php printf(__('%s Modifications', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')); ?></a>
                <a href="#events" class="nav-tab"><?php _e('Events', 'sportspress-admin-tools'); ?></a>
            </nav>
            
            <div id="general" class="tab-content">
                <form action="options.php" method="post">
                    <input type="hidden" name="current_tab" value="general">
                    <?php
                    settings_fields('spat_general_settings');
                    do_settings_sections('spat_general_settings');
                    submit_button(__('Save Settings', 'sportspress-admin-tools'));
                    ?>
                </form>
            </div>
            
            <div id="etransfer" class="tab-content" style="display:none;">
                <form action="options.php" method="post">
                    <input type="hidden" name="current_tab" value="etransfer">
                    <?php
                    settings_fields('spat_etransfer_settings');
                    do_settings_sections('spat_etransfer_settings');
                    submit_button(__('Save Settings', 'sportspress-admin-tools'));
                    ?>
                </form>
                
                <div id="setup-instructions" style="background: #f9f9f9; border: 1px solid #ddd; padding: 15px; margin: 20px 0;">
                    <!-- Setup instructions will be populated by JavaScript -->
                </div>
                
                <h2><?php _e('Webhook Activity Log', 'sportspress-admin-tools'); ?></h2>
                <?php $this->display_webhook_logs(); ?>
            </div>
            
            <div id="player-registration" class="tab-content" style="display:none;">
                <form action="options.php" method="post">
                    <input type="hidden" name="current_tab" value="player-registration">
                    <?php
                    settings_fields('spat_player_registration_settings');
                    do_settings_sections('spat_player_registration_settings');
                    submit_button(__('Save Settings', 'sportspress-admin-tools'));
                    ?>
                </form>
                
                <h2><?php printf(__('Manual %s-User Sync', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')); ?></h2>
                <?php 
                $enabled_modules = get_option('spat_enabled_modules', array());
                if (!in_array('player_registration', $enabled_modules)) {
                    echo '<p><em>' . __('This tool is only available when the Player Registration module is enabled in the General tab.', 'sportspress-admin-tools') . '</em></p>';
                }
                $this->display_player_sync_tool(); 
                ?>
                
                <h2><?php _e('Registration Activity Log', 'sportspress-admin-tools'); ?></h2>
                <?php $this->display_registration_logs(); ?>
                
                <h2><?php _e('Role Assignment Log', 'sportspress-admin-tools'); ?></h2>
                <?php $this->display_role_logs(); ?>
            </div>
            
            <div id="player-stats" class="tab-content" style="display:none;">
                <form action="options.php" method="post">
                    <input type="hidden" name="current_tab" value="player-stats">
                    <?php
                    settings_fields('spat_player_stats_settings');
                    do_settings_sections('spat_player_stats_settings');
                    submit_button(__('Save Settings', 'sportspress-admin-tools'));
                    ?>
                </form>
                
                <h2><?php printf(__('Bulk Enable %s Stats', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')); ?></h2>
                <?php 
                $enabled_modules = get_option('spat_enabled_modules', array());
                if (!in_array('player_stats_enabler', $enabled_modules)) {
                    echo '<p><em>' . __('This tool is only available when the Player Stats Enabler module is enabled in the General tab.', 'sportspress-admin-tools') . '</em></p>';
                }
                $this->display_bulk_stats_tool(); 
                ?>
            </div>
            
            <div id="player-modifications" class="tab-content" style="display:none;">
                <form action="options.php" method="post">
                    <input type="hidden" name="current_tab" value="player-modifications">
                    <?php
                    settings_fields('spat_player_modifications_settings');
                    do_settings_sections('spat_player_modifications_settings');
                    submit_button(__('Save Settings', 'sportspress-admin-tools'));
                    ?>
                </form>
            </div>
            
            <div id="events" class="tab-content" style="display:none;">
                <form action="options.php" method="post">
                    <input type="hidden" name="current_tab" value="events">
                    <?php
                    settings_fields('spat_events_settings');
                    do_settings_sections('spat_events_settings');
                    submit_button(__('Save Settings', 'sportspress-admin-tools'));
                    ?>
                </form>
                
                <?php 
                $enabled_modules = get_option('spat_enabled_modules', array());
                if (in_array('events_management', $enabled_modules)) {
                    if (class_exists('SPAT_Events_Management')) {
                        $events_manager = new SPAT_Events_Management();
                        $events_manager->display_admin_interface();
                    } else {
                        require_once SPAT_PLUGIN_PATH . 'modules/class-events-management.php';
                        $events_manager = new SPAT_Events_Management();
                        $events_manager->display_admin_interface();
                    }
                } else {
                    echo '<h2>' . __('Tools', 'sportspress-admin-tools') . '</h2>';
                    echo '<p><em>' . __('Tools are only available when the Events Management module is enabled in the General tab.', 'sportspress-admin-tools') . '</em></p>';
                }
                ?>
            </div>
        </div>
        <?php
    }
}