<?php
/**
 * Plugin Name: SportsPress Admin Tools
 * Description: Administrative tools for SportsPress
 * Version: 1.0.0
 * Author: Cody (lusky3)
 * Text Domain: sportspress-admin-tools
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    wp_die();
}

// Define plugin constants
define('SPAT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SPAT_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('SPAT_VERSION', '1.0.0');

// Main plugin class
if (!class_exists('SportsPress_Admin_Tools')) {
    class SportsPress_Admin_Tools {
        
        public function __construct() {
            add_action('plugins_loaded', array($this, 'init'));
            register_activation_hook(__FILE__, array($this, 'activate'));
            register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        }
        
        public function init() {
            // Load text domain
            load_plugin_textdomain('sportspress-admin-tools', false, dirname(plugin_basename(__FILE__)) . '/languages');
            
            // Initialize admin
            if (is_admin()) {
                $this->init_admin();
            }
            
            // Initialize modules
            $this->init_modules();
        }
        
        private function init_admin() {
            require_once SPAT_PLUGIN_PATH . 'includes/class-text-helper.php';
            require_once SPAT_PLUGIN_PATH . 'includes/class-database.php';
            require_once SPAT_PLUGIN_PATH . 'includes/class-admin.php';
            new SPAT_Admin();
            
            // Check if database needs setup
            if (get_option('spat_db_version') !== '1.0.0') {
                SPAT_Database::create_tables();
            }
            
            // Migrate existing logs once
            if (!get_option('spat_logs_migrated')) {
                SPAT_Database::migrate_existing_logs();
            }
            
            // e-Transfer admin page (always load if WooCommerce is active)
            if ($this->is_woocommerce_active()) {
                require_once SPAT_PLUGIN_PATH . 'includes/class-etransfer-admin.php';
                new SPAT_ETransfer_Admin();
            }
        }
        
        private function init_modules() {
            // Initialize file downloads
            require_once SPAT_PLUGIN_PATH . 'includes/class-file-downloads.php';
            new SPAT_File_Downloads();
            
            $enabled_modules = get_option('spat_enabled_modules', array());
            
            // e-Transfer Automation Module
            if (in_array('etransfer_automation', $enabled_modules)) {
                if ($this->is_woocommerce_active()) {
                    // Load database class for webhook logging
                    require_once SPAT_PLUGIN_PATH . 'includes/class-database.php';
                    require_once SPAT_PLUGIN_PATH . 'modules/class-etransfer-automation.php';
                    new SPAT_ETransfer_Automation();
                } else {
                    add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
                }
            }
            
            // Player Registration Module
            if (in_array('player_registration', $enabled_modules)) {
                if ($this->is_woocommerce_active() && $this->is_sportspress_active()) {
                    require_once SPAT_PLUGIN_PATH . 'modules/class-player-registration.php';
                    new SPAT_Player_Registration();
                } else {
                    add_action('admin_notices', array($this, 'dependencies_missing_notice'));
                }
            }
            
            // League Table Generator Module
            if (in_array('league_table_generator', $enabled_modules)) {
                if ($this->is_sportspress_active()) {
                    require_once SPAT_PLUGIN_PATH . 'modules/class-league-table-generator.php';
                    new SPAT_League_Table_Generator();
                } else {
                    add_action('admin_notices', array($this, 'sportspress_missing_notice'));
                }
            }
            
            // Player Stats Enabler Module
            if (in_array('player_stats_enabler', $enabled_modules)) {
                if ($this->is_sportspress_active()) {
                    require_once SPAT_PLUGIN_PATH . 'modules/class-player-stats-enabler.php';
                    new SPAT_Player_Stats_Enabler();
                } else {
                    add_action('admin_notices', array($this, 'sportspress_missing_notice'));
                }
            }
            
            // Player Modifications Module
            if (in_array('player_modifications', $enabled_modules)) {
                if ($this->is_sportspress_active() && $this->is_woocommerce_active()) {
                    require_once SPAT_PLUGIN_PATH . 'modules/class-player-modifications.php';
                    new SPAT_Player_Modifications();
                } else {
                    add_action('admin_notices', array($this, 'dependencies_missing_notice'));
                }
            }
            
            // Events Management Module
            if (in_array('events_management', $enabled_modules)) {
                if ($this->is_sportspress_active()) {
                    require_once SPAT_PLUGIN_PATH . 'modules/class-events-management.php';
                    new SPAT_Events_Management();
                } else {
                    add_action('admin_notices', array($this, 'sportspress_missing_notice'));
                }
            }
        }
        
        private function is_woocommerce_active() {
            return class_exists('WooCommerce');
        }
        
        private function is_sportspress_active() {
            return class_exists('SportsPress');
        }
        
        public function woocommerce_missing_notice() {
            echo '<div class="notice notice-error"><p>';
            echo __('SportsPress Admin Tools: e-Transfer Automation requires WooCommerce to be installed and activated.', 'sportspress-admin-tools');
            echo '</p></div>';
        }
        
        public function dependencies_missing_notice() {
            echo '<div class="notice notice-error"><p>';
            echo __('SportsPress Admin Tools: Player Registration requires WooCommerce and SportsPress to be installed and activated.', 'sportspress-admin-tools');
            echo '</p></div>';
        }
        
        public function sportspress_missing_notice() {
            echo '<div class="notice notice-error"><p>';
            echo __('SportsPress Admin Tools: League Table Generator requires SportsPress to be installed and activated.', 'sportspress-admin-tools');
            echo '</p></div>';
        }
        
        public function activate() {
            // Set default options
            add_option('spat_enabled_modules', array());
            add_option('spat_remove_data_on_uninstall', '0');
        }
        
        public function deactivate() {
            // Cleanup if needed
        }
    }
    
    // Initialize plugin
    new SportsPress_Admin_Tools();
}