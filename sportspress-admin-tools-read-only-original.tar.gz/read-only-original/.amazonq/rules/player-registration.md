# Player Registration Module Rules

## Overview

The Player Registration module automatically creates SportsPress player records when customers complete WooCommerce orders for registration products, and links user accounts to player records.

## Order Processing Flow

### 1. Order Completion Trigger
- Activates on `woocommerce_order_status_completed` hook
- Processes only orders containing registration products
- Extracts customer billing name for player matching

### 2. Registration Product Identification
- **Category**: Must contain "registration" in category name
- **Season Category**: Format `W2024-25`, `S2025`, `W2025-26`, `S2026`, etc.
- **Product Tags**: "player" (default) or "goalie" for position

### 3. Player Record Management
- **Search**: Look for existing `sp_player` by name match
- **Create**: Generate new `sp_player` if no match found
- **Season Assignment**: Add season taxonomy to player record
- **Position Tracking**: Store player/goalie designation

### 4. User Account Integration
- **Role Assignment**: Add "player" role to non-guest customers
- **Player Linking**: Set `sp_user` meta to link user to player record
- **Guest Handling**: Skip user operations for guest checkouts

## Manual Player-User Sync

### Sync Process
- Find unlinked `sp_player` records (no `sp_user` meta)
- Search for users with matching names (display_name, first_name + last_name)
- **Single Match**: Auto-link user to player and assign role
- **Multiple Matches**: Present admin interface for manual selection
- **No Matches**: Leave unlinked for manual handling

### Admin Interface
- **Sync Button**: Trigger manual sync process
- **Match Display**: Show player and matching users for selection
- **Manual Linking**: Admin selects correct user-player pairs

## Data Structure

### Player Records (`sp_player`)
- **Post Type**: `sp_player`
- **Title**: Customer billing name
- **Meta**: `sp_user` (linked user ID)
- **Taxonomy**: `sp_season` (season terms)

### Season Format
- **Winter**: `W2024-25`, `W2025-26`
- **Summer**: `S2025`, `S2026`
- **Auto-Creation**: Create season terms if they don't exist

### User Roles
- **Role**: `player`
- **Assignment**: Added to non-guest customers
- **Preservation**: Only add if not already present

## Logging System

### Registration Activity Log
- **Columns**: Timestamp, Order, Customer, Player Record, Season, Position
- **Storage**: Last 100 entries in `spat_player_registration_logs`
- **Links**: Direct links to WooCommerce orders and player records

### Role Assignment Log
- **Columns**: Timestamp, User, Action
- **Storage**: Last 100 entries in `spat_player_role_logs`
- **Links**: Direct links to user edit pages

## Admin Interface

### Settings Location
- WordPress Admin → Settings → SportsPress Admin Tools → Player Registration tab

### Features
- **Manual Sync Tool**: Sync unlinked players to users
- **Registration Log**: Track all automatic registrations
- **Role Assignment Log**: Track user role additions
- **Dependency Checks**: Verify WooCommerce and SportsPress are active

## Dependencies

### Required
- **WordPress**: 5.0+
- **WooCommerce**: Active and configured
- **SportsPress**: Active with player post type

### Product Setup
- **Categories**: "registration" + season (e.g., "W2025-26")
- **Tags**: "player" or "goalie"
- **Status**: Published products

## Error Handling

### Common Issues
- **Missing Dependencies**: Show admin notices
- **Invalid Season Format**: Skip processing
- **Player Creation Failure**: Log error
- **User Role Assignment Failure**: Continue processing

### Data Validation
- Verify product categories and tags
- Validate season format with regex
- Check user and player record existence
- Ensure proper post type and status

## Best Practices

### Product Configuration
- Use consistent season naming (W2024-25, S2025)
- Apply correct product tags (player/goalie)
- Include "registration" in category names

### User Management
- Encourage account creation over guest checkout
- Use consistent billing names
- Monitor sync tool for unlinked players

### Monitoring
- Review registration logs regularly
- Check for failed player creations
- Verify season assignments are correct

## Troubleshooting

### Players Not Created
1. Check product has "registration" category
2. Verify season format in categories
3. Confirm order status is "completed"
4. Review registration activity log

### Users Not Linked
1. Verify customer didn't checkout as guest
2. Check user account exists
3. Run manual sync tool
4. Review role assignment log

### Season Issues
1. Confirm season format matches regex pattern
2. Check taxonomy creation permissions
3. Verify SportsPress season taxonomy exists