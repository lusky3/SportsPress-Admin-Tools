# SportsPress Text Overrides Implementation

## Overview

This document describes the implementation of SportsPress text overrides in the SportsPress Admin Tools plugin. The system allows administrators to customize SportsPress terminology (e.g., changing "Player" to "Athlete" or "League" to "Conference") and have those changes reflected throughout our plugin's user interface.

## Implementation

### Text Helper Class

Created `includes/class-text-helper.php` with the following functionality:

- `SPAT_Text_Helper::get_text($text, $domain)` - Returns overridden text or falls back to translation
- `SPAT_Text_Helper::echo_text($text, $domain)` - Echoes overridden text with HTML escaping

### Integration Points

The text helper has been integrated into the following modules and locations:

#### Admin Interface (`includes/class-admin.php`)
- Module names and descriptions
- Settings field titles and section headers
- Tab navigation labels
- Tool section headers
- Form labels and descriptions
- Success/error messages

#### Events Management (`modules/class-events-management.php`)
- Import interface labels
- Column headers and descriptions
- Preview and confirmation messages
- Settings descriptions

#### Player Modifications (`modules/class-player-modifications.php`)
- Meta box titles
- Form labels and descriptions
- Admin interface text

#### League Table Generator (`modules/class-league-table-generator.php`)
- Modal dialog titles and labels
- Form elements and buttons
- Success messages and alerts

### Supported SportsPress Terms

The following SportsPress terms are now overrideable in our plugin:

- **Player** / **Players**
- **Team** / **Teams** 
- **League** / **Leagues**
- **Venue** / **Venues**
- **Season** / **Seasons**
- **Event** / **Events**

### Usage Examples

```php
// Get overridden text
$player_text = SPAT_Text_Helper::get_text('Player');

// Echo overridden text (with escaping)
SPAT_Text_Helper::echo_text('Team');

// Use in sprintf for dynamic text
sprintf(__('Add %s:', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Team'));

// Use in admin interface
echo '<h2>' . sprintf(__('%s Registration', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')) . '</h2>';
```

### How It Works

1. **Check for SportsPress**: Verifies that SportsPress is loaded and available
2. **Check for Overrides**: Looks in `SP()->text` array for custom terminology
3. **Return Override**: If found, returns the custom text
4. **Fallback**: If no override exists, returns the standard translated text

### Configuration

Text overrides are configured in SportsPress settings:
1. Go to SportsPress → Settings → Text
2. Add custom terminology (e.g., "Player" → "Athlete")
3. Save settings
4. Our plugin will automatically use the custom terms

### Files Modified

- `sportspress-admin-tools.php` - Added text helper include
- `includes/class-text-helper.php` - New helper class
- `includes/class-admin.php` - Updated all user-facing SportsPress terms
- `modules/class-events-management.php` - Updated event-related terms
- `modules/class-player-modifications.php` - Updated player-related terms  
- `modules/class-league-table-generator.php` - Updated league/team terms

### Testing

A test file `test-text-override.php` has been created to verify functionality:
- Tests basic text override functionality
- Checks SportsPress availability
- Displays configured overrides
- **Note**: Remove this file after testing

### Backward Compatibility

The implementation maintains full backward compatibility:
- If SportsPress is not available, standard text is used
- If no overrides are configured, standard text is used
- All existing functionality remains unchanged

### Performance Impact

Minimal performance impact:
- Simple array lookup for overrides
- Fallback to standard translation functions
- No database queries or complex processing

## Benefits

1. **Consistent Terminology**: Custom SportsPress terms are now used throughout our plugin
2. **User Experience**: Administrators see consistent terminology across all interfaces
3. **Flexibility**: Easy to extend to additional terms as needed
4. **Maintainable**: Centralized text override logic in helper class
5. **Standards Compliant**: Follows WordPress and SportsPress conventions