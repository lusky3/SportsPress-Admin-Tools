# Player Registration Module Fixes

## Issues Fixed

### 1. Player Lookup Logic
**Problem**: Players were not being found due to incorrect search criteria.

**Fix**: Implemented proper two-tier lookup system:
- **First criteria**: Search by `spat_email` meta field (exact match)
- **Second criteria**: Search by First Name + Last Name match (post title)

### 2. Season Parsing
**Problem**: Season was only extracted from product categories, not product title as specified.

**Fix**: Modified `extract_season_from_product()` to:
- First try to extract season from product title using regex
- Fallback to category-based extraction if not found in title

### 3. Database Logging
**Problem**: Logging methods were not handling NULL values properly and had no error handling.

**Fix**: 
- Added proper NULL handling in database insert methods
- Added error logging for failed database operations
- Ensured database tables are created before logging attempts
- Added try-catch blocks around logging operations

### 4. Module Initialization
**Problem**: Database tables might not exist when module runs.

**Fix**: Added database table creation check in `process_completed_order()` method.

## Key Changes Made

### In `class-player-registration.php`:

1. **Enhanced `find_or_create_player()` method**:
   ```php
   // First criteria: Search by spat_email if provided
   if (!empty($customer_email)) {
       $players = get_posts(array(
           'post_type' => 'sp_player',
           'post_status' => 'publish',
           'posts_per_page' => 1,
           'meta_query' => array(
               array(
                   'key' => 'spat_email',
                   'value' => strtolower($customer_email),
                   'compare' => '='
               )
           )
       ));
   }
   
   // Second criteria: Search by First Name Last Name match
   if (!$player_id) {
       $players = get_posts(array(
           'post_type' => 'sp_player',
           'post_status' => 'publish',
           'title' => $customer_name,
           'posts_per_page' => 1
       ));
   }
   ```

2. **Improved `extract_season_from_product()` method**:
   ```php
   // First try to extract from product title
   $product_title = get_the_title($product_id);
   if (preg_match('/([WS]\d{4}(?:-\d{2})?)/', $product_title, $matches)) {
       return $matches[1];
   }
   
   // Fallback to categories
   $categories = wp_get_post_terms($product_id, 'product_cat');
   foreach ($categories as $category) {
       if (preg_match('/^[WS]\d{4}(-\d{2})?$/', $category->name)) {
           return $category->name;
       }
   }
   ```

3. **Enhanced logging methods** with error handling and database checks.

### In `class-database.php`:

1. **Improved `log_registration_activity()` method**:
   ```php
   $result = $wpdb->insert($table_name, array(
       'order_id' => intval($order_id),
       'customer_name' => sanitize_text_field($customer_name),
       'player_id' => $player_id ? intval($player_id) : null,
       'season' => sanitize_text_field($season),
       'position' => sanitize_text_field($position),
       'action' => sanitize_text_field($action)
   ), array(
       '%d', '%s', $player_id ? '%d' : null, '%s', '%s', '%s'
   ));
   
   if ($result === false) {
       error_log('SPAT Database: Failed to log registration activity - ' . $wpdb->last_error);
   }
   ```

2. **Improved `log_role_assignment()` method** with similar enhancements.

## Testing Instructions

### 1. Enable the Module
1. Go to WordPress Admin → Settings → SportsPress Admin Tools
2. In the General tab, check "Player Registration"
3. Save Settings

### 2. Configure Settings
1. Go to the Player Registration tab
2. Ensure both "Automatic Role Assignment" and "Automatic Player Creation" are checked
3. Save Settings

### 3. Create Test Products
1. Create a WooCommerce product
2. Add it to a category containing "registration" (e.g., "Hockey Registration")
3. Add a season category like "W2024-25" or "S2025"
4. Optionally add product tags "player" or "goalie"

### 4. Test the Flow
1. Create a test order with the registration product
2. Mark the order as "Completed"
3. Check the Player Registration logs in Settings → SportsPress Admin Tools → Player Registration tab

### 5. Verify Results
- Check if a new `sp_player` record was created
- Verify the customer received the "player" role
- Review the Registration Activity Log and Role Assignment Log

## Debug Tools

### 1. Error Logs
Check WordPress error logs for detailed processing information:
```
SPAT Player Registration: Processing order #123 for customer 'John Doe'
SPAT Player Registration: Found existing player by email 'john@example.com' (ID: 456)
SPAT Player Registration: Logged activity - Order: #123, Customer: John Doe, Action: player_found_by_email
```

### 2. Database Tables
The module creates these tables:
- `wp_spat_registration_logs` - Player creation/finding activity
- `wp_spat_role_logs` - Role assignment activity

### 3. Debug Script
Use the provided `debug-player-registration.php` by adding its contents to your theme's `functions.php` file temporarily.

## Expected Log Actions

### Registration Activity Log Actions:
- `player_found_by_email` - Existing player found by email match
- `player_found_by_name` - Existing player found by name match
- `player_created` - New player record created
- `player_creation_disabled` - Auto-creation is disabled

### Role Assignment Log Actions:
- `role_assigned` - Player role successfully added to user
- `role_already_exists` - User already has player role
- `role_assignment_disabled` - Auto-assignment is disabled
- `guest_checkout_skipped` - Guest checkout, no user account to assign role

## Troubleshooting

### No Logs Appearing
1. Verify the module is enabled in General settings
2. Check that database tables exist
3. Ensure WooCommerce and SportsPress are active
4. Check WordPress error logs for database errors

### Players Not Being Created
1. Verify "Automatic Player Creation" is enabled
2. Check that products have "registration" in category name
3. Ensure season format matches regex pattern `[WS]\d{4}(-\d{2})?`
4. Check error logs for processing details

### Roles Not Being Assigned
1. Verify "Automatic Role Assignment" is enabled
2. Ensure customer is not checking out as guest
3. Check that user account exists and is valid
4. Review Role Assignment Log for specific actions taken