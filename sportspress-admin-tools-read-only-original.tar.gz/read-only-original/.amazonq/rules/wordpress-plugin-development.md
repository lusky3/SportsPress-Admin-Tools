# WordPress Plugin Development Rules

## Plugin Structure

- Main plugin file must include WordPress plugin header with Plugin Name
- Use recommended folder structure: `/admin`, `/public`, `/includes`, `/languages`
- Prevent direct access with `if (!defined('ABSPATH')) { exit; }`
- Use unique prefixes for all functions, classes, and options to avoid conflicts

## Security & Best Practices

- Always escape output with `esc_html()`, `esc_attr()`, `esc_url()`
- Sanitize input data before processing
- Use nonces for AJAX requests and form submissions
- Check user capabilities before allowing actions
- Load admin-specific code conditionally with `is_admin()`

## Internationalization

- Define text domain in plugin header matching plugin slug
- Use translation functions: `__()`, `_e()`, `_n()`, `_x()`
- Load text domain on `init` hook with `load_plugin_textdomain()`
- Add translator comments for context: `/* translators: explanation */`

## WordPress APIs

- Use Settings API for admin pages and options
- Register activation/deactivation hooks for setup/cleanup
- Use `plugins_url()` for asset URLs, never hardcode paths
- Implement proper AJAX handlers with `wp_ajax_` hooks
- Use WP Cron for scheduled tasks, unschedule on deactivation

## Code Organization

- Use classes with existence checks: `if (!class_exists('ClassName'))`
- Implement proper hook priorities and argument counts
- Follow WordPress coding standards and naming conventions
- Include GPL license block in main plugin file
