# Events Management Module Rules

## Overview

The Events Management module provides tools for managing SportsPress events and calendars, including automated calendar management and bulk event import capabilities.

## Core Features

### 1. Calendar Reset to Current Season
- **Function**: Reset all existing calendars to use the current season
- **Purpose**: Quickly update all calendars when transitioning between seasons
- **Implementation**: Updates `sp_season` taxonomy terms for all `sp_calendar` posts
- **Season Logic**: 
  - September-December: Winter season (W2024-25 format)
  - January-August: Summer season (S2024 format)

### 2. Auto-Create Calendars for New Teams
- **Trigger**: Automatically runs when new teams are created (`sp_after_team_save` hook)
- **Function**: Creates a calendar for each new team if one doesn't exist
- **Calendar Setup**:
  - Links calendar to team via `sp_team` meta
  - Assigns current season
  - Copies team's league assignments
  - Uses team name + "Calendar" as title

### 3. XLSX Event Import
- **File Support**: Excel (.xlsx) files with structured event data
- **Required Columns**: Date, Home Team, Away Team
- **Optional Columns**: Time, Venue, League, Title
- **Smart Team Matching**: Fuzzy matching with existing teams, uses actual team names in event titles
- **Auto-Creation**: Creates venues and leagues as taxonomy terms if they don't exist
- **Date Formats**: Supports YYYY-MM-DD, MM/DD/YYYY, DD/MM/YYYY
- **Time Formats**: Supports HH:MM and H:MM AM/PM
- **Team Assignment**: Automatically assigns event's league and season to participating teams
- **Import Confirmation**: Shows success/error counts after import completion

## Data Structure

### Calendar Management
- **Post Type**: `sp_calendar`
- **Team Link**: `sp_team` meta field (array of team IDs)
- **Season Assignment**: `sp_season` taxonomy
- **League Assignment**: `sp_league` taxonomy (copied from team)

### Event Creation
- **Post Type**: `sp_event`
- **Date/Time**: Use `post_date` field, NOT `sp_date`/`sp_time` meta
- **Permalink**: Set `post_name` to event ID after creation
- **Teams**: Individual `sp_team` meta entries (not array)
- **Venue**: `sp_venue` taxonomy term (not meta or post)
- **Required Meta Structure**:
  - `sp_players`: Team-indexed arrays with stat placeholders
  - `sp_player`: Two entries set to 0
  - `sp_staff`: Two entries set to 0
  - `sp_results`: Team-indexed arrays with goal placeholders
- **Team Assignment**: Teams must share same league/season as event
- **Taxonomies**: `sp_season`, `sp_league`, `sp_venue`

### Season Detection
- **Current Season Logic**:
  - Month 9-12: Winter season (W + current_year + "-" + next_year_short)
  - Month 1-8: Summer season (S + current_year)
- **Auto-Creation**: Creates season terms if they don't exist

## Import File Format

### XLSX Structure
```
| Date       | Time  | Home Team | Away Team | Venue      | League    | Title (optional) |
|------------|-------|-----------|-----------|------------|-----------|------------------|
| 2024-01-15 | 19:00 | Team A    | Team B    | Arena 1    | Division A| Game 1           |
| 01/16/2024 | 7:30 PM| Team C   | Team D    | Arena 2    | Division B|                  |
```

### Column Mapping
- **Title**: title, event, game, match
- **Date**: date, game_date, event_date
- **Time**: time, game_time, event_time
- **Home Team**: home, home_team, team_a
- **Away Team**: away, away_team, team_b
- **Venue**: venue, location, arena
- **League**: league, division, competition

## Security and Validation

### File Upload Security
- **File Type Validation**: Only .xlsx files accepted
- **Upload Directory**: WordPress uploads directory
- **Temporary Files**: Cleaned up after processing
- **Permission Check**: Requires `manage_options` capability

### Data Validation
- **Required Fields**: Date, Home Team, Away Team must be present
- **Date Parsing**: Multiple format support with fallback
- **Team Creation**: Only creates teams if they don't exist
- **Duplicate Prevention**: Checks for existing calendars before creation

## Admin Interface

### Calendar Management Section
- **Reset Calendars**: Button to update all calendars to current season
- **Auto-Create Status**: Shows that auto-creation is always active
- **Confirmation**: JavaScript confirmation for destructive actions

### Event Import Section
- **File Upload**: XLSX file selection with format requirements
- **Format Guide**: Lists expected columns and formats
- **Progress Feedback**: Success/error messages with import counts

## Error Handling

### Common Issues
- **Invalid File Format**: Non-XLSX files rejected
- **Missing Required Columns**: Rows with missing data skipped
- **Date Parse Errors**: Falls back to current date
- **Team Creation Failures**: Logged but import continues

### User Feedback
- **Success Messages**: Show number of imported events
- **Error Messages**: Clear descriptions of issues
- **Validation Warnings**: Inform about skipped rows

## Performance Considerations

### Bulk Operations
- **Batch Processing**: Events imported one at a time
- **Memory Management**: Files cleaned up after processing
- **Database Efficiency**: Uses WordPress post creation APIs
- **Transaction Safety**: Each event creation is atomic

### Optimization
- **Existing Entity Lookup**: Checks for teams/venues before creating
- **Minimal Meta Updates**: Only sets necessary meta fields
- **Taxonomy Caching**: Reuses season/league terms

## Integration Points

### SportsPress Hooks
- **Team Creation**: `sp_after_team_save` for auto-calendar creation
- **Post Types**: Works with `sp_team`, `sp_event`, `sp_calendar`, `sp_venue`
- **Taxonomies**: Manages `sp_season`, `sp_league` terms

### WordPress Integration
- **File Uploads**: Uses WordPress upload handling
- **Post Creation**: Standard `wp_insert_post()` functions
- **Meta Management**: WordPress meta API
- **Permissions**: WordPress capability system

## Best Practices

### Before Import
1. **Backup Database**: Always backup before bulk imports
2. **Test File Format**: Verify XLSX structure matches requirements
3. **Check Existing Data**: Review current teams/venues to avoid duplicates

### During Import
1. **Monitor Progress**: Watch for error messages
2. **Verify Results**: Check created events in SportsPress
3. **Review Auto-Created Entities**: Confirm teams/venues are correct

### After Import
1. **Validate Data**: Ensure all events imported correctly
2. **Update Calendars**: Run calendar reset if needed
3. **Clean Up**: Remove temporary files if any remain

## Troubleshooting

### Import Issues
- **No Events Imported**: Check file format and required columns
- **Missing Teams**: Verify team names in XLSX match expected format
- **Date Problems**: Ensure dates are in supported formats
- **Permission Errors**: Confirm user has `manage_options` capability
- **Teams Not Showing**: Ensure teams have same league/season as event
- **Wrong Team Names**: Import uses actual team names from database, not XLSX names

### Event Structure Issues
- **Events Not Displaying Properly**: Check `sp_players`, `sp_player`, `sp_staff` meta structure
- **Venue Missing**: Venue stored as `sp_venue` taxonomy, not meta or post
- **Wrong Permalink**: `post_name` should match event ID
- **Date/Time Issues**: Use `post_date` field, not `sp_date`/`sp_time` meta

### Calendar Issues
- **Auto-Creation Not Working**: Check if SportsPress team hooks are firing
- **Season Assignment Problems**: Verify season detection logic
- **Missing Calendars**: Run manual calendar reset

### File Format Issues
- **XLSX Not Recognized**: Currently falls back to CSV parsing
- **Column Headers**: Ensure first row contains proper headers
- **Empty Rows**: Blank rows are automatically skipped

## Dependencies

### Required
- **WordPress**: 5.0+
- **SportsPress**: Active with event and calendar post types
- **PHP**: 5.6+ for DateTime parsing

### Optional
- **PhpSpreadsheet**: For proper XLSX parsing (future enhancement)
- **WP-CLI**: For command-line event management

## Future Enhancements

### Planned Features
- **Proper XLSX Parser**: Replace SimpleXLSX with PhpSpreadsheet
- **Event Templates**: Save common event configurations
- **Bulk Event Editing**: Mass update existing events
- **Calendar Sync**: Two-way sync with external calendar systems

### API Extensions
- **REST Endpoints**: API access for event import
- **Webhook Support**: External system integration
- **Export Functions**: Export events to various formats
- **Scheduling**: Automated imports from external sources