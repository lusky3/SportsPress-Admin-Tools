# Development Environment Configuration

## System Environment

- **Operating System**: WSL2 Ubuntu
- **Default User**: root
- **Development User**: cody (non-root)
- **Development Site**: [http://arl-local.ddev.site](http://arl-local.ddev.site)
- **Database**: MySQL

- **ALWAYS** prefer the use of Model Context Protocol (MCP) tools before using command line tools.

### DDEV Commands

- **ALWAYS** run ddev commands as user `cody`
- **Format**: `sudo -u cody ddev [command]`
- **Example**: `sudo -u cody ddev mysql -e "SELECT * FROM wp_posts LIMIT 5;"`
