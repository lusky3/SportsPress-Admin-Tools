# WordPress.org Guidelines Rules

## Plugin Submission Requirements

- Plugin header must include Plugin Name, Version, Description, Author
- Create proper readme.txt with required fields and formatting
- Use semantic versioning for releases
- Include "Tested up to" field for WordPress compatibility
- Set "Requires at least" and "Requires PHP" appropriately

## Repository Management

- Use SVN repository structure: `/trunk`, `/tags`, `/assets`
- Create release tags with `svn copy /trunk /tags/version`
- Place screenshots and banners in `/assets` directory
- Never commit directly to tags, always work in trunk

## Block Plugin Specific

- Use proper block naming with namespace: `plugin-name/block-name`
- Include required block.json attributes: name, title, script/editorScript
- Avoid reserved namespaces like 'core' or 'wordpress'

## Update Management

- Add "Update URI" header to prevent WordPress.org updates for external plugins
- Use `http_request_args` filter to exclude plugin from update checks
- Maintain version consistency between plugin header and readme.txt

## Content Guidelines

- Use WordPress Playground blueprints for interactive demos
- Support video embedding with `[wpvideo]` shortcode
- Follow markdown syntax for readme.txt hyperlinks
- Provide clear installation and usage instructions
