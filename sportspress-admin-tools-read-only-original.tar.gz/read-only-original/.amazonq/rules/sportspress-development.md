# SportsPress Development Rules

## Project Context

- Working on SportsPress WordPress plugin automation tools
- Previous experience with SportsPress Player Merge plugin development
- Focus on data integrity and proper handling of player statistics

## Core Requirements

- **WordPress**: Deep understanding required
- **SportsPress Plugin**: Comprehensive knowledge essential
- **GitHub Repository**: [https://github.com/ThemeBoy/SportsPress](https://github.com/ThemeBoy/SportsPress)

## SportsPress API Resources

- **REST API Documentation**: [https://support.themeboy.com/category/339-rest-api](https://support.themeboy.com/category/339-rest-api)
- **Core API Files**: [https://github.com/ThemeBoy/SportsPress/tree/master/includes/api](https://github.com/ThemeBoy/SportsPress/tree/master/includes/api)

## Critical Event Creation Findings

### Event Structure Requirements
- **Date/Time**: Use `post_date` field, NOT `sp_date`/`sp_time` meta fields
- **Permalink**: Set `post_name` to event ID after creation for proper URLs
- **Teams**: Store as individual `sp_team` meta entries, not arrays
- **Venue**: Store as `sp_venue` taxonomy term, not meta or post type
- **Team Assignment**: Teams must share same league/season taxonomies as event

### Required Meta Structure
```php
// sp_players: Team-indexed with stat structure
$players[$team_id] = array(0 => array('g' => '', 'a' => '', 'pim' => '', 'ga' => ''));

// sp_player and sp_staff: Two entries set to 0
add_post_meta($event_id, 'sp_player', 0);
add_post_meta($event_id, 'sp_staff', 0);

// sp_results: Team-indexed with goal structure  
$results[$team_id] = array('goals' => '', 'goalstwo' => '');
```

## Data Operations

- Player merge operations require careful handling of:
  - Team assignments (sp_assignments table)
  - Player statistics (sp_statistics table)
  - Team entries (sp_team table)
  - Jersey numbers and duplicate detection
- Always preserve original IDs during data operations
- Implement proper revert/recovery processes for data operations

## Player Statistics Enabler Critical Findings

### sp_leagues Meta Field Controls Statistics Display

- **Discovery**: The `sp_leagues` meta field is the key to proper statistics display
- **Format**: `[league_id][season_id] = team_id`
- **Critical Issue**: When team_id = -1, statistics show "— None —" and don't calculate
- **Solution**: Must update sp_leagues to set actual team IDs, not just create sp_assignments

### Bulk Enable Stats Requirements

1. **sp_columns**: Enable statistic columns based on position (skater vs goalie)
2. **sp_assignments**: Create string format assignments from sp_leagues data
3. **sp_statistics**: Create empty stat arrays for each league/season
4. **sp_leagues**: Update team IDs from -1 to actual current team ID

### Implementation Pattern

```php
// Read existing sp_leagues data
$leagues_data = get_post_meta($player_id, 'sp_leagues', true);
$current_team = get_post_meta($player_id, 'sp_current_team', true);

// Update sp_leagues to set proper team IDs
foreach ($leagues_data as $league_id => $seasons) {
    foreach ($seasons as $season_id => $team_id) {
        if ($team_id == -1) {
            $leagues_data[$league_id][$season_id] = $current_team;
        }
    }
}
update_post_meta($player_id, 'sp_leagues', $leagues_data);
```

## Development Environment

- Use Docker-based WordPress + SportsPress test environment
- Alpine Linux base with Nginx + PHP-FPM + MariaDB
- Support multiple sports configurations via SPORTSPRESS_SPORT environment variable
- Automated sample data installation for testing

## Code Attribution

- Use author format: "Author: Cody (lusky3)" in code headers and documentation
- Username: lusky3
