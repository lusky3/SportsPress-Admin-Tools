# Data Integrity Rules

## Player Data Management

- Preserve original player IDs during all operations
- Maintain data structure integrity for:
  - Display settings
  - Current team assignments
  - League associations with seasons and events
  - Jersey numbers
  - Past team history
  - Statistics data

## Duplicate Detection

- Check for players with same jersey number and team
- Compare similar names for potential duplicates
- Verify team assignments before merging operations

## Recovery Procedures

- Implement proper revert operations for all data modifications
- Ensure no data loss during merge/unmerge operations
- Maintain original data structures and byte sizes
- Test recovery processes thoroughly before deployment
