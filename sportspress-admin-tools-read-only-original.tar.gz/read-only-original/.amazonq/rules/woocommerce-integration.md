# WooCommerce Integration Rules

## Hook System Best Practices

### Action and Filter Implementation

- Use lifecycle hooks: `woocommerce_before_*` and `woocommerce_after_*` patterns
- Implement escape hooks with `pre_` prefix for short-circuiting functions
- Pass objects instead of IDs to hooks for better data integrity
- Avoid dynamic hook names with enumeration values

### Hook Naming Conventions

- Prefix all hooks with `woocommerce_`
- Use descriptive names without execution path specifics
- Avoid embedding error codes or dynamic values in hook names
- Use generic hooks that pass context to callbacks

## Core WooCommerce Hooks

### Essential Action Hooks

- `woocommerce_add_to_cart` - Fires when item added to cart
- `woocommerce_applied_coupon` - After coupon applied
- `woocommerce_before_main_content` - Before main content rendering
- `woocommerce_after_main_content` - After main content rendering
- `woocommerce_before_shop_loop` - Before product loop
- `woocommerce_after_shop_loop` - After product loop

### Critical Filter Hooks

- `woocommerce_add_to_cart_validation` - Validate cart additions
- `woocommerce_cart_contents_changed` - Modify cart contents
- `woocommerce_get_item_data` - Modify cart item data
- `woocommerce_format_sale_price` - Format price display

## Block vs Classic Template Compatibility

### Supported Hooks

- Most core WooCommerce hooks work with blocks
- Legacy hooks migrated for block compatibility
- Use `woocommerce_blocks_hook_compatibility_additional_data` for extensions

### Unsupported Patterns

- Direct template modifications via hooks
- Checkout field modifications through legacy hooks
- Cart item removal link customizations
- Price formatting hooks in block context

## Security and Validation

### Input Validation

- Always validate cart additions with `woocommerce_add_to_cart_validation`
- Use proper nonce verification for AJAX operations
- Sanitize all user inputs before processing
- Check user capabilities before allowing actions

### Data Integrity

- Use WordPress options instead of filters for feature flags
- Implement proper error handling with WP_Error objects
- Validate product existence before operations
- Handle serialized data carefully

## Performance Considerations

### Hook Optimization

- Use appropriate hook priorities (10, 20, 30)
- Avoid excessive hook callbacks
- Process data efficiently in hook callbacks
- Cache expensive operations when possible

### Database Operations

- Use WooCommerce APIs instead of direct database queries
- Leverage WooCommerce caching mechanisms
- Batch operations when processing multiple items
- Clean up temporary data after operations

## Integration Patterns

### Plugin Development

- Follow WordPress coding standards
- Use proper prefixing for functions and classes
- Implement proper activation/deactivation hooks
- Handle plugin dependencies gracefully

### Theme Integration

- Use template hooks instead of direct template modifications
- Respect WooCommerce template hierarchy
- Test with both classic and block themes
- Provide fallbacks for unsupported features