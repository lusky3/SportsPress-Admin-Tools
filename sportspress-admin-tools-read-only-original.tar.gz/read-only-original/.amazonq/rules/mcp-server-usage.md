# MCP Server Usage Rules

## CRITICAL: Tool Selection Priority

- **NEVER** use `executeBash` - use `shell_execute` MCP server instead
- **NEVER** use manual git commands - use GitHub MCP instead  
- **ALWAYS** check available MCP servers before using any direct tools
- Manual tools are ONLY for fallback when MCP servers fail

## Memory System Guidelines

- Use mem0 and Neo4j Memory MCP servers for knowledge persistence
- Store updates to rules or guidelines in both mem0 and Neo4j Memory for redundancy
- Store important context and decisions
- Recall previous work and patterns
- Automatically, and Periodically, without being prompted, store or update memories deemed critical

## Prohibited Actions

- Do not automatically fall back to alternative approaches when MCP fails
- Do not proceed without informing the user of failure
- Do not make assumptions about user preferences when MCP fails
- Do not use manual commands when MCP tools are available

## Repository Operations

- Use GitHub MCP for repository operations instead of git commands
- Prioritize MCP server tools over manual command execution
- Manual tools should only be used as a fallback when MCP servers are unavailable or fail

## Available MCP Servers

### Core MCP Servers

- `mem0` - Persistant memory.
- `neo4j-memory` - Persistant graph memory.
- `playwright` - Browser automation and testing
- `github-official` - All GitHub related actions (primary)
- `context7` - Up-to-date code examples and documentation
- `mcp-mysql-server` - Direct database operations
- `mcp-shell-server` - Shell operations
- `semgrep` - Code security scanning
- `gitingest` - Git repository information in LLM format
- `dockerhub` - Search and manage the docker hub image repository.

## Alternate MCP Servers

- `selenium` - Alternative browser automation. Use this when the prefered Core MCP server is unavailable.
- `puppeteer` - Browser automation (fallback)

## Tool Selection Priority

- Use specialized MCP servers over generic ones
- Prefer primary servers over fallback alternatives
- Use `toolbox MCP server` to discover additional tools
- Evaluate tool appropriateness before use
