# e-Transfer Automation Module Rules

## Overview

The e-Transfer Automation module automatically processes Interac e-Transfer payments for WooCommerce orders by receiving webhook notifications when e-Transfer emails are received. Supports multiple service providers including generic webhooks, deliverhook.com, and Cloudflare Email Routing.

## Webhook Processing Flow

### 1. Email Reception
- Service provider forwards emails from `notify@payments.interac.ca` to webhook endpoint
- Webhook URL: `/wp-json/spat/v1/etransfer-webhook`
- HMAC SHA256 signature verification required
- Supports Generic, deliverhook.com, and Cloudflare Email Routing providers

### 2. Payment Data Extraction
- **Reference Number**: Extracted from email body pattern `Reference Number:\n\n{number}`
- **Amount**: Extracted from pattern `Amount:\n\n${amount} (CAD)`
- **Sender Name**: From email body `Sent From:\n\n{name}` or webhook header
- **Customer Email**: From `Reply-To` header (Generic/Cloudflare) or `From` header (deliverhook)
- **Order Number**: From email body `Message:\n\n{order_number}` (optional)

### 3. Order Matching Strategies (Priority Order)

#### Strategy 1: Order Number Match (Highest Priority)
- Looks for `ARL-{ID}` format in email message field
- Validates order exists, status is "on-hold", created before payment
- **Criteria**: `Order Number (ARL-{ID})`

#### Strategy 2: Reply-To Email Match ⭐ **Most Reliable**
- Uses customer's actual email from `Reply-To` header (not `notify@payments.interac.ca`)
- Matches to WooCommerce `billing_email`
- Filters: status="on-hold", created before payment timestamp
- Returns most recent matching order
- **Criteria**: `Reply-To Email ({email})`

#### Strategy 3: Customer Name Match (Fallback)
- Compares `sender_name` to `billing_first_name + billing_last_name`
- Case-insensitive comparison
- Searches last 10 "on-hold" orders
- **Criteria**: `Customer Name ({name})`

### 4. Payment Amount Validation
- **Exact Match**: Payment amount matches order total (within 1¢ tolerance)
- **Zero Amount Check**: Zero or negative amounts automatically rejected for manual review
- **Underpayment**: Payment less than order total → flagged for manual review
- **Overpayment**: Payment exceeds order total → flagged for manual review
- **Validation Logic**: Prevents automatic completion of mismatched amounts

### 5. Order Processing
- Sets transaction ID to reference number
- Adds order note with payment details
- Updates status from "on-hold" to "completed" (only if amount validates)
- Logs successful processing or validation failure

## Admin Interface

### Settings Location
- WordPress Admin → Settings → SportsPress Admin Tools → e-Transfer tab

### Configuration Fields
- **Service Provider**: Choose between Generic, deliverhook.com, or Cloudflare Email Routing
- **Webhook URL**: Auto-generated REST endpoint (read-only)
- **Webhook Secret**: HMAC SHA256 signing key (auto-generated or custom for deliverhook)

### Activity Log (Settings Page)
- **Columns**: Timestamp, From, Amount, Reference, Match Criteria, Order, Result
- **Storage**: Database table `wp_spat_etransfer_logs`
- **Features**: Color coding, order links, complete audit trail
- **Retention**: All records preserved for audit purposes

### Management Interface
- **Location**: WooCommerce → e-Transfer Webhooks
- **Purpose**: Handle unmatched payments requiring manual intervention
- **Notification Counter**: Shows pending unmatched webhooks in menu
- **Features**: Manual order matching, hide invalid records

## Management Features

### Unmatched Webhook Handling
- **Detection**: Webhooks with "No matching order found" result
- **Manual Matching**: Admin can manually link payments to orders
- **Order Selection**: Dropdown of "on-hold" orders for manual matching
- **Processing**: Automatically completes order when manually matched

### Notification System
- **Menu Counter**: Shows number of pending unmatched webhooks
- **Visual Indicator**: Uses WordPress standard notification styling
- **Real-time Updates**: Counter updates as webhooks are processed

### Record Management
- **Hide Functionality**: Remove invalid records from management view
- **Audit Preservation**: Hidden records remain in settings page logs
- **Confirmation**: JavaScript confirmation before hiding records
- **Security**: WordPress nonce verification for all actions

## Security

### Webhook Verification
- HMAC SHA256 signature in `X-Signature` header
- Validates against stored webhook secret
- Rejects unsigned or invalid requests

### Data Validation
- Verifies email is e-Transfer notification
- Validates payment data extraction
- Confirms order exists and is eligible

### Access Control
- Management page requires `manage_woocommerce` capability
- Settings page requires `manage_options` capability
- All form submissions use WordPress nonces

## Dependencies

### Required
- **WordPress**: 5.0+
- **WooCommerce**: Active and configured
- **Email Service**: One of the supported providers (Generic, deliverhook.com, or Cloudflare)

### Optional
- **SportsPress**: For sports-specific functionality

## Database Structure

### Storage Table: `wp_spat_etransfer_logs`
- **id**: Primary key
- **timestamp**: When webhook was received
- **from_email**: Sender email address
- **from_name**: Sender display name
- **amount**: Payment amount
- **reference_number**: e-Transfer reference
- **match_criteria**: How order was matched
- **order_id**: Linked WooCommerce order ID
- **result**: Processing result/status
- **webhook_data**: Serialized webhook payload
- **payment_data**: Serialized payment details

### Record States
- **Successful**: `order_id` set, result contains "successfully"
- **Unmatched**: `order_id` is NULL, result contains "No matching order"
- **Amount Mismatch**: `order_id` set, result contains "amount validation failed" or "requires manual review"
- **Hidden**: `result` equals "Hidden from management"
- **Manual**: `match_criteria` equals "Manual Match"

## Error Handling

### Common Failures
- **Invalid Signature**: Wrong webhook secret
- **Parse Error**: Email format not recognized
- **No Order Found**: No matching WooCommerce order
- **Order Ineligible**: Order not "on-hold" or created after payment
- **Amount Mismatch**: Payment amount doesn't match order total
- **Zero Amount**: Payment amount is zero or negative
- **Underpayment**: Payment less than order total
- **Overpayment**: Payment exceeds order total

### Logging
- All webhook attempts logged to database
- Failed attempts include error details
- Debug logging to WordPress error log
- Complete audit trail maintained

## Service Provider Configuration

### Generic Provider
- Configure your service to forward emails from `notify@payments.interac.ca`
- Send POST requests with JSON payload containing email data
- **Must include Reply-To header** in JSON payload for proper customer email matching
- Include X-Signature header with HMAC SHA256 signature

### deliverhook.com
- **Source**: `notify@payments.interac.ca`
- **Destination**: Plugin webhook URL
- **Format**: Automatic JSON conversion
- **Security**: Configure webhook secret in deliverhook Security tab

### Cloudflare Email Routing
- **Worker**: Custom Cloudflare Worker processes emails and extracts Reply-To header
- **Environment Variables**: WEBHOOK_URL, WEBHOOK_SECRET, FORWARD_EMAIL, SAFE_DOMAINS, DISABLE_INTERAC_CHECK
- **Routing**: Configure domain to forward emails to Worker
- **Reply-To Support**: Worker automatically parses Reply-To header for customer email
- **Debug Logging**: Worker logs comprehensive email data to Cloudflare console for troubleshooting
- **Flexible Domain Checking**: Support for custom sender domains and bypass options
- **Files**: Download worker code, config, and setup guide from plugin

## Best Practices

### Order Management
- Keep orders in "on-hold" status until payment received
- Use consistent customer email addresses
- Include order numbers in e-Transfer messages when possible
- Monitor notification counter for pending manual matches
- **Ensure order totals are accurate** before customers send payments

### Payment Validation
- **Review amount mismatches** promptly in management interface
- **Investigate underpayments** - may indicate customer confusion or partial payment
- **Handle overpayments** - consider refunds or credit adjustments
- **Document manual overrides** when processing mismatched amounts

### Monitoring
- Check management interface regularly for unmatched payments and amount mismatches
- Review settings page activity log for complete audit trail
- Verify webhook secret matches service provider configuration
- Monitor WordPress error log for processing issues
- **Use Cloudflare Worker logs** for email parsing troubleshooting

### Record Management
- Use hide function for invalid/spam webhooks
- Preserve audit trail by not deleting records
- Manually match legitimate payments that failed auto-matching
- **Process amount mismatches** through manual review workflow
- Regular cleanup of old hidden records if needed

### Testing
- Use test orders with "on-hold" status
- Test with actual e-Transfer email formats
- Verify signature calculation matches service provider
- Test manual matching workflow with unmatched webhooks
- **Test amount validation** with various payment scenarios
- **Verify email parsing** using Cloudflare Worker debug logs

## Troubleshooting

### No Orders Matched
1. Check Reply-To email matches billing email exactly (most common issue)
2. Verify order status is "on-hold"
3. Confirm order created before payment timestamp
4. Check activity log for match criteria attempted
5. For deliverhook: Uses From email instead of Reply-To
6. Use manual matching feature in management interface

### Amount Validation Issues
1. **Underpayment**: Check if customer sent partial payment
2. **Overpayment**: Verify if customer included tips or fees
3. **Currency Conversion**: Ensure amounts are in same currency
4. **Rounding Differences**: System allows 1¢ tolerance for rounding
5. **Manual Override**: Use management interface to process mismatched amounts

### Webhook Failures
1. Verify webhook secret matches your service provider
2. Check WordPress error log for signature issues
3. Confirm service provider is forwarding emails correctly
4. Test webhook endpoint accessibility
5. For Cloudflare: Check Worker logs and environment variables

### Data Extraction Issues
1. Verify email format matches expected patterns
2. Check for special characters in amounts/names
3. Confirm deliverhook payload structure
4. Review activity log for parsing errors

### Management Interface Issues
1. **Missing Notification Counter**: Check if unmatched webhooks exist
2. **Hidden Records Still Showing**: Clear browser cache
3. **Manual Match Fails**: Verify order is "on-hold" status
4. **Permission Errors**: Ensure user has `manage_woocommerce` capability