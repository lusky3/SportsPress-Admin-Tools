# Captain Role Feature

## Overview

The Captain Role feature allows you to designate a team captain in SportsPress player lists (rosters). The selected captain will display with a "C" indicator next to their name on the frontend.

## Setup

1. Go to **Settings → SportsPress Admin Tools → Player Modifications**
2. Enable the **Captain Role Selection** checkbox
3. Save settings

## Usage

### Selecting a Captain

1. Edit any SportsPress List (sp_list) in WordPress admin
2. Look for the **Captain Selection** meta box in the sidebar
3. Choose a captain from the dropdown (only players in the current list are shown)
4. Save the list

### Frontend Display

When viewing the list on the frontend, the selected captain will have a blue "C" indicator next to their name:

- **John Smith C** - Captain indicator appears after the player name
- Hover effect shows "Captain" tooltip
- Responsive design adapts to mobile screens

## Technical Details

### Database Storage

- Captain selection is stored as `spat_captain` meta field on the sp_list post
- Contains the player ID of the selected captain

### Hooks and Filters

- `sportspress_list_player_name` - Filter used to add captain indicator
- `spat_captain_indicator_text` - Filter to customize the captain text (default: "C")

### CSS Classes

- `.spat-captain-indicator` - Main styling class for the captain badge

## Customization

### Change Captain Text

```php
add_filter('spat_captain_indicator_text', function($text) {
    return '★'; // Use star instead of "C"
});
```

### Custom CSS

```css
.spat-captain-indicator {
    background: #ff6b35 !important; /* Orange background */
    color: white !important;
}
```

## Validation

- Only players actually in the list can be selected as captain
- Invalid selections are automatically removed
- Captain selection is validated on save

## Compatibility

- Works with all SportsPress list display formats
- Compatible with custom themes
- Responsive design for mobile devices

## Testing

Run the test file to verify functionality:
```
/tests/test-captain-functionality.php
```

This will check:
- Module enablement
- Available lists and players
- Current captain selections