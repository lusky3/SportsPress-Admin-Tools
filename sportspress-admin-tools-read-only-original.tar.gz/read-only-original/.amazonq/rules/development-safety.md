# Development Safety Rules

## Destructive Action Confirmation

- ALWAYS confirm with user before:
  - Deleting files or data
  - Modifying database structure
  - Changing user permissions
  - Updating production-like environments

## Data Integrity Protection

- Backup before major changes
- Validate data before operations
- Use WordPress transactional patterns
- Test changes in safe environments

## API Usage Priority

1. **Primary**: WordPress and SportsPress APIs
2. **Secondary**: SportsPress REST API
3. **Tertiary**: Direct database queries (only when necessary)
4. **Never**: Bypass WordPress security or data validation

## Code Quality Standards

- Follow WordPress coding standards
- Use proper error handling
- Implement comprehensive logging
- Document complex operations

## Performance Guidelines

- Use efficient WordPress queries
- Implement proper caching strategies
- Optimize database operations
- Monitor memory usage

## Security Requirements

- Validate all inputs
- Use WordPress nonces for AJAX
- Implement proper capability checks
- Sanitize outputs
