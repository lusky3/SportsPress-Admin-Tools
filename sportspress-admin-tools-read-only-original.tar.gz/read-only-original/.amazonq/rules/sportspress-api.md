# SportsPress API Reference for LLM Development

## Overview

SportsPress is a comprehensive WordPress plugin for managing sports data. This document provides detailed API information for Large Language Models to understand and work with SportsPress data structures, functions, and best practices.

## Core Data Structure

### Post Types

SportsPress uses WordPress custom post types for all major entities:

- `sp_player` - Individual players/athletes
- `sp_team` - Teams/clubs
- `sp_event` - Games/matches/events
- `sp_calendar` - Event calendars
- `sp_table` - League tables/standings
- `sp_list` - Player lists/rosters
- `sp_staff` - Staff members (coaches, managers)
- `sp_venue` - Venues/stadiums

### Taxonomies

SportsPress organizes data using WordPress taxonomies:

- `sp_league` - Leagues/competitions
- `sp_season` - Seasons/years
- `sp_position` - Player positions
- `sp_role` - Staff roles
- `sp_venue` - Venue categories

## Player Management

### Player Data Structure

```php
// Get player post
$player = get_post($player_id);

// Player meta fields
$player_number = get_post_meta($player_id, 'sp_number', true);
$player_nationality = get_post_meta($player_id, 'sp_nationality', true);
$player_current_team = get_post_meta($player_id, 'sp_current_team', true);
$player_past_team = get_post_meta($player_id, 'sp_past_team', true);
```

### Critical Player Meta Keys

- `sp_number` - Player jersey number
- `sp_nationality` - Player nationality (array of country codes)
- `sp_current_team` - Current team ID(s)
- `sp_past_team` - Past team ID(s)
- `sp_statistics` - Player statistics (serialized array)
- `sp_assignments` - Event assignments (links to games)
- `sp_leagues` - League participation data
- `sp_columns` - Display columns configuration
- `sp_metrics` - Physical metrics (height, weight, etc.)

### Player Statistics System

```php
// Statistics are stored as nested arrays
$statistics = get_post_meta($player_id, 'sp_statistics', true);
// Structure: [league_id][event_id][stat_key] = value

// Example structure:
$stats = [
    5 => [ // League ID
        0 => [ // Overall stats
            'g' => '10',    // Goals
            'a' => '5',     // Assists
            'gp' => '20',   // Games played
            'pim' => '15'   // Penalty minutes
        ],
        123 => [ // Specific event ID
            'g' => '1',
            'a' => '0',
            'gp' => '1'
        ]
    ]
];
```

### Player Assignments

```php
// Assignments link players to league-season-team combinations
$assignments = get_post_meta($player_id, 'sp_assignments');
// Format: [league_id]_[season_id]_[team_id]

// Example: "5_123_456" means:
// - League ID: 5
// - Season ID: 123  
// - Team ID: 456
```

## Team Management

### Team Data Structure

```php
// Get team data
$team = get_post($team_id);
$team_abbreviation = get_post_meta($team_id, 'sp_abbreviation', true);
$team_logo = get_post_meta($team_id, 'sp_logo', true);
```

### Team Meta Keys

- `sp_abbreviation` - Team abbreviation/short name
- `sp_logo` - Team logo attachment ID
- `sp_venue` - Home venue ID
- `sp_columns` - Display columns for team stats
- `sp_statistics` - Team statistics

## Event Management

### Event Data Structure

```php
// Event represents a game/match
$event = get_post($event_id);
$event_date = get_post_meta($event_id, 'sp_date', true);
$event_time = get_post_meta($event_id, 'sp_time', true);
$event_venue = get_post_meta($event_id, 'sp_venue', true);
```

### Event Meta Keys

- `sp_date` - Event date (Y-m-d format)
- `sp_time` - Event time (H:i format)
- `sp_venue` - Venue ID
- `sp_format` - Event format
- `sp_mode` - Event mode (team vs individual)
- `sp_status` - Event status (scheduled, live, completed)
- `sp_results` - Event results (team scores)
- `sp_players` - Player performance data

### Event Results Structure

```php
$results = get_post_meta($event_id, 'sp_results', true);
// Structure: [team_id] => ['outcome' => result]
// Outcomes: 'win', 'loss', 'draw'

$players = get_post_meta($event_id, 'sp_players', true);
// Structure: [team_id][player_id] => [performance_data]
```

## Statistics and Performance

### Statistics Configuration

```php
// Get configured statistics for a post type
$columns = get_post_meta($post_id, 'sp_columns', true);
// Returns array of enabled statistic keys

// Common statistic keys:
// 'g' - Goals
// 'a' - Assists  
// 'gp' - Games Played
// 'pim' - Penalty Minutes
// 'p' - Points
// '+/-' - Plus/Minus
```

### Calculating Statistics

```php
// SportsPress calculates stats from event assignments
// Statistics are derived from sp_assignments and event performance data
// Use SportsPress classes for calculations:

if (class_exists('SP_Player')) {
    $player_obj = new SP_Player($player_id);
    $stats = $player_obj->statistics();
}
```

## Taxonomies and Terms

### Working with SportsPress Taxonomies

```php
// Get player's leagues
$leagues = wp_get_object_terms($player_id, 'sp_league');

// Get player's positions
$positions = wp_get_object_terms($player_id, 'sp_position');

// Get player's seasons
$seasons = wp_get_object_terms($player_id, 'sp_season');

// Assign terms to player
wp_set_object_terms($player_id, [1, 2, 3], 'sp_league');
```

### Term Relationships

```php
// Teams can be assigned via taxonomy or meta
// Taxonomy method (preferred):
wp_set_object_terms($player_id, [$team_id], 'sp_team');

// Meta method (legacy):
add_post_meta($player_id, 'sp_current_team', $team_id);
```

## Data Relationships

### Player-Team Relationships

```php
// Current team (active)
$current_teams = get_post_meta($player_id, 'sp_current_team');

// Past teams (historical)
$past_teams = get_post_meta($player_id, 'sp_past_team');

// Team taxonomy (modern approach)
$team_terms = wp_get_object_terms($player_id, 'sp_team');
```

### Player-Event Relationships

```php
// Events are linked via assignments
$assignments = get_post_meta($player_id, 'sp_assignments');

// Each assignment format: league_season_team
foreach ($assignments as $assignment) {
    list($league_id, $season_id, $team_id) = explode('_', $assignment);
    // Process assignment
}
```

## Database Queries

### Efficient Player Queries

```php
// Get all players
$players = get_posts([
    'post_type' => 'sp_player',
    'posts_per_page' => -1,
    'post_status' => 'publish'
]);

// Get players by team
$team_players = get_posts([
    'post_type' => 'sp_player',
    'meta_query' => [
        [
            'key' => 'sp_current_team',
            'value' => $team_id,
            'compare' => '='
        ]
    ]
]);

// Get players by league (taxonomy)
$league_players = get_posts([
    'post_type' => 'sp_player',
    'tax_query' => [
        [
            'taxonomy' => 'sp_league',
            'field' => 'term_id',
            'terms' => $league_id
        ]
    ]
]);
```

### Meta Query Examples

```php
// Players with specific statistics
$players_with_goals = get_posts([
    'post_type' => 'sp_player',
    'meta_query' => [
        [
            'key' => 'sp_statistics',
            'value' => 'goals',
            'compare' => 'LIKE'
        ]
    ]
]);

// Players by number
$player_by_number = get_posts([
    'post_type' => 'sp_player',
    'meta_query' => [
        [
            'key' => 'sp_number',
            'value' => '10',
            'compare' => '='
        ]
    ]
]);
```

## SportsPress Classes

### Core Classes

```php
// Player class
if (class_exists('SP_Player')) {
    $player = new SP_Player($player_id);
    $stats = $player->statistics();
    $events = $player->events();
}

// Team class  
if (class_exists('SP_Team')) {
    $team = new SP_Team($team_id);
    $players = $team->players();
}

// Event class
if (class_exists('SP_Event')) {
    $event = new SP_Event($event_id);
    $results = $event->results();
}
```

### Using SportsPress Functions

```php
// Get formatted statistics
$formatted_stats = sp_get_player_statistics($player_id);

// Get player events
$player_events = sp_get_player_events($player_id);

// Get team players
$team_players = sp_get_team_players($team_id);
```

## Data Validation and Sanitization

### Input Validation

```php
// Validate player ID
if (!get_post($player_id) || get_post_type($player_id) !== 'sp_player') {
    // Invalid player
}

// Validate team ID
if (!get_post($team_id) || get_post_type($team_id) !== 'sp_team') {
    // Invalid team
}

// Validate statistics data
$stats = get_post_meta($player_id, 'sp_statistics', true);
if (!is_array($stats)) {
    $stats = [];
}
```

### Data Sanitization

```php
// Sanitize player number
$number = sanitize_text_field($_POST['player_number']);
$number = intval($number);

// Sanitize statistics
$goals = intval($_POST['goals']);
$assists = intval($_POST['assists']);

// Validate and sanitize meta arrays
$statistics = [];
if (isset($_POST['statistics']) && is_array($_POST['statistics'])) {
    foreach ($_POST['statistics'] as $key => $value) {
        $statistics[sanitize_key($key)] = sanitize_text_field($value);
    }
}
```

## Common Operations

### Adding a New Player

```php
// Create player post
$player_id = wp_insert_post([
    'post_type' => 'sp_player',
    'post_title' => 'Player Name',
    'post_status' => 'publish'
]);

// Add player meta
add_post_meta($player_id, 'sp_number', 10);
add_post_meta($player_id, 'sp_current_team', $team_id);

// Assign taxonomies
wp_set_object_terms($player_id, [$league_id], 'sp_league');
wp_set_object_terms($player_id, [$position_id], 'sp_position');
```

### Updating Player Statistics

```php
// Get existing statistics
$stats = get_post_meta($player_id, 'sp_statistics', true);
if (!is_array($stats)) {
    $stats = [];
}

// Update league statistics
if (!isset($stats[$league_id])) {
    $stats[$league_id] = [];
}

$stats[$league_id][0] = [ // Overall stats
    'g' => '15',  // Goals
    'a' => '8',   // Assists
    'gp' => '25'  // Games played
];

// Save updated statistics
update_post_meta($player_id, 'sp_statistics', $stats);
```

### Managing Player Assignments

```php
// Add player assignment (league-season-team)
$assignment = $league_id . '_' . $season_id . '_' . $team_id;
add_post_meta($player_id, 'sp_assignments', $assignment);

// Remove player assignment
delete_post_meta($player_id, 'sp_assignments', $assignment);

// Get all player assignments
$assignments = get_post_meta($player_id, 'sp_assignments');
```

## Performance Considerations

### Efficient Data Access

```php
// Use get_posts() for multiple items
$players = get_posts([
    'post_type' => 'sp_player',
    'numberposts' => 50,
    'fields' => 'ids' // Only get IDs if that's all you need
]);

// Batch meta queries
$meta_values = get_post_meta($player_id); // Get all meta at once

// Use taxonomy queries for term-based filtering
$args = [
    'post_type' => 'sp_player',
    'tax_query' => [
        [
            'taxonomy' => 'sp_league',
            'field' => 'term_id',
            'terms' => $league_ids
        ]
    ]
];
```

### Caching Strategies

```php
// Use WordPress transients for expensive queries
$cache_key = 'sp_team_' . $team_id . '_players';
$players = get_transient($cache_key);

if (false === $players) {
    $players = get_posts([
        'post_type' => 'sp_player',
        'meta_query' => [
            [
                'key' => 'sp_current_team',
                'value' => $team_id
            ]
        ]
    ]);
    set_transient($cache_key, $players, HOUR_IN_SECONDS);
}
```

## Error Handling

### Common Error Patterns

```php
// Check if SportsPress is active
if (!class_exists('SportsPress')) {
    wp_die('SportsPress plugin is required');
}

// Validate post exists and is correct type
$player = get_post($player_id);
if (!$player || $player->post_type !== 'sp_player') {
    return new WP_Error('invalid_player', 'Invalid player ID');
}

// Handle missing meta data gracefully
$stats = get_post_meta($player_id, 'sp_statistics', true);
if (empty($stats) || !is_array($stats)) {
    $stats = [];
}
```

### Data Integrity Checks

```php
// Verify team exists before assignment
if (!get_post($team_id) || get_post_type($team_id) !== 'sp_team') {
    return false;
}

// Validate assignment format
if (!preg_match('/^\d+_\d+_\d+$/', $assignment)) {
    return false;
}

// Check for duplicate assignments
$existing = get_post_meta($player_id, 'sp_assignments');
if (in_array($assignment, $existing)) {
    return false; // Already assigned
}
```

## Best Practices for LLM Development

### Always Use WordPress APIs

```php
// Correct: Use WordPress functions
$players = get_posts(['post_type' => 'sp_player']);

// Incorrect: Direct database queries
// $players = $wpdb->get_results("SELECT * FROM wp_posts WHERE post_type = 'sp_player'");
```

### Respect Data Relationships

```php
// When updating player data, consider all relationships
function update_player_team($player_id, $new_team_id) {
    // Update current team
    update_post_meta($player_id, 'sp_current_team', $new_team_id);
    
    // Update taxonomy
    wp_set_object_terms($player_id, [$new_team_id], 'sp_team');
    
    // Clear statistics cache if needed
    delete_transient('sp_player_' . $player_id . '_stats');
}
```

### Handle Serialized Data Properly

```php
// SportsPress uses serialized arrays extensively
$stats = get_post_meta($player_id, 'sp_statistics', true);
$stats = maybe_unserialize($stats);

// Always validate structure
if (!is_array($stats)) {
    $stats = [];
}

// Update and save
$stats[$league_id][0]['g'] = $goals;
update_post_meta($player_id, 'sp_statistics', $stats);
```

## Summary

SportsPress provides a comprehensive sports management system built on WordPress. Key points for LLM development:

1. **Use WordPress APIs** - Always prefer WordPress functions over direct database access
2. **Understand data relationships** - Players, teams, events, and statistics are interconnected
3. **Handle serialized data carefully** - Many SportsPress fields store complex arrays
4. **Validate data integrity** - Always check post types and data structure
5. **Consider performance** - Use efficient queries and caching for large datasets
6. **Respect taxonomies** - Use WordPress taxonomy functions for term management

The SportsPress API is extensive and powerful when used correctly. Always test thoroughly and follow WordPress coding standards.


## Player Statistics Configuration

### Enabling Frontend Statistics Display

To properly configure a player for frontend statistics display, four components must be correctly set:

1. **sp_columns**: Array of enabled statistic columns (e.g., ['0', 'g', 'a', 'pim', '0', 'p', 'gp'])
2. **sp_assignments**: String format assignments matching sp_leagues data (e.g., 'league_season_team')  
3. **sp_statistics**: Nested array structure with empty stat arrays for each league/season
4. **sp_leagues**: Controls team dropdowns and links statistics to team context

### Critical Implementation Details

- **Use existing sp_leagues data**: Never use arbitrary first available league/season
- **Assignment format**: String format 'league_season_team' (e.g., '2_647_10652')
- **Team handling**: Use sp_current_team when sp_leagues shows -1 or empty team
- **Statistics structure**: Include overall stats (index 0) for each league
- **Division stats**: Require matching sp_assignments and sp_leagues data
- **sp_leagues critical**: Must update sp_leagues to set proper team IDs, not just create sp_assignments

### Key Discovery: sp_leagues Controls Team Display

The `sp_leagues` meta field controls the team dropdown in statistics sections:
- Format: `[league_id][season_id] = team_id`
- When team_id = -1, dropdown shows "— None —" and statistics don't display
- When team_id = actual_team_id, dropdown shows team name and statistics calculate properly
- Creating sp_assignments alone is insufficient - sp_leagues must be updated to match

### Common Mistakes

- Creating assignments with arbitrary league/season instead of player's actual data
- Using array format for assignments instead of string format
- Mismatched league/season data between sp_assignments and sp_leagues
- Missing overall statistics (index 0) entries
- **Critical**: Creating sp_assignments but not updating sp_leagues team IDs from -1 to actual team
