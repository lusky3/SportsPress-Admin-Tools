<?php
/**
 * League Table Generator Module
 * 
 * @author Cody (lusky3)
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    wp_die();
}

// Include text helper if not already loaded
if (!class_exists('SPAT_Text_Helper')) {
    require_once SPAT_PLUGIN_PATH . 'includes/class-text-helper.php';
}

class SPAT_League_Table_Generator {
    
    public function __construct() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('load-edit.php', array($this, 'add_generate_button'));
        add_action('wp_ajax_spat_generate_tables', array($this, 'ajax_generate_tables'));
    }
    
    public function enqueue_scripts($hook) {
        if ($hook === 'edit.php' && isset($_GET['post_type']) && sanitize_key($_GET['post_type']) === 'sp_table') {
            wp_enqueue_script('jquery');
            wp_enqueue_script('jquery-ui-dialog');
            wp_enqueue_style('wp-jquery-ui-dialog');
        }
    }
    
    public function add_generate_button() {
        if (isset($_GET['post_type']) && sanitize_key($_GET['post_type']) === 'sp_table') {
            add_action('admin_footer', array($this, 'render_modal_and_button'));
        }
    }
    
    public function render_modal_and_button() {
        $teams = get_posts(array('post_type' => 'sp_team', 'posts_per_page' => -1, 'post_status' => 'publish'));
        
        // Sort teams alphabetically with special characters at bottom
        usort($teams, function($a, $b) {
            $a_starts_special = preg_match('/^[^a-zA-Z]/', $a->post_title);
            $b_starts_special = preg_match('/^[^a-zA-Z]/', $b->post_title);
            
            if ($a_starts_special && !$b_starts_special) return 1;
            if (!$a_starts_special && $b_starts_special) return -1;
            
            return strcasecmp($a->post_title, $b->post_title);
        });
        $seasons = get_terms(array('taxonomy' => 'sp_season', 'hide_empty' => false));
        $leagues = get_terms(array('taxonomy' => 'sp_league', 'hide_empty' => false));
        $current_season = get_option('sportspress_season', '');
        ?>
        <script>
        var leagues = <?php echo json_encode(array_map(function($league) {
            return array('id' => $league->term_id, 'name' => $league->name);
        }, $leagues)); ?>;
        
        jQuery(document).ready(function($) {
            // Add button
            $('.page-title-action').after('<a href="#" id="generate-tables-btn" class="page-title-action"><?php printf(__('Generate %s Tables', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('League')); ?></a>');
            
            // Initialize modal
            $("#generate-tables-modal").dialog({
                autoOpen: false,
                modal: true,
                width: 600,
                height: 500
            });
            
            // Button click handler
            $("#generate-tables-btn").click(function(e) {
                e.preventDefault();
                $("#generate-tables-modal").dialog("open");
            });
            
            // Add team handler
            $("#add-team-btn").click(function() {
                var teamId = $("#team-select").val();
                var teamName = $("#team-select option:selected").text();
                
                if (!teamId) return;
                
                var leagueOptions = "";
                leagues.forEach(function(league) {
                    leagueOptions += "<option value=\"" + league.id + "\">" + league.name + "</option>";
                });
                
                var row = "<tr data-team-id=\"" + teamId + "\">" +
                    "<td>" + teamName + "</td>" +
                    "<td><select class=\"division-select\">" + leagueOptions + "</select></td>" +
                    "<td><button type=\"button\" class=\"button remove-team\">Remove</button></td>" +
                    "</tr>";
                
                $("#teams-table tbody").append(row);
                $("#team-select").val("");
            });
            
            // Remove team handler
            $(document).on("click", ".remove-team", function() {
                $(this).closest("tr").remove();
            });
            
            // Generate tables handler
            $("#generate-btn").click(function() {
                var seasonId = $("#season-select").val();
                var teams = [];
                
                $("#teams-table tbody tr").each(function() {
                    teams.push({
                        team_id: $(this).data("team-id"),
                        league_id: $(this).find(".division-select").val()
                    });
                });
                
                if (teams.length === 0) {
                    alert("<?php printf(__('Please add at least one %s.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Team'))); ?>");
                    return;
                }
                
                $.post(ajaxurl, {
                    action: "spat_generate_tables",
                    season_id: seasonId,
                    teams: teams,
                    nonce: "<?php echo wp_create_nonce('spat_generate_tables'); ?>"
                }, function(response) {
                    if (response.success) {
                        alert("<?php printf(__('%s tables generated successfully!', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('League')); ?>");
                        location.reload();
                    } else {
                        alert("<?php _e('Error:', 'sportspress-admin-tools'); ?> " + response.data);
                    }
                });
            });
        });
        </script>
        
        <style>
        .ui-dialog-titlebar-close {
            overflow: hidden !important;
        }
        .ui-dialog-titlebar-close .ui-button-icon-space + * {
            display: none !important;
        }
        </style>
        
        <div id="generate-tables-modal" title="<?php printf(__('Generate %s Tables', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('League')); ?>" style="display:none;">
            <div style="margin-bottom:20px;">
                <label><?php SPAT_Text_Helper::echo_text('Season'); ?>: </label>
                <select id="season-select">
                    <?php foreach ($seasons as $season): ?>
                        <option value="<?php echo $season->term_id; ?>" <?php selected($season->term_id, $current_season); ?>>
                            <?php echo esc_html($season->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div style="margin-bottom:20px;">
                <label><?php printf(__('Add %s:', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Team')); ?> </label>
                <select id="team-select">
                    <option value=""><?php printf(__('Select %s', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Team')); ?></option>
                    <?php foreach ($teams as $team): ?>
                        <option value="<?php echo $team->ID; ?>"><?php echo esc_html($team->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="button" id="add-team-btn" class="button"><?php printf(__('Add %s', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Team')); ?></button>
            </div>
            
            <table id="teams-table" class="wp-list-table widefat fixed striped" style="margin-bottom:20px;">
                <thead>
                    <tr>
                        <th><?php SPAT_Text_Helper::echo_text('Team'); ?></th>
                        <th>Division</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
            
            <button type="button" id="generate-btn" class="button button-primary"><?php _e('Generate Tables', 'sportspress-admin-tools'); ?></button>
        </div>

        <?php
    }
    

    
    public function ajax_generate_tables() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        if (!wp_verify_nonce($_POST['nonce'], 'spat_generate_tables')) {
            wp_send_json_error('Security check failed');
        }
        
        $season_id = intval($_POST['season_id']);
        $teams = $_POST['teams'];
        
        $season = get_term($season_id, 'sp_season');
        if (!$season) {
            wp_send_json_error('Invalid season');
        }
        
        $leagues_used = array();
        
        // Update team associations
        foreach ($teams as $team_data) {
            $team_id = intval($team_data['team_id']);
            $league_id = intval($team_data['league_id']);
            
            $leagues_used[$league_id] = get_term($league_id, 'sp_league');
            
            // Associate team with season and league
            wp_set_object_terms($team_id, array($season_id), 'sp_season', true);
            wp_set_object_terms($team_id, array($league_id), 'sp_league', true);
        }
        
        $created_tables = array();
        
        // Generate tables for each league
        foreach ($leagues_used as $league_id => $league) {
            // Create main season table
            $main_table_id = $this->create_league_table($league->name . ' | ' . $season->name, $season_id, $league_id);
            $created_tables[] = $main_table_id;
            
            // Create playoff table
            $playoff_season_name = $season->name . ' Playoffs';
            $playoff_season = get_term_by('name', $playoff_season_name, 'sp_season');
            
            if (!$playoff_season) {
                $playoff_result = wp_insert_term($playoff_season_name, 'sp_season');
                if (!is_wp_error($playoff_result)) {
                    $playoff_season_id = $playoff_result['term_id'];
                } else {
                    continue;
                }
            } else {
                $playoff_season_id = $playoff_season->term_id;
            }
            
            $playoff_table_id = $this->create_league_table($league->name . ' | ' . $playoff_season_name, $playoff_season_id, $league_id);
            $created_tables[] = $playoff_table_id;
            
            // Associate teams with tables
            foreach ($teams as $team_data) {
                if (intval($team_data['league_id']) === $league_id) {
                    $team_id = intval($team_data['team_id']);
                    
                    // Clear existing sp_table values and add new ones
                    delete_post_meta($team_id, 'sp_table');
                    add_post_meta($team_id, 'sp_table', $main_table_id);
                    add_post_meta($team_id, 'sp_table', $playoff_table_id);
                    
                    // Associate teams with playoff season
                    wp_set_object_terms($team_id, array($playoff_season_id), 'sp_season', true);
                }
            }
        }
        
        wp_send_json_success(sprintf(__('Generated %d %s tables', 'sportspress-admin-tools'), count($created_tables), strtolower(SPAT_Text_Helper::get_text('League'))));
    }
    
    private function create_league_table($title, $season_id, $league_id) {
        $table_id = wp_insert_post(array(
            'post_type' => 'sp_table',
            'post_title' => $title,
            'post_status' => 'publish'
        ));
        
        if ($table_id) {
            // Set table metadata (matching working table)
            update_post_meta($table_id, 'sp_select', 'manual');
            update_post_meta($table_id, 'sp_mode', 'team');
            update_post_meta($table_id, 'sp_format', 'standings');
            update_post_meta($table_id, 'sp_caption', '');
            update_post_meta($table_id, 'sp_highlight', 0);
            update_post_meta($table_id, 'sp_order', 'ASC');
            update_post_meta($table_id, 'sp_orderby', 'default');
            
            // Associate with season and league
            wp_set_object_terms($table_id, array($season_id), 'sp_season');
            wp_set_object_terms($table_id, array($league_id), 'sp_league');
            
            // Get teams for this league from the request
            $teams = $_POST['teams'];
            $team_ids = array();
            
            foreach ($teams as $team_data) {
                if (intval($team_data['league_id']) === $league_id) {
                    $team_ids[] = intval($team_data['team_id']);
                }
            }
            
            // Associate teams with table and initialize data structure
            if (!empty($team_ids)) {
                // Add each team as separate meta entries
                update_post_meta($table_id, 'sp_team', 0); // First entry is 0
                foreach ($team_ids as $team_id) {
                    add_post_meta($table_id, 'sp_team', $team_id);
                }
                
                // Set columns (hockey format based on working table)
                $columns = array('gp', 'w', 'l', 'tie', 'ot', 'pts', 'gf', 'ga', 'diff', 'lten', 'strk');
                update_post_meta($table_id, 'sp_columns', $columns);
                
                // Initialize sp_teams structure
                $teams_data = array();
                foreach ($team_ids as $team_id) {
                    $teams_data[$team_id] = array(
                        'name' => '',
                        'gp' => '',
                        'w' => '',
                        'l' => '',
                        'tie' => '',
                        'ot' => '',
                        'pts' => '',
                        'gf' => '',
                        'ga' => '',
                        'diff' => '',
                        'lten' => '',
                        'strk' => ''
                    );
                }
                update_post_meta($table_id, 'sp_teams', $teams_data);
                
                // Initialize sp_adjustments structure
                $adjustments = array();
                foreach ($team_ids as $team_id) {
                    $adjustments[$team_id] = array(
                        'gp' => '',
                        'w' => '',
                        'l' => '',
                        'tie' => '',
                        'ot' => '',
                        'pts' => '',
                        'gf' => '',
                        'ga' => '',
                        'diff' => '',
                        'lten' => '',
                        'strk' => ''
                    );
                }
                update_post_meta($table_id, 'sp_adjustments', $adjustments);
            }
        }
        
        return $table_id;
    }
}