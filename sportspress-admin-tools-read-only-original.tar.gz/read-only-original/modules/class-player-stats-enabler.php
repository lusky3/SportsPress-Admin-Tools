<?php
/**
 * Player Stats Enabler Module
 * 
 * Automatically enables frontend statistics display for SportsPress players
 * 
 * @author Cody (lusky3)
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    wp_die();
}

class SPAT_Player_Stats_Enabler {
    
    public function __construct() {
        // Hook into player save to enable stats
        add_action('save_post_sp_player', array($this, 'enable_player_stats'), 10, 2);
    }
    
    public function enable_player_stats($post_id, $post) {
        // Skip if this is an autosave or revision
        if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
            return;
        }
        
        // Check if auto-enable is enabled
        if (get_option('spat_player_stats_auto_enable', '1') !== '1') {
            return;
        }
        
        $this->setup_player_columns($post_id);
        $this->setup_player_assignments($post_id);
    }
    
    private function setup_player_columns($player_id) {
        // Check if columns are properly configured
        $existing_columns = get_post_meta($player_id, 'sp_columns', true);
        if (!empty($existing_columns) && is_array($existing_columns)) {
            $has_stats = false;
            foreach ($existing_columns as $col) {
                if ($col !== '0' && !empty($col)) {
                    $has_stats = true;
                    break;
                }
            }
            if ($has_stats) {
                return; // Already properly configured
            }
        }
        
        // Determine if player is skater or goalie
        $positions = wp_get_object_terms($player_id, 'sp_position');
        $is_goalie = false;
        
        foreach ($positions as $position) {
            if (strtolower($position->name) === 'goalie') {
                $is_goalie = true;
                break;
            }
        }
        
        // Set columns based on position
        if ($is_goalie) {
            // Goalie columns: Performance (G, A, PIM, GA) + Statistics (P, GP, GAA)
            $columns = array('0', 'g', 'a', 'pim', 'ga', '0', 'p', 'gp', 'gaa');
        } else {
            // Skater columns: Performance (G, A, PIM) + Statistics (P, GP)
            $columns = array('0', 'g', 'a', 'pim', '0', 'p', 'gp');
        }
        
        update_post_meta($player_id, 'sp_columns', $columns);
    }
    
    private function setup_player_assignments($player_id) {
        // Initialize statistics structure
        $statistics = get_post_meta($player_id, 'sp_statistics', true);
        if (!is_array($statistics)) {
            $statistics = array();
        }
        
        // Get player's existing assignments
        $assignments = get_post_meta($player_id, 'sp_assignments');
        
        if (!empty($assignments)) {
            // Process each assignment to create statistics structure
            foreach ($assignments as $assignment) {
                // Handle both array and string assignment formats
                if (is_array($assignment)) {
                    if (count($assignment) !== 3) {
                        continue;
                    }
                    list($league_id, $season_id, $team_id) = $assignment;
                } else {
                    // Parse string assignment: league_season_team
                    $parts = explode('_', $assignment);
                    if (count($parts) !== 3) {
                        continue;
                    }
                    list($league_id, $season_id, $team_id) = $parts;
                }
                
                // Ensure league exists in statistics
                if (!isset($statistics[$league_id])) {
                    $statistics[$league_id] = array();
                }
                
                // Add overall stats (index 0) and season stats
                $empty_stats = $this->get_empty_stats_array($player_id);
                
                if (!isset($statistics[$league_id][0])) {
                    $statistics[$league_id][0] = $empty_stats;
                }
                
                if (!isset($statistics[$league_id][$season_id])) {
                    $statistics[$league_id][$season_id] = $empty_stats;
                }
            }
        } else {
            // No assignments, create from sp_leagues data
            $leagues_data = get_post_meta($player_id, 'sp_leagues', true);
            $current_team = get_post_meta($player_id, 'sp_current_team', true);
            
            if (!empty($leagues_data) && is_array($leagues_data)) {
                foreach ($leagues_data as $league_id => $seasons) {
                    // Skip league 0 as it's typically invalid/duplicate data
                    if ($league_id == 0) {
                        continue;
                    }
                    
                    if (is_array($seasons)) {
                        foreach ($seasons as $season_id => $team_id) {
                            // Use current team if team_id is -1 or invalid
                            $team = ($team_id == -1 || empty($team_id)) ? $current_team : $team_id;
                            
                            // Create assignment: league_season_team format
                            $assignment = $league_id . '_' . $season_id . '_' . $team;
                            add_post_meta($player_id, 'sp_assignments', $assignment);
                            
                            // Update sp_leagues to set proper team ID
                            if ($team_id == -1 || empty($team_id)) {
                                $leagues_data[$league_id][$season_id] = $current_team;
                            }
                            
                            // Ensure league exists in statistics
                            if (!isset($statistics[$league_id])) {
                                $statistics[$league_id] = array();
                            }
                            
                            $empty_stats = $this->get_empty_stats_array($player_id);
                            
                            if (!isset($statistics[$league_id][0])) {
                                $statistics[$league_id][0] = $empty_stats;
                            }
                            
                            if (!isset($statistics[$league_id][$season_id])) {
                                $statistics[$league_id][$season_id] = $empty_stats;
                            }
                        }
                    }
                }
                
                // Update sp_leagues with corrected team IDs
                update_post_meta($player_id, 'sp_leagues', $leagues_data);
            }
        }
        
        update_post_meta($player_id, 'sp_statistics', $statistics);
    }
    
    private function get_empty_stats_array($player_id) {
        // Determine if player is goalie
        $positions = wp_get_object_terms($player_id, 'sp_position');
        $is_goalie = false;
        
        foreach ($positions as $position) {
            if (strtolower($position->name) === 'goalie') {
                $is_goalie = true;
                break;
            }
        }
        
        if ($is_goalie) {
            return array(
                'g' => '',
                'a' => '',
                'pim' => '',
                'ga' => '',
                'p' => '',
                'gp' => '',
                'gaa' => ''
            );
        } else {
            return array(
                'g' => '',
                'a' => '',
                'pim' => '',
                'p' => '',
                'gp' => ''
            );
        }
    }
    
    public function bulk_enable_stats() {
        // Get all players
        $players = get_posts(array(
            'post_type' => 'sp_player',
            'post_status' => 'publish',
            'posts_per_page' => -1
        ));
        
        $processed = 0;
        
        foreach ($players as $player) {
            // Check if columns are properly configured
            $existing_columns = get_post_meta($player->ID, 'sp_columns', true);
            
            // Skip if already properly configured (has actual stat columns)
            if (!empty($existing_columns) && is_array($existing_columns)) {
                $has_stats = false;
                foreach ($existing_columns as $col) {
                    if ($col !== '0' && !empty($col)) {
                        $has_stats = true;
                        break;
                    }
                }
                if ($has_stats) {
                    continue;
                }
            }
            
            $this->setup_player_columns($player->ID);
            $this->setup_player_assignments($player->ID);
            $processed++;
        }
        
        return $processed;
    }
}