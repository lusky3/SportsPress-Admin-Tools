<?php
/**
 * Events Management Module
 * 
 * @author Cody (lusky3)
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    wp_die();
}

// Include text helper if not already loaded
if (!class_exists('SPAT_Text_Helper')) {
    require_once SPAT_PLUGIN_PATH . 'includes/class-text-helper.php';
}

class SPAT_Events_Management {
    
    public function __construct() {
        add_action('admin_init', array($this, 'handle_admin_actions'));
        add_action('save_post', array($this, 'auto_create_calendar'));
        add_action('wp_ajax_spat_reset_calendars', array($this, 'ajax_reset_calendars'));
        add_action('wp_ajax_spat_import_events', array($this, 'ajax_import_events'));
        
        // Add calendar to team templates
        add_filter('sportspress_after_team_template', array($this, 'add_calendar_to_team_template'));
        add_filter('sportspress_team_settings', array($this, 'add_calendar_settings'));
        
        // Create the global function that SportsPress expects
        if (!function_exists('sportspress_output_team_calendar')) {
            function sportspress_output_team_calendar() {
                $events_manager = new SPAT_Events_Management();
                $events_manager->output_team_calendar();
            }
        }
    }
    
    /**
     * Handle admin form submissions
     */
    public function handle_admin_actions() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $actions = [
            'reset_calendars' => function() {
                $this->reset_calendars_to_current_season();
                $this->add_admin_notice(__('Calendars have been reset to current season.', 'sportspress-admin-tools'));
            },
            'import_events' => [$this, 'handle_xlsx_import'],
            'confirm_import' => [$this, 'handle_import_confirmation'],
            'create_missing_calendars' => function() {
                $created = $this->create_missing_calendars();
                $this->add_admin_notice(sprintf(__('Created %d calendars for teams without existing calendars.', 'sportspress-admin-tools'), $created));
            }
        ];
        
        foreach ($actions as $action => $callback) {
            if (isset($_POST[$action]) && wp_verify_nonce($_POST['_wpnonce'], $action)) {
                call_user_func($callback);
                break;
            }
        }
    }
    
    /**
     * Reset all calendars to current season
     */
    public function reset_calendars_to_current_season() {
        $current_season = $this->get_current_season();
        if (!$current_season) {
            return false;
        }
        
        $calendars = get_posts(array(
            'post_type' => 'sp_calendar',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ));
        
        $updated = 0;
        foreach ($calendars as $calendar) {
            $team = get_post_meta($calendar->ID, 'sp_team', true);
            if (!empty($team)) {
                wp_set_object_terms($calendar->ID, array($current_season->term_id), 'sp_season');
                $updated++;
            }
        }
        
        return $updated;
    }
    
    /**
     * Auto-create calendar when new team is created
     */
    public function auto_create_calendar($team_id) {
        // Check if auto-creation is enabled
        if (!get_option('spat_events_auto_calendar_creation', '1')) {
            return;
        }
        
        if (get_post_type($team_id) !== 'sp_team') {
            return;
        }
        
        $team = get_post($team_id);
        if (!$team || $team->post_status !== 'publish') {
            return;
        }
        
        // Avoid infinite loops on autosave/revisions
        if (wp_is_post_revision($team_id) || wp_is_post_autosave($team_id)) {
            return;
        }
        
        // Check if calendar already exists for this team
        $existing = get_posts(array(
            'post_type' => 'sp_calendar',
            'meta_query' => array(
                array(
                    'key' => 'sp_team',
                    'value' => $team_id,
                    'compare' => '='
                )
            ),
            'posts_per_page' => 1
        ));
        
        if (!empty($existing)) {
            return; // Calendar already exists
        }
        
        // Generate calendar title based on settings
        $title = $this->generate_calendar_title($team_id);
        
        // Create new calendar
        $calendar_id = wp_insert_post(array(
            'post_type' => 'sp_calendar',
            'post_title' => $title,
            'post_status' => 'publish'
        ));
        
        if ($calendar_id) {
            // Configure calendar like reference 111486
            $this->configure_calendar($calendar_id, $team_id);
        }
        
        return $calendar_id;
    }
    
    /**
     * Generate calendar title based on settings
     */
    private function generate_calendar_title($team_id) {
        $parts = array();
        $team = get_post($team_id);
        
        // Add prefix
        $prefix = get_option('spat_events_naming_prefix', '');
        if (!empty($prefix)) {
            $parts[] = $prefix;
        }
        
        // Add team name
        if (get_option('spat_events_include_team_name', '1')) {
            $parts[] = $team->post_title;
        }
        
        // Add division (first league)
        if (get_option('spat_events_include_division', '0')) {
            $leagues = wp_get_object_terms($team_id, 'sp_league');
            if (!empty($leagues)) {
                $parts[] = $leagues[0]->name;
            }
        }
        
        // Add suffix
        $suffix = get_option('spat_events_naming_suffix', 'ARL');
        if (!empty($suffix)) {
            $parts[] = $suffix;
        }
        
        // Join with separator
        $separator = get_option('spat_events_naming_separator', '|');
        if (empty($separator)) {
            return implode(' ', array_filter($parts));
        }
        return implode(' ' . $separator . ' ', array_filter($parts));
    }
    
    /**
     * Configure calendar based on reference 111486
     */
    private function configure_calendar($calendar_id, $team_id) {
        $meta_data = [
            'sp_team' => $team_id,
            'sp_format' => get_option('spat_events_calendar_type', 'list'),
            'sp_columns' => ['event', 'time', 'league', 'season', 'venue'],
            'sp_date' => 0,
            'sp_date_relative' => 0,
            'sp_date_future' => 7,
            'sp_date_past' => 7,
            'sp_event_format' => 'all',
            'sp_order' => 'ASC',
            'sp_orderby' => 'date',
            'sp_status' => 'any'
        ];
        
        foreach ($meta_data as $key => $value) {
            update_post_meta($calendar_id, $key, $value);
        }
        
        $current_season = $this->get_current_season();
        if ($current_season) {
            wp_set_object_terms($calendar_id, [$current_season->term_id], 'sp_season');
        }
        
        $team_leagues = wp_get_object_terms($team_id, 'sp_league');
        if (!empty($team_leagues)) {
            wp_set_object_terms($calendar_id, wp_list_pluck($team_leagues, 'term_id'), 'sp_league');
        }
    }
    
    /**
     * Handle XLSX file import - create preview
     */
    public function handle_xlsx_import() {
        try {
            if (!isset($_FILES['events_xlsx']) || $_FILES['events_xlsx']['error'] !== UPLOAD_ERR_OK) {
                throw new Exception('File upload failed.');
            }
            
            $file = $_FILES['events_xlsx'];
            $upload_dir = wp_upload_dir();
            $temp_file = $upload_dir['path'] . '/' . sanitize_file_name($file['name']);
            
            if (!move_uploaded_file($file['tmp_name'], $temp_file)) {
                throw new Exception('Failed to move uploaded file.');
            }
            
            // Parse file and create preview
            $preview_data = $this->create_import_preview($temp_file);
            
            // Store preview data in transient
            set_transient('spat_import_preview', $preview_data, 3600);
            set_transient('spat_import_file', $temp_file, 3600);
            
            // Redirect to show preview
            wp_redirect(admin_url('admin.php?page=sportspress-admin-tools&tab=events&preview=1'));
            exit;
            
        } catch (Exception $e) {
            $this->add_admin_notice('Import failed: ' . $e->getMessage(), 'error');
        }
    }
    
    /**
     * Create import preview
     */
    public function create_import_preview($file_path) {
        if (!class_exists('SimpleXLSX')) {
            require_once SPAT_PLUGIN_PATH . 'includes/SimpleXLSX.php';
        }
        
        $xlsx = SimpleXLSX::parse($file_path);
        if (!$xlsx) {
            throw new Exception('Failed to parse XLSX file');
        }
        
        $rows = $xlsx->rows();
        $preview = array(
            'events' => array(),
            'unique_teams' => array(),
            'unique_leagues' => array()
        );
        
        // Reset date tracking for new file
        $this->current_date = null;
        
        $existing_teams = $this->get_existing_teams();
        $existing_leagues = $this->get_existing_leagues();
        
        foreach ($rows as $index => $row) {
            if (empty(array_filter($row))) continue;
            
            $event_data = $this->parse_event_row($row, array());
            if (!$event_data) continue;
            
            $preview['events'][] = array(
                'row' => $index + 1,
                'date' => $event_data['date'],
                'time' => $event_data['time'],
                'home_team' => $event_data['home_team'],
                'away_team' => $event_data['away_team'],
                'venue' => $event_data['venue'],
                'league' => $event_data['league']
            );
            
            // Collect unique teams
            if (!isset($preview['unique_teams'][$event_data['home_team']])) {
                $preview['unique_teams'][$event_data['home_team']] = $this->find_team_match($event_data['home_team'], $existing_teams);
            }
            if (!isset($preview['unique_teams'][$event_data['away_team']])) {
                $preview['unique_teams'][$event_data['away_team']] = $this->find_team_match($event_data['away_team'], $existing_teams);
            }
            
            // Collect unique leagues
            if (!empty($event_data['league']) && !isset($preview['unique_leagues'][$event_data['league']])) {
                $preview['unique_leagues'][$event_data['league']] = $this->find_league_match($event_data['league'], $existing_leagues);
            }
        }
        
        return $preview;
    }
    
    /**
     * Get existing teams or leagues
     */
    private function get_existing_teams() {
        return $this->get_existing_entities('sp_team');
    }
    
    private function get_existing_leagues() {
        return $this->get_existing_entities('sp_league', true);
    }
    
    private function get_existing_entities($type, $is_taxonomy = false) {
        if ($is_taxonomy) {
            $items = get_terms(array('taxonomy' => $type, 'hide_empty' => false));
            $list = array();
            foreach ($items as $item) {
                $list[$item->term_id] = $item->name;
            }
        } else {
            $items = get_posts(array('post_type' => $type, 'posts_per_page' => -1, 'post_status' => 'publish'));
            $list = array();
            foreach ($items as $item) {
                $list[$item->ID] = $item->post_title;
            }
        }
        
        uasort($list, function($a, $b) {
            $a_alpha = preg_match('/^[a-zA-Z]/', $a);
            $b_alpha = preg_match('/^[a-zA-Z]/', $b);
            return ($a_alpha && !$b_alpha) ? -1 : ((!$a_alpha && $b_alpha) ? 1 : strcasecmp($a, $b));
        });
        
        return $list;
    }
    
    /**
     * Find league match
     */
    private function find_league_match($league_name, $existing_leagues) {
        // Exact match
        foreach ($existing_leagues as $id => $name) {
            if (strtolower($name) === strtolower($league_name)) {
                return array('id' => $id, 'name' => $name, 'type' => 'exact');
            }
        }
        
        // Check for common patterns (D1 -> Division 1, etc.)
        $patterns = array(
            '/^D(\d+)$/i' => 'Division $1',
            '/^Div\s*(\d+)$/i' => 'Division $1',
            '/^Division\s*(\d+)$/i' => 'Division $1'
        );
        
        foreach ($patterns as $pattern => $replacement) {
            if (preg_match($pattern, $league_name, $matches)) {
                $formatted_name = preg_replace($pattern, $replacement, $league_name);
                foreach ($existing_leagues as $id => $name) {
                    if (stripos($name, $formatted_name) !== false) {
                        return array('id' => $id, 'name' => $name, 'type' => 'pattern');
                    }
                }
            }
        }
        
        // Fuzzy match
        $best_match = null;
        $best_score = 0;
        foreach ($existing_leagues as $id => $name) {
            $similarity = $this->calculate_similarity($league_name, $name);
            if ($similarity > 0.6 && $similarity > $best_score) {
                $best_match = array('id' => $id, 'name' => $name, 'type' => 'fuzzy');
                $best_score = $similarity;
            }
        }
        
        return $best_match;
    }
    
    /**
     * Find team match
     */
    private function find_team_match($team_name, $existing_teams) {
        // Exact match
        foreach ($existing_teams as $id => $name) {
            if (strtolower($name) === strtolower($team_name)) {
                return array('id' => $id, 'name' => $name, 'type' => 'exact');
            }
        }
        
        // Fuzzy match - collect all matches above threshold
        $matches = array();
        foreach ($existing_teams as $id => $name) {
            $similarity = $this->calculate_similarity($team_name, $name);
            if ($similarity > 0.7) {
                $matches[] = array(
                    'id' => $id, 
                    'name' => $name, 
                    'similarity' => $similarity
                );
            }
        }
        
        // If multiple matches, prefer exact substring matches
        if (count($matches) > 1) {
            foreach ($matches as $match) {
                if (stripos($match['name'], $team_name) !== false || stripos($team_name, $match['name']) !== false) {
                    return array('id' => $match['id'], 'name' => $match['name'], 'type' => 'fuzzy');
                }
            }
        }
        
        // Return best match if any
        if (!empty($matches)) {
            usort($matches, function($a, $b) { return $b['similarity'] <=> $a['similarity']; });
            return array('id' => $matches[0]['id'], 'name' => $matches[0]['name'], 'type' => 'fuzzy');
        }
        
        return null;
    }
    
    /**
     * Handle import confirmation
     */
    public function handle_import_confirmation() {
        $preview_data = get_transient('spat_import_preview');
        $file_path = get_transient('spat_import_file');
        
        if (!$preview_data || !$file_path) {
            $this->add_admin_notice('Import session expired. Please upload the file again.', 'error');
            return;
        }
        
        $team_mappings = isset($_POST['team_mappings']) ? $_POST['team_mappings'] : array();
        $league_mappings = isset($_POST['league_mappings']) ? $_POST['league_mappings'] : array();
        $season_id = isset($_POST['import_season']) ? intval($_POST['import_season']) : null;
        
        if (!$season_id) {
            $this->add_admin_notice('Please select a season for the imported events.', 'error');
            return;
        }
        
        $imported = 0;
        $errors = 0;
        
        foreach ($preview_data['events'] as $event) {
            $home_team_id = isset($team_mappings[$event['home_team']]) ? intval($team_mappings[$event['home_team']]) : null;
            $away_team_id = isset($team_mappings[$event['away_team']]) ? intval($team_mappings[$event['away_team']]) : null;
            $league_id = isset($league_mappings[$event['league']]) ? intval($league_mappings[$event['league']]) : null;
            
            if ($home_team_id && $away_team_id) {
                if ($this->create_event_direct($event, $home_team_id, $away_team_id, $league_id, $season_id)) {
                    $imported++;
                } else {
                    $errors++;
                }
            } else {
                $errors++;
            }
        }
        
        // Clean up
        delete_transient('spat_import_preview');
        delete_transient('spat_import_file');
        if (file_exists($file_path)) {
            unlink($file_path);
        }
        
        // Store notices in transients to survive redirects
        if ($imported > 0) {
            set_transient('spat_import_success', sprintf('Successfully imported %d events.', $imported), 30);
        }
        if ($errors > 0) {
            set_transient('spat_import_errors', sprintf('Failed to import %d events due to missing team mappings.', $errors), 30);
        }
        
        // Redirect back to events tab with confirmation
        wp_redirect(admin_url('admin.php?page=sportspress-admin-tools&tab=events'));
        exit;
    }
    

    
    /**
     * Create event directly with team IDs
     */
    private function create_event_direct($event_data, $home_team_id, $away_team_id, $league_id = null, $season_id = null) {
        // Use actual team names from database, not XLSX names
        $home_team_name = get_the_title($home_team_id);
        $away_team_name = get_the_title($away_team_id);
        $title = $home_team_name . ' vs ' . $away_team_name;
        
        // Create datetime for post_date
        $datetime = $event_data['date'];
        if (!empty($event_data['time'])) {
            $datetime .= ' ' . $event_data['time'] . ':00';
        } else {
            $datetime .= ' 00:00:00';
        }
        
        $event_id = wp_insert_post(array(
            'post_type' => 'sp_event',
            'post_title' => $title,
            'post_status' => 'publish',
            'post_date' => $datetime,
            'post_date_gmt' => get_gmt_from_date($datetime)
        ));
        
        if (!$event_id) return false;
        
        // Update post_name to use ID
        wp_update_post(array(
            'ID' => $event_id,
            'post_name' => $event_id
        ));
        
        // Store teams as individual meta entries (not array)
        add_post_meta($event_id, 'sp_team', $home_team_id);
        add_post_meta($event_id, 'sp_team', $away_team_id);
        
        $meta_data = [
            'sp_format' => 'league',
            'sp_mode' => 'team',
            'sp_status' => 'ok',
            'sp_results' => [$home_team_id => ['goals' => '', 'goalstwo' => ''], $away_team_id => ['goals' => '', 'goalstwo' => '']],
            'sp_players' => [$home_team_id => [0 => ['g' => '', 'a' => '', 'pim' => '', 'ga' => '']], $away_team_id => [0 => ['g' => '', 'a' => '', 'pim' => '', 'ga' => '']]],
            'sp_specs' => [],
            'sp_timeline' => [],
            'sp_stars' => [],
            'sp_order' => [],
            'sp_result_columns' => []
        ];
        
        foreach ($meta_data as $key => $value) {
            update_post_meta($event_id, $key, $value);
        }
        
        foreach (['sp_player', 'sp_staff'] as $meta_key) {
            add_post_meta($event_id, $meta_key, 0);
            add_post_meta($event_id, $meta_key, 0);
        }
        
        if (!empty($event_data['venue'])) {
            $venue_id = $this->find_or_create_venue($event_data['venue']);
            if ($venue_id) {
                wp_set_object_terms($event_id, array($venue_id), 'sp_venue');
            }
        }
        
        if ($league_id) {
            wp_set_object_terms($event_id, array($league_id), 'sp_league');
            // Assign league to both teams
            wp_set_object_terms($home_team_id, array($league_id), 'sp_league', true);
            wp_set_object_terms($away_team_id, array($league_id), 'sp_league', true);
        }
        
        // Use selected season or current season
        $final_season_id = null;
        if ($season_id) {
            wp_set_object_terms($event_id, array($season_id), 'sp_season');
            $final_season_id = $season_id;
        } else {
            $current_season = $this->get_current_season();
            if ($current_season) {
                wp_set_object_terms($event_id, array($current_season->term_id), 'sp_season');
                $final_season_id = $current_season->term_id;
            }
        }
        
        // Assign season to both teams
        if ($final_season_id) {
            wp_set_object_terms($home_team_id, array($final_season_id), 'sp_season', true);
            wp_set_object_terms($away_team_id, array($final_season_id), 'sp_season', true);
        }
        
        return $event_id;
    }
    
    /**
     * Parse event row from XLSX
     */
    private function parse_event_row($row, $header) {
        // Skip empty rows
        if (empty(array_filter($row))) {
            return false;
        }
        
        // Check if this is a date header row
        if (isset($row[1]) && preg_match('/^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday).*\d{4}/', $row[1])) {
            $this->current_date = $this->parse_date_header($row[1]);
            return false;
        }
        
        // Skip header rows (HOME/VISITOR)
        if (isset($row[3]) && $row[3] === 'HOME') {
            return false;
        }
        
        // Check if this looks like a game row (has teams in columns 3 and 4)
        $home_team = isset($row[3]) ? trim($row[3]) : '';
        $away_team = isset($row[4]) ? trim($row[4]) : '';
        
        // Skip if no teams or empty teams
        if (empty($home_team) || empty($away_team)) {
            return false;
        }
        
        $data = array(
            'time' => isset($row[1]) ? $this->parse_time_value($row[1]) : '19:00',
            'league' => isset($row[2]) ? trim($row[2]) : '',
            'home_team' => $this->clean_team_name($home_team),
            'away_team' => $this->clean_team_name($away_team),
            'venue' => isset($row[5]) ? trim($row[5]) : 'Black',
            'date' => $this->current_date ?: date('Y-m-d')
        );
        
        return $data;
    }
    
    private $current_date = null;
    
    private function add_admin_notice($message, $type = 'success') {
        add_action('admin_notices', function() use ($message, $type) {
            echo '<div class="notice notice-' . $type . '"><p>' . esc_html($message) . '</p></div>';
        });
    }
    
    /**
     * Parse date header like "Friday August 1, 2025 - Round Robin - 1"
     */
    private function parse_date_header($header) {
        // Extract date from header like "Friday August 1, 2025 - Round Robin - 1"
        if (preg_match('/(\w+)\s+(\w+)\s+(\d+),\s+(\d{4})/', $header, $matches)) {
            $month = $matches[2];
            $day = $matches[3];
            $year = $matches[4];
            
            $date_string = "$month $day, $year";
            $timestamp = strtotime($date_string);
            
            if ($timestamp !== false) {
                return date('Y-m-d', $timestamp);
            }
        }
        
        return date('Y-m-d');
    }
    
    /**
     * Parse time value (handles both decimal and text formats)
     */
    private function parse_time_value($value) {
        $value = trim($value);
        
        // If it's a decimal (Excel time), convert it
        if (is_numeric($value) && $value > 0 && $value < 1) {
            $hours = floor($value * 24);
            $minutes = floor(($value * 24 - $hours) * 60);
            return sprintf('%02d:%02d', $hours, $minutes);
        }
        
        // If it's already a time string like "6:00PM"
        if (preg_match('/^\d{1,2}:\d{2}\s*(AM|PM)?$/i', $value)) {
            return $this->parse_time($value);
        }
        
        return '19:00'; // Default
    }
    
    /**
     * Clean team name by removing numbers, extra spaces, and common prefixes
     */
    private function clean_team_name($team_name) {
        return trim(preg_replace(['/^\d+\s*-\s*/', '/^\d+[.\s]*/', '/^- /'], '', trim($team_name)));
    }
    

    

    
    /**
     * Calculate similarity between two team names
     */
    private function calculate_similarity($name1, $name2) {
        // Normalize names for comparison
        $name1 = strtolower(trim($name1));
        $name2 = strtolower(trim($name2));
        
        // Use Levenshtein distance for similarity
        $max_len = max(strlen($name1), strlen($name2));
        if ($max_len == 0) return 1;
        
        $distance = levenshtein($name1, $name2);
        return 1 - ($distance / $max_len);
    }
    
    /**
     * Find or create venue/league
     */
    private function find_or_create_venue($venue_name) {
        return $this->find_or_create_term($venue_name, 'sp_venue', true);
    }
    
    private function find_or_create_league($league_name) {
        return $this->find_or_create_term($league_name, 'sp_league');
    }
    
    private function find_or_create_term($name, $taxonomy, $return_id = false) {
        $existing = get_term_by('name', $name, $taxonomy);
        if ($existing) {
            return $return_id ? $existing->term_id : $existing;
        }
        
        $result = wp_insert_term($name, $taxonomy);
        if (is_wp_error($result)) {
            return false;
        }
        
        return $return_id ? $result['term_id'] : get_term($result['term_id'], $taxonomy);
    }
    
    /**
     * Get current season
     */
    private function get_current_season() {
        $current_year = date('Y');
        $current_month = date('n');
        
        // Determine season based on month (adjust as needed)
        if ($current_month >= 9) {
            // Fall/Winter season
            $season_name = 'W' . $current_year . '-' . substr($current_year + 1, 2);
        } else {
            // Spring/Summer season
            $season_name = 'S' . $current_year;
        }
        
        $season = get_term_by('name', $season_name, 'sp_season');
        
        if (!$season) {
            // Create season if it doesn't exist
            $result = wp_insert_term($season_name, 'sp_season');
            if (!is_wp_error($result)) {
                $season = get_term($result['term_id'], 'sp_season');
            }
        }
        
        return $season;
    }
    
    /**
     * Create calendars for teams that don't have one
     */
    public function create_missing_calendars() {
        $teams = get_posts(array(
            'post_type' => 'sp_team',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ));
        
        $created = 0;
        foreach ($teams as $team) {
            // Check if calendar already exists
            $existing = get_posts(array(
                'post_type' => 'sp_calendar',
                'meta_query' => array(
                    array(
                        'key' => 'sp_team',
                        'value' => $team->ID,
                        'compare' => '='
                    )
                ),
                'posts_per_page' => 1
            ));
            
            if (empty($existing)) {
                if ($this->auto_create_calendar($team->ID)) {
                    $created++;
                }
            }
        }
        
        return $created;
    }
    
    /**
     * Parse date/time from various formats
     */
    private function parse_date($date_string) {
        return $this->parse_datetime($date_string, 'Y-m-d', ['Y-m-d','m/d/Y','d/m/Y','n/j/Y','j/n/Y','Y/m/d','M j, Y','F j, Y','d-m-Y','m-d-Y']);
    }
    
    private function parse_time($time_string) {
        return empty(trim($time_string)) ? '19:00' : $this->parse_datetime($time_string, 'H:i', ['H:i','H:i:s','g:i A','g:i a','g:iA','g:ia','G:i','h:i A','h:i a'], '19:00');
    }
    
    private function parse_datetime($string, $output_format, $formats, $default = null) {
        $string = trim($string);
        foreach ($formats as $format) {
            $dt = DateTime::createFromFormat($format, $string);
            if ($dt && $dt->format($format) === $string) {
                return $dt->format($output_format);
            }
        }
        $timestamp = strtotime($string);
        return $timestamp !== false ? date($output_format, $timestamp) : ($default ?: date($output_format));
    }
    
    /**
     * AJAX handler for calendar reset
     */
    public function ajax_reset_calendars() {
        check_ajax_referer('spat_events_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions.', 'sportspress-admin-tools'));
        }
        
        $count = $this->reset_calendars_to_current_season();
        
        wp_send_json_success(array(
            'message' => sprintf(__('Reset %d calendars to current season.', 'sportspress-admin-tools'), $count)
        ));
    }
    
    /**
     * AJAX handler for event import
     */
    public function ajax_import_events() {
        check_ajax_referer('spat_events_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions.', 'sportspress-admin-tools'));
        }
        
        $this->handle_xlsx_import();
        wp_die();
    }
    
    /**
     * Display admin interface
     */
    public function display_admin_interface() {
        $this->display_transient_notices();
        
        if (isset($_GET['preview']) && $_GET['preview'] == '1') {
            $preview_data = get_transient('spat_import_preview');
            if ($preview_data) {
                $this->display_import_preview();
                return;
            }
            wp_redirect(admin_url('admin.php?page=sportspress-admin-tools&tab=events'));
            exit;
        }
        
        include SPAT_PLUGIN_PATH . 'templates/events-admin.php';
    }
    
    private function display_transient_notices() {
        $notices = [
            'spat_import_success' => 'success',
            'spat_import_errors' => 'warning'
        ];
        
        foreach ($notices as $transient => $type) {
            $notice = get_transient($transient);
            if ($notice) {
                echo '<div class="notice notice-' . $type . ' is-dismissible"><p>' . esc_html($notice) . '</p></div>';
                delete_transient($transient);
            }
        }
    }
    
    /**
     * Display import preview
     */
    public function display_import_preview() {
        $preview_data = get_transient('spat_import_preview');
        
        if (!$preview_data) {
            echo '<div class="notice notice-error"><p>Import preview expired. Please upload the file again.</p></div>';
            return;
        }
        
        $unique_teams = $preview_data['unique_teams'];
        $unique_leagues = $preview_data['unique_leagues'];
        $events = $preview_data['events'];
        $existing_teams = $this->get_existing_teams();
        $existing_leagues = $this->get_existing_leagues();
        
        include SPAT_PLUGIN_PATH . 'templates/events-preview.php';
    }
    
    public function add_calendar_to_team_template($templates) {
        $templates['calendar'] = array(
            'title'   => __('Calendar', 'sportspress-admin-tools'),
            'option'  => 'sportspress_team_show_calendar',
            'action'  => 'sportspress_output_team_calendar',
            'default' => 'no',
        );
        return $templates;
    }
    
    public function output_team_calendar() {
        global $post;
        
        if (!$post || get_post_type($post) !== 'sp_team') {
            return;
        }
        
        // Find calendar for this team
        $calendars = get_posts(array(
            'post_type' => 'sp_calendar',
            'meta_query' => array(
                array(
                    'key' => 'sp_team',
                    'value' => $post->ID,
                    'compare' => '='
                )
            ),
            'posts_per_page' => 1
        ));
        
        if (empty($calendars)) {
            return;
        }
        
        $calendar = $calendars[0];
        
        // Output calendar using SportsPress shortcode with column settings
        $columns = array();
        if (get_option('sportspress_calendar_show_date', 'yes') === 'yes') $columns[] = 'date';
        if (get_option('sportspress_calendar_show_time', 'yes') === 'yes') $columns[] = 'time';
        if (get_option('sportspress_calendar_show_teams', 'yes') === 'yes') $columns[] = 'event';
        if (get_option('sportspress_calendar_show_league', 'no') === 'yes') $columns[] = 'league';
        if (get_option('sportspress_calendar_show_season', 'no') === 'yes') $columns[] = 'season';
        if (get_option('sportspress_calendar_show_venue', 'no') === 'yes') $columns[] = 'venue';
        
        $shortcode_attrs = 'id="' . $calendar->ID . '" title="0"';
        if (!empty($columns)) {
            $shortcode_attrs .= ' columns="' . implode(',', $columns) . '"';
        }
        
        echo '<div class="sp-template sp-template-team-calendar">';
        
        $show_feed = get_option('sportspress_calendar_show_feed', 'no') === 'yes';
        $feed_position = get_option('sportspress_calendar_feed_position', 'header');
        
        // Title and optional header feed icons
        if (get_option('sportspress_calendar_show_title', 'yes') === 'yes' || ($show_feed && $feed_position === 'header')) {
            // Title on left
            if (get_option('sportspress_calendar_show_title', 'yes') === 'yes') {
                $custom_title = get_option('sportspress_calendar_custom_title', '');
                $title = !empty($custom_title) ? $custom_title : $calendar->post_title;
                echo '<h4 class="sp-table-caption" style="display: flex; justify-content: space-between; align-items: center;">';
                echo '<span>' . esc_html($title) . '</span>';
            } else {
                echo '<div style="display: flex; justify-content: flex-end; align-items: center; margin-bottom: 10px;">';
            }
            
            // Feed icons in header
            if ($show_feed && $feed_position === 'header') {
                echo $this->render_calendar_icons('header');
            }
            
            if (get_option('sportspress_calendar_show_title', 'yes') === 'yes') {
                echo '</h4>';
            } else {
                echo '</div>';
            }
        }
        
        echo do_shortcode('[event_list ' . $shortcode_attrs . ']');
        
        // Feed icons below calendar
        if ($show_feed && $feed_position === 'below') {
            echo '<div class="sp-calendar-feeds" style="margin-top: 10px; display: flex; align-items: center; gap: 10px;">';
            echo '<strong>' . __('Add to Calendar:', 'sportspress-admin-tools') . '</strong>';
            echo $this->render_calendar_icons('below');
            echo '</div>';
        }
        
        echo '</div>';
    }
    
    public function add_calendar_settings($settings) {
        $calendar_settings = array(
            array(
                'title' => __('Calendar', 'sportspress-admin-tools'),
                'type'  => 'title',
                'id'    => 'calendar_options',
            ),
            array(
                'title'   => __('Title', 'sportspress-admin-tools'),
                'desc'    => __('Display title', 'sportspress-admin-tools'),
                'id'      => 'sportspress_calendar_show_title',
                'default' => 'yes',
                'type'    => 'checkbox',
            ),
            array(
                'title'   => __('Custom Title', 'sportspress-admin-tools'),
                'desc'    => __('Leave blank to use event list title', 'sportspress-admin-tools'),
                'id'      => 'sportspress_calendar_custom_title',
                'default' => '',
                'type'    => 'text',
            ),
            array(
                'title'   => __('Calendar Feed', 'sportspress-admin-tools'),
                'desc'    => __('Display calendar feed links', 'sportspress-admin-tools'),
                'id'      => 'sportspress_calendar_show_feed',
                'default' => 'no',
                'type'    => 'checkbox',
            ),
            array(
                'title'   => __('Feed Position', 'sportspress-admin-tools'),
                'desc'    => __('Where to display calendar feed icons', 'sportspress-admin-tools'),
                'id'      => 'sportspress_calendar_feed_position',
                'default' => 'header',
                'type'    => 'select',
                'options' => array(
                    'header' => __('In header (right-aligned)', 'sportspress-admin-tools'),
                    'below'  => __('Below calendar', 'sportspress-admin-tools'),
                ),
            ),
            array(
                'title'   => __('Date', 'sportspress-admin-tools'),
                'desc'    => __('Display date', 'sportspress-admin-tools'),
                'id'      => 'sportspress_calendar_show_date',
                'default' => 'yes',
                'type'    => 'checkbox',
            ),
            array(
                'title'   => __('Time', 'sportspress-admin-tools'),
                'desc'    => __('Display time', 'sportspress-admin-tools'),
                'id'      => 'sportspress_calendar_show_time',
                'default' => 'yes',
                'type'    => 'checkbox',
            ),
            array(
                'title'   => __('Teams', 'sportspress-admin-tools'),
                'desc'    => __('Display teams', 'sportspress-admin-tools'),
                'id'      => 'sportspress_calendar_show_teams',
                'default' => 'yes',
                'type'    => 'checkbox',
            ),
            array(
                'title'   => __('League', 'sportspress-admin-tools'),
                'desc'    => sprintf(__('Display %s', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('League'))),
                'id'      => 'sportspress_calendar_show_league',
                'default' => 'no',
                'type'    => 'checkbox',
            ),
            array(
                'title'   => __('Season', 'sportspress-admin-tools'),
                'desc'    => __('Display season', 'sportspress-admin-tools'),
                'id'      => 'sportspress_calendar_show_season',
                'default' => 'no',
                'type'    => 'checkbox',
            ),
            array(
                'title'   => SPAT_Text_Helper::get_text('Venue'),
                'desc'    => sprintf(__('Display %s', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Venue'))),
                'id'      => 'sportspress_calendar_show_venue',
                'default' => 'no',
                'type'    => 'checkbox',
            ),
            array(
                'title'             => __('Limit', 'sportspress-admin-tools'),
                'id'                => 'sportspress_calendar_rows',
                'class'             => 'small-text',
                'default'           => '10',
                'desc'              => __('events', 'sportspress-admin-tools'),
                'type'              => 'number',
                'custom_attributes' => array(
                    'min'  => 1,
                    'step' => 1,
                ),
            ),
            array(
                'type' => 'sectionend',
                'id'   => 'calendar_options',
            ),
        );
        
        return array_merge($settings, $calendar_settings);
    }
    
    private function render_calendar_icons($position = 'header') {
        $calendar_url = get_permalink(get_the_ID());
        $webcal_url = str_replace(array('http://', 'https://'), 'webcal://', $calendar_url) . '?feed=sp-ical';
        $google_url = 'http://www.google.com/calendar/render?cid=' . urlencode($webcal_url);
        $outlook_url = 'https://outlook.live.com/calendar/0/addcalendar?url=' . urlencode($webcal_url);
        
        $plugin_url = plugin_dir_url(__FILE__) . '../assets/images/';
        $icon_size = $position === 'header' ? '22px' : '20px';
        $gap = $position === 'header' ? '8px' : '10px';
        
        $output = '<div class="calendar-icons" style="display: flex; gap: ' . $gap . '; align-items: center;">';
        
        // Google Calendar
        $output .= '<a href="' . esc_url($google_url) . '" target="_blank" title="' . __('Google Calendar', 'sportspress-admin-tools') . '" style="display: inline-flex; align-items: center; text-decoration: none; padding: 2px;">';
        $output .= '<img src="' . esc_url($plugin_url . 'google_calendar_icon.svg') . '" alt="Google" style="width: ' . $icon_size . '; height: ' . $icon_size . ';" onerror="this.style.display=\'none\'; this.nextSibling.style.display=\'inline\';">';
        $output .= '<span style="display: none; font-size: 12px;">' . __('Google', 'sportspress-admin-tools') . '</span>';
        $output .= '</a>';
        
        // Apple Calendar
        $output .= '<a href="' . esc_url($webcal_url) . '" title="' . __('Apple Calendar', 'sportspress-admin-tools') . '" style="display: inline-flex; align-items: center; text-decoration: none; padding: 2px;">';
        $output .= '<img src="' . esc_url($plugin_url . 'apple_calendar_96.png') . '" alt="Apple" style="width: ' . $icon_size . '; height: ' . $icon_size . ';" onerror="this.style.display=\'none\'; this.nextSibling.style.display=\'inline\';">';
        $output .= '<span style="display: none; font-size: 12px;">' . __('Apple', 'sportspress-admin-tools') . '</span>';
        $output .= '</a>';
        
        // Outlook Calendar
        $output .= '<a href="' . esc_url($outlook_url) . '" target="_blank" title="' . __('Outlook Calendar', 'sportspress-admin-tools') . '" style="display: inline-flex; align-items: center; text-decoration: none; padding: 2px;">';
        $output .= '<img src="' . esc_url($plugin_url . 'outlook.svg') . '" alt="Outlook" style="width: ' . $icon_size . '; height: ' . $icon_size . ';" onerror="this.style.display=\'none\'; this.nextSibling.style.display=\'inline\';">';
        $output .= '<span style="display: none; font-size: 12px;">' . __('Outlook', 'sportspress-admin-tools') . '</span>';
        $output .= '</a>';
        
        // Other Calendar Apps
        $output .= '<a href="' . esc_url($webcal_url) . '" title="' . __('Other Calendar Apps', 'sportspress-admin-tools') . '" style="display: inline-flex; align-items: center; text-decoration: none; padding: 2px;">';
        $output .= '<img src="' . esc_url($plugin_url . 'calendar_96.png') . '" alt="Calendar" style="width: ' . $icon_size . '; height: ' . $icon_size . ';" onerror="this.style.display=\'none\'; this.nextSibling.style.display=\'inline\';">';
        $output .= '<span style="display: none; font-size: 12px;">' . __('Other', 'sportspress-admin-tools') . '</span>';
        $output .= '</a>';
        
        $output .= '</div>';
        
        return $output;
    }
}