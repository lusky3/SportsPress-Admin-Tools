<?php
/**
 * Player Registration Module
 * 
 * @author Cody (lusky3)
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    wp_die();
}

class SPAT_Player_Registration {
    
    public function __construct() {
        add_action('woocommerce_order_status_completed', array($this, 'process_completed_order'));
    }
    
    public function process_completed_order($order_id) {
        // Ensure database tables exist
        if (!class_exists('SPAT_Database')) {
            require_once SPAT_PLUGIN_PATH . 'includes/class-database.php';
        }
        
        // Create tables if they don't exist
        if (get_option('spat_db_version') !== '1.0.0') {
            SPAT_Database::create_tables();
        }
        
        $order = wc_get_order($order_id);
        if (!$order) {
            error_log("SPAT Player Registration: Order #$order_id not found");
            return;
        }
        
        $registration_items = $this->get_registration_items($order);
        if (empty($registration_items)) {
            error_log("SPAT Player Registration: No registration items found in order #$order_id");
            return;
        }
        
        $raw_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        $customer_name = $this->validate_and_clean_name($raw_name);
        
        if (!$customer_name) {
            error_log("SPAT Player Registration: Invalid name format '$raw_name' in order #$order_id - skipping");
            return;
        }
        
        $customer_email = strtolower($order->get_billing_email());
        $user_id = $order->get_user_id();
        
        error_log("SPAT Player Registration: Processing order #$order_id for customer '$customer_name' with " . count($registration_items) . " registration items");
        
        foreach ($registration_items as $item) {
            $season = $this->extract_season_from_product($item['product_id']);
            if (!$season) {
                error_log("SPAT Player Registration: No season found for product #{$item['product_id']} in order #$order_id");
                continue;
            }
            
            $result = $this->find_or_create_player($customer_name, $season, $item['position'], $customer_email);
            
            if ($result['player_id']) {
                $player_id = $result['player_id'];
                
                // Link user to player if not guest checkout
                if ($user_id > 0) {
                    // Check if automatic role assignment is enabled
                    if (get_option('spat_player_registration_auto_role', '1') === '1') {
                        $this->assign_player_role($user_id);
                    } else {
                        $user = get_user_by('id', $user_id);
                        if ($user) {
                            $this->log_role_assignment($user_id, $user->display_name, 'role_assignment_disabled');
                        }
                    }
                    $this->link_user_to_player($user_id, $player_id);
                } else {
                    $this->log_role_assignment(0, $customer_name, 'guest_checkout_skipped');
                    error_log("SPAT Player Registration: Guest checkout - no role assignment for '$customer_name'");
                }
                
                $this->log_registration_activity($order_id, $customer_name, $player_id, $season, $item['position'], $result['action']);
            } else {
                $this->log_registration_activity($order_id, $customer_name, null, $season, $item['position'], $result['action']);
                error_log("SPAT Player Registration: {$result['action']} for '$customer_name' in order #$order_id (season: $season)");
            }
        }
    }
    
    private function get_registration_items($order) {
        $items = array();
        
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if (!$product) continue;
            
            // Check if product is in registration category
            $categories = wp_get_post_terms($product->get_id(), 'product_cat');
            $is_registration = false;
            $season = null;
            
            foreach ($categories as $category) {
                if (stripos($category->name, 'registration') !== false) {
                    $is_registration = true;
                }
                // Extract season from category (W2024-25, Winter 2025-26, etc.)
                if (preg_match('/^[WS]\d{4}(-\d{2})?$/', $category->name) || preg_match('/(Winter|Summer)\s+(\d{4}-\d{2})/', $category->name, $matches)) {
                    if (isset($matches[2])) {
                        $season = ($matches[1] === 'Winter' ? 'W' : 'S') . $matches[2];
                    } else {
                        $season = $category->name;
                    }
                }
            }
            
            if (!$is_registration || !$season) continue;
            
            // Check product tags for position
            $tags = wp_get_post_terms($product->get_id(), 'product_tag');
            $position = 'player'; // default
            
            foreach ($tags as $tag) {
                if (strtolower($tag->name) === 'goalie') {
                    $position = 'goalie';
                    break;
                }
            }
            
            $items[] = array(
                'product_id' => $product->get_id(),
                'season' => $season,
                'position' => $position
            );
        }
        
        return $items;
    }
    
    private function extract_season_from_product($product_id) {
        // First try to extract from product title
        $product_title = get_the_title($product_id);
        if (preg_match('/([WS]\d{4}(?:-\d{2})?)/', $product_title, $matches)) {
            return $matches[1];
        }
        
        // Fallback to categories
        $categories = wp_get_post_terms($product_id, 'product_cat');
        
        foreach ($categories as $category) {
            if (preg_match('/^[WS]\d{4}(-\d{2})?$/', $category->name)) {
                return $category->name;
            }
            // Handle "Winter 2025-26" format
            if (preg_match('/(Winter|Summer)\s+(\d{4}-\d{2})/', $category->name, $matches)) {
                return ($matches[1] === 'Winter' ? 'W' : 'S') . $matches[2];
            }
        }
        
        return null;
    }
    
    private function find_or_create_player($customer_name, $season, $position, $customer_email = '') {
        $player_id = null;
        $action = '';
        
        // First criteria: Search by spat_email if provided
        if (!empty($customer_email)) {
            $players = get_posts(array(
                'post_type' => 'sp_player',
                'post_status' => 'publish',
                'posts_per_page' => 1,
                'meta_query' => array(
                    array(
                        'key' => 'spat_email',
                        'value' => strtolower($customer_email),
                        'compare' => '='
                    )
                )
            ));
            
            if (!empty($players)) {
                $player_id = $players[0]->ID;
                $action = 'player_found_by_email';
                error_log("SPAT Player Registration: Found existing player by email '$customer_email' (ID: $player_id)");
            }
        }
        
        // Second criteria: Search by First Name Last Name match
        if (!$player_id) {
            $players = get_posts(array(
                'post_type' => 'sp_player',
                'post_status' => 'publish',
                'title' => $customer_name,
                'posts_per_page' => -1
            ));
            
            if (count($players) === 1) {
                $player_id = $players[0]->ID;
                $action = 'player_found_by_name';
                error_log("SPAT Player Registration: Found existing player by name '$customer_name' (ID: $player_id)");
            } elseif (count($players) > 1) {
                $action = 'multiple_players_found_name_match_requires_email';
                error_log("SPAT Player Registration: Multiple players found with name '$customer_name' - email match required");
                return array('player_id' => null, 'action' => $action);
            }
        }
        
        $is_new_player = false;
        
        if (!$player_id) {
            // Check if automatic player creation is enabled
            if (get_option('spat_player_registration_auto_create', '1') === '1') {
                // Create new player
                $player_id = wp_insert_post(array(
                    'post_type' => 'sp_player',
                    'post_title' => $customer_name,
                    'post_status' => 'publish'
                ));
                $is_new_player = true;
                $action = 'player_created';
                error_log("SPAT Player Registration: Created new player '$customer_name' (ID: $player_id)");
            } else {
                // Auto-creation disabled
                $action = 'player_creation_disabled';
                error_log("SPAT Player Registration: Player creation disabled - skipping '$customer_name'");
                return array('player_id' => null, 'action' => $action);
            }
        }
        
        if ($player_id) {
            $this->add_season_to_player($player_id, $season);
            
            // Set email for new players if provided
            if ($is_new_player && !empty($customer_email)) {
                update_post_meta($player_id, 'spat_email', sanitize_email(strtolower($customer_email)));
                error_log("SPAT Player Registration: Set email '$customer_email' for new player '$customer_name'");
            }
        }
        
        return array('player_id' => $player_id, 'action' => $action);
    }
    
    private function add_season_to_player($player_id, $season) {
        // Get or create season term
        $season_term = get_term_by('name', $season, 'sp_season');
        if (!$season_term) {
            $result = wp_insert_term($season, 'sp_season');
            if (!is_wp_error($result)) {
                $season_term = get_term($result['term_id'], 'sp_season');
            }
        }
        
        if ($season_term) {
            $season_ids = array($season_term->term_id);
            
            // Get child seasons
            $child_seasons = get_terms(array(
                'taxonomy' => 'sp_season',
                'parent' => $season_term->term_id,
                'hide_empty' => false
            ));
            
            foreach ($child_seasons as $child) {
                $season_ids[] = $child->term_id;
            }
            
            wp_set_object_terms($player_id, $season_ids, 'sp_season', true);
        }
    }
    
    private function assign_player_role($user_id) {
        $user = get_user_by('id', $user_id);
        if (!$user) return;
        
        if (!in_array('player', $user->roles)) {
            $user->add_role('player');
            $this->log_role_assignment($user_id, $user->display_name, 'role_assigned');
        } else {
            $this->log_role_assignment($user_id, $user->display_name, 'role_already_exists');
        }
    }
    
    private function link_user_to_player($user_id, $player_id) {
        update_post_meta($player_id, 'sp_user', $user_id);
    }
    
    public function sync_players_to_users() {
        $players = get_posts(array(
            'post_type' => 'sp_player',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => 'sp_user',
                    'compare' => 'NOT EXISTS'
                )
            )
        ));
        
        $matches = array();
        
        foreach ($players as $player) {
            $player_name = $player->post_title;
            $clean_name = $this->strip_bracket_text($player_name);
            
            // Find users with matching names
            $users = get_users(array(
                'search' => '*' . $clean_name . '*',
                'search_columns' => array('display_name', 'user_nicename')
            ));
            
            // Also search by first/last name combination
            $name_parts = explode(' ', $clean_name);
            if (count($name_parts) >= 2) {
                $first_name = $name_parts[0];
                $last_name = end($name_parts);
                
                $meta_users = get_users(array(
                    'meta_query' => array(
                        'relation' => 'AND',
                        array(
                            'key' => 'first_name',
                            'value' => $first_name,
                            'compare' => 'LIKE'
                        ),
                        array(
                            'key' => 'last_name',
                            'value' => $last_name,
                            'compare' => 'LIKE'
                        )
                    )
                ));
                
                $users = array_merge($users, $meta_users);
                $users = array_unique($users, SORT_REGULAR);
            }
            
            if (count($users) === 1) {
                // Auto-link single match
                $this->link_user_to_player($users[0]->ID, $player->ID);
                // Set email if not already set
                $this->set_player_email_if_empty($player->ID, $users[0]->user_email);
                // Check if automatic role assignment is enabled
                if (get_option('spat_player_registration_auto_role', '1') === '1') {
                    $this->assign_player_role($users[0]->ID);
                }
            } elseif (count($users) > 1) {
                // Multiple matches - require manual selection
                $matches[] = array(
                    'player' => $player,
                    'users' => $users
                );
            }
        }
        
        return $matches;
    }
    
    public function get_sync_preview_data() {
        $players = get_posts(array(
            'post_type' => 'sp_player',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => 'sp_user',
                    'compare' => 'NOT EXISTS'
                )
            )
        ));
        
        $preview_data = array();
        
        foreach ($players as $player) {
            $player_name = $player->post_title;
            $clean_name = $this->strip_bracket_text($player_name);
            
            // Find users with matching names (read-only)
            $users = get_users(array(
                'search' => '*' . $clean_name . '*',
                'search_columns' => array('display_name'),
                'number' => 5
            ));
            
            if (count($users) === 1) {
                $preview_data[] = array(
                    'player' => $player,
                    'user' => $users[0],
                    'action' => 'auto_link'
                );
            } elseif (count($users) > 1) {
                $preview_data[] = array(
                    'player' => $player,
                    'users' => $users,
                    'action' => 'manual_select'
                );
            } else {
                $preview_data[] = array(
                    'player' => $player,
                    'action' => 'no_match'
                );
            }
        }
        
        return $preview_data;
    }
    

    
    private function log_registration_activity($order_id, $customer_name, $player_id, $season, $position, $action = 'player_registration') {
        // Ensure database class is loaded
        if (!class_exists('SPAT_Database')) {
            require_once SPAT_PLUGIN_PATH . 'includes/class-database.php';
        }
        
        try {
            SPAT_Database::log_registration_activity($order_id, $customer_name, $player_id, $season, $position, $action);
            error_log("SPAT Player Registration: Logged activity - Order: #$order_id, Customer: $customer_name, Action: $action");
        } catch (Exception $e) {
            error_log("SPAT Player Registration: Failed to log activity - " . $e->getMessage());
        }
    }
    
    private function log_role_assignment($user_id, $user_name, $action = 'role_assignment') {
        // Ensure database class is loaded
        if (!class_exists('SPAT_Database')) {
            require_once SPAT_PLUGIN_PATH . 'includes/class-database.php';
        }
        
        try {
            SPAT_Database::log_role_assignment($user_id, $user_name, $action);
            error_log("SPAT Player Registration: Logged role assignment - User: $user_name, Action: $action");
        } catch (Exception $e) {
            error_log("SPAT Player Registration: Failed to log role assignment - " . $e->getMessage());
        }
    }
    
    private function set_player_email_if_empty($player_id, $user_email) {
        $existing_email = get_post_meta($player_id, 'spat_email', true);
        if (empty($existing_email) && !empty($user_email)) {
            update_post_meta($player_id, 'spat_email', sanitize_email(strtolower($user_email)));
        }
    }
    
    private function validate_and_clean_name($name) {
        // Remove extra whitespace and normalize
        $name = trim(preg_replace('/\s+/', ' ', $name));
        
        // Check if name contains only letters, spaces, hyphens, and apostrophes
        if (!preg_match('/^[a-zA-Z\s\-\']+$/', $name)) {
            return false;
        }
        
        // Check for reasonable length (2-50 characters)
        if (strlen($name) < 2 || strlen($name) > 50) {
            return false;
        }
        
        // Ensure it has at least one letter
        if (!preg_match('/[a-zA-Z]/', $name)) {
            return false;
        }
        
        return $this->format_proper_case($name);
    }
    
    private function format_proper_case($name) {
        return ucwords(strtolower(trim($name)));
    }
    
    private function strip_bracket_text($name) {
        return trim(preg_replace('/\s*\([^)]*\)\s*/', ' ', $name));
    }
}