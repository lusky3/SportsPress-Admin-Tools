<?php
/**
 * Player Modifications Module
 * 
 * @author Cody (lusky3)
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    wp_die();
}

// Include text helper if not already loaded
if (!class_exists('SPAT_Text_Helper')) {
    require_once SPAT_PLUGIN_PATH . 'includes/class-text-helper.php';
}

class SPAT_Player_Modifications {
    
    private $email_meta_enabled;
    private $squad_number_edit_enabled;
    private $captain_role_enabled;
    private $roster_upload_enabled;
    
    public function __construct() {
        // Cache option values
        $this->email_meta_enabled = get_option('spat_player_modifications_email_meta', '1') === '1';
        $this->squad_number_edit_enabled = get_option('spat_player_modifications_squad_number_edit', '1') === '1';
        $this->captain_role_enabled = get_option('spat_player_modifications_captain_role', '1') === '1';
        $this->roster_upload_enabled = get_option('spat_player_modifications_roster_upload', '1') === '1';
        
        // Admin email field
        if ($this->email_meta_enabled) {
            add_action('add_meta_boxes', array($this, 'add_email_meta_box'));
            add_action('save_post', array($this, 'save_email_meta'));
        }
        
        // Front-end squad number editing
        if ($this->squad_number_edit_enabled) {
            add_action('woocommerce_account_dashboard', array($this, 'display_squad_number_form'));
            add_action('init', array($this, 'handle_squad_number_update'));
        }
        
        // Captain role functionality
        if ($this->captain_role_enabled) {
            add_action('add_meta_boxes', array($this, 'add_captain_meta_box'));
            add_action('save_post', array($this, 'save_captain_selection'));
            
            // Only add frontend filters
            if (!is_admin()) {
                add_filter('the_content', array($this, 'add_captain_to_content'), 10);
                add_action('wp_enqueue_scripts', array($this, 'enqueue_captain_styles'));
            }
        }
        
        // Roster upload functionality
        if ($this->roster_upload_enabled) {
            add_action('add_meta_boxes', array($this, 'add_roster_upload_meta_box'));
            add_action('admin_init', array($this, 'handle_roster_upload'));
            add_action('wp_ajax_spat_roster_preview', array($this, 'ajax_roster_preview'));
            add_action('wp_ajax_spat_roster_process', array($this, 'ajax_roster_process'));
        }
    }
    
    public function add_email_meta_box() {
        add_meta_box(
            'spat_player_email',
            sprintf(__('%s Email', 'sportspress-admin-tools'), SPAT_Text_Helper::get_text('Player')),
            array($this, 'email_meta_box_callback'),
            'sp_player',
            'side',
            'default'
        );
    }
    
    public function email_meta_box_callback($post) {
        wp_nonce_field('spat_player_email_nonce', 'spat_player_email_nonce');
        $email = get_post_meta($post->ID, 'spat_email', true);
        
        echo '<label for="spat_email">' . __('Email Address:', 'sportspress-admin-tools') . '</label>';
        echo '<input type="email" id="spat_email" name="spat_email" value="' . esc_attr($email) . '" class="widefat" />';
        echo '<p class="description">' . __('Private email address for administrative use only.', 'sportspress-admin-tools') . '</p>';
    }
    
    public function save_email_meta($post_id) {
        if (!isset($_POST['spat_player_email_nonce']) || !wp_verify_nonce($_POST['spat_player_email_nonce'], 'spat_player_email_nonce')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        if (isset($_POST['spat_email'])) {
            $email = sanitize_email($_POST['spat_email']);
            if (is_email($email) || empty($email)) {
                update_post_meta($post_id, 'spat_email', $email);
            }
        }
    }
    
    public function display_squad_number_form() {
        if (!is_user_logged_in()) {
            return;
        }
        
        $user_id = get_current_user_id();
        $player_id = $this->get_user_player_id($user_id);
        
        if (!$player_id) {
            return;
        }
        
        $current_number = get_post_meta($player_id, 'sp_number', true);
        
        echo '<div class="woocommerce-MyAccount-content">';
        echo '<h3>' . __('Squad Number', 'sportspress-admin-tools') . '</h3>';
        echo '<form method="post" action="">';
        wp_nonce_field('update_squad_number', 'squad_number_nonce');
        echo '<p>';
        echo '<label for="squad_number">' . __('Your Squad Number:', 'sportspress-admin-tools') . '</label>';
        echo '<input type="number" id="squad_number" name="squad_number" value="' . esc_attr($current_number) . '" min="1" max="99" />';
        echo '</p>';
        echo '<p><input type="submit" name="update_squad_number" value="' . __('Update Number', 'sportspress-admin-tools') . '" class="button" /></p>';
        echo '</form>';
        echo '</div>';
    }
    
    public function handle_squad_number_update() {
        if (!isset($_POST['update_squad_number']) || !isset($_POST['squad_number_nonce']) || !isset($_POST['squad_number'])) {
            return;
        }
        
        if (!wp_verify_nonce($_POST['squad_number_nonce'], 'update_squad_number')) {
            return;
        }
        
        if (!is_user_logged_in()) {
            return;
        }
        
        $user_id = get_current_user_id();
        $player_id = $this->get_user_player_id($user_id);
        
        if (!$player_id) {
            return;
        }
        
        $new_number = intval($_POST['squad_number']);
        
        if ($new_number > 0 && $new_number <= 99) {
            update_post_meta($player_id, 'sp_number', $new_number);
            wc_add_notice(__('Squad number updated successfully!', 'sportspress-admin-tools'), 'success');
        } else {
            wc_add_notice(__('Please enter a valid squad number (1-99).', 'sportspress-admin-tools'), 'error');
        }
    }
    
    private function get_user_player_id($user_id) {
        global $wpdb;
        
        $player_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'sp_user' AND meta_value = %d LIMIT 1",
            $user_id
        ));
        
        if ($player_id && get_post_type($player_id) === 'sp_player') {
            return intval($player_id);
        }
        
        return null;
    }
    
    public function add_captain_meta_box() {
        add_meta_box(
            'spat_captain_selection',
            __('Captain Selection', 'sportspress-admin-tools'),
            array($this, 'captain_meta_box_callback'),
            'sp_list',
            'side',
            'default'
        );
    }
    
    public function captain_meta_box_callback($post) {
        wp_nonce_field('spat_captain_selection_nonce', 'spat_captain_selection_nonce');
        $captain_id = get_post_meta($post->ID, 'spat_captain', true);
        
        // Get players from this list - try multiple meta keys
        $players = get_post_meta($post->ID, 'sp_player', false);
        if (empty($players)) {
            $players = get_post_meta($post->ID, 'sp_players', true);
            if (is_array($players)) {
                $players = array_keys($players);
            }
        }
        
        echo '<label for="spat_captain">' . __('Select Captain:', 'sportspress-admin-tools') . '</label>';
        echo '<select id="spat_captain" name="spat_captain" class="widefat">';
        echo '<option value="">' . __('No Captain', 'sportspress-admin-tools') . '</option>';
        
        if (!empty($players)) {
            foreach ($players as $player_id) {
                if (is_numeric($player_id) && get_post_type($player_id) === 'sp_player') {
                    $player_title = get_the_title($player_id);
                    $selected = selected($captain_id, $player_id, false);
                    echo '<option value="' . esc_attr($player_id) . '" ' . $selected . '>' . esc_html($player_title) . '</option>';
                }
            }
        } else {
            echo '<option value="" disabled>' . sprintf(__('No %s found in this list', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Players'))) . '</option>';
        }
        
        echo '</select>';
        echo '<p class="description">' . sprintf(__('Select the team captain from %s in this list. The captain will display with a "C" indicator on the frontend.', 'sportspress-admin-tools'), strtolower(SPAT_Text_Helper::get_text('Players'))) . '</p>';
    }
    
    public function save_captain_selection($post_id) {
        if (!isset($_POST['spat_captain_selection_nonce']) || !wp_verify_nonce($_POST['spat_captain_selection_nonce'], 'spat_captain_selection_nonce')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        if (get_post_type($post_id) !== 'sp_list') {
            return;
        }
        
        if (isset($_POST['spat_captain'])) {
            $captain_id = sanitize_text_field($_POST['spat_captain']);
            
            if (empty($captain_id)) {
                delete_post_meta($post_id, 'spat_captain');
            } else {
                // Validate that the selected captain is actually in this list
                $players = get_post_meta($post_id, 'sp_player', false);
                if (empty($players)) {
                    $players = get_post_meta($post_id, 'sp_players', true);
                    if (is_array($players)) {
                        $players = array_keys($players);
                    }
                }
                
                if (is_array($players) && in_array($captain_id, $players) && get_post_type($captain_id) === 'sp_player') {
                    update_post_meta($post_id, 'spat_captain', $captain_id);
                } else {
                    // Invalid captain selection, remove it
                    delete_post_meta($post_id, 'spat_captain');
                }
            }
        }
    }
    

    
    public function add_captain_to_content($content) {
        global $post;
        
        if (!$post || (get_post_type($post) !== 'sp_list' && get_post_type($post) !== 'sp_team')) {
            return $content;
        }
        
        // Prevent double processing
        if (strpos($content, 'spat-captain-indicator') !== false) {
            return $content;
        }
        
        if (get_post_type($post) === 'sp_list') {
            $captain_id = get_post_meta($post->ID, 'spat_captain', true);
            if ($captain_id) {
                $captain_name = get_the_title($captain_id);
                $captain_text = apply_filters('spat_captain_indicator_text', 'C');
                $captain_indicator = ' <span class="spat-captain-indicator" title="' . esc_attr__('Captain', 'sportspress-admin-tools') . '">' . esc_html($captain_text) . '</span>';
                
                // Clean any existing HTML first, then add indicator
                $clean_name = strip_tags($captain_name);
                $content = str_replace('>' . $captain_name . '<', '>' . $clean_name . $captain_indicator . '<', $content);
                $content = str_replace('>' . $clean_name . '<', '>' . $clean_name . $captain_indicator . '<', $content);
            }
        }
        
        return $content;
    }
    
    public function enqueue_captain_styles() {
        if (is_singular('sp_list') || is_singular('sp_team') || (function_exists('sp_get_post_type') && in_array(sp_get_post_type(), array('sp_list', 'sp_team')))) {
            global $post;
            
            // Get team colors if SportsPress Pro Team Colors is active
            $primary_color = '#0073aa'; // Default color
            $hover_color = '#005a87';
            
            if (class_exists('SportsPress_Team_Colors')) {
                $team_id = null;
                
                if (get_post_type($post) === 'sp_team') {
                    $team_id = $post->ID;
                } elseif (get_post_type($post) === 'sp_list') {
                    $team_id = get_post_meta($post->ID, 'sp_team', true);
                }
                
                if ($team_id) {
                    $team_colors = get_post_meta($team_id, 'sp_colors', true);
                    if (!empty($team_colors['primary'])) {
                        $primary_color = $team_colors['primary'];
                        // Create darker hover color
                        $hover_color = $this->darken_color($primary_color, 20);
                    }
                }
            }
            
            wp_add_inline_style('wp-block-library', '
                .spat-captain-indicator {
                    display: inline-block;
                    background: ' . esc_attr($primary_color) . ';
                    color: white;
                    font-weight: bold;
                    font-size: 0.75em;
                    padding: 3px 6px;
                    border-radius: 50%;
                    margin-left: 6px;
                    line-height: 1;
                    text-align: center;
                    min-width: 18px;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.2);
                    transition: all 0.2s ease;
                }
                .spat-captain-indicator:hover {
                    background: ' . esc_attr($hover_color) . ';
                    transform: scale(1.1);
                }
                @media (max-width: 768px) {
                    .spat-captain-indicator {
                        font-size: 0.7em;
                        padding: 2px 5px;
                        min-width: 16px;
                    }
                }
            ');
        }
    }
    
    private function darken_color($hex, $percent) {
        $hex = str_replace('#', '', $hex);
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        $r = max(0, min(255, $r - ($r * $percent / 100)));
        $g = max(0, min(255, $g - ($g * $percent / 100)));
        $b = max(0, min(255, $b - ($b * $percent / 100)));
        
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }
    
    // Roster Upload Functionality
    
    public function add_roster_upload_meta_box() {
        add_meta_box(
            'spat_roster_upload',
            __('Roster Upload', 'sportspress-admin-tools'),
            array($this, 'roster_upload_meta_box_callback'),
            'sp_list',
            'side',
            'high'
        );
    }
    
    public function roster_upload_meta_box_callback($post) {
        wp_nonce_field('spat_roster_upload_nonce', 'spat_roster_upload_nonce');
        
        echo '<div id="roster-upload-form">';
        echo '<p><strong>' . __('Upload CSV/XLSX roster file:', 'sportspress-admin-tools') . '</strong></p>';
        
        // Team selection
        $teams = get_terms(array('taxonomy' => 'sp_team', 'hide_empty' => false));
        echo '<p><label for="roster_team">' . SPAT_Text_Helper::get_text('Team') . ':</label><br>';
        echo '<select id="roster_team" name="roster_team" required class="widefat">';
        echo '<option value="">' . __('Select Team', 'sportspress-admin-tools') . '</option>';
        foreach ($teams as $team) {
            echo '<option value="' . esc_attr($team->term_id) . '">' . esc_html($team->name) . '</option>';
        }
        echo '</select></p>';
        
        // Season selection
        $seasons = get_terms(array('taxonomy' => 'sp_season', 'hide_empty' => false));
        echo '<p><label for="roster_season">' . SPAT_Text_Helper::get_text('Season') . ':</label><br>';
        echo '<select id="roster_season" name="roster_season" required class="widefat">';
        echo '<option value="">' . __('Select Season', 'sportspress-admin-tools') . '</option>';
        foreach ($seasons as $season) {
            echo '<option value="' . esc_attr($season->term_id) . '">' . esc_html($season->name) . '</option>';
        }
        echo '</select></p>';
        
        // File upload
        echo '<p><label for="roster_file">' . __('Roster File:', 'sportspress-admin-tools') . '</label><br>';
        echo '<input type="file" id="roster_file" name="roster_file" accept=".csv,.xlsx" class="widefat" /></p>';
        
        echo '<p><button type="button" id="preview-roster" class="button button-secondary" style="width: 100%;">' . __('Preview Upload', 'sportspress-admin-tools') . '</button></p>';
        echo '</div>';
        
        echo '<div id="roster-preview" style="display: none;"></div>';
        
        $this->enqueue_roster_upload_scripts();
    }
    
    private function enqueue_roster_upload_scripts() {
        wp_add_inline_script('jquery', '
            jQuery(document).ready(function($) {
                $("#preview-roster").click(function() {
                    var formData = new FormData();
                    var fileInput = document.getElementById("roster_file");
                    
                    if (!fileInput.files[0]) {
                        alert("Please select a file");
                        return;
                    }
                    
                    if (!$("#roster_team").val() || !$("#roster_season").val()) {
                        alert("Please select team and season");
                        return;
                    }
                    
                    formData.append("action", "spat_roster_preview");
                    formData.append("nonce", "' . wp_create_nonce('spat_roster_preview') . '");
                    formData.append("roster_file", fileInput.files[0]);
                    formData.append("roster_team", $("#roster_team").val());
                    formData.append("roster_season", $("#roster_season").val());
                    
                    $(this).prop("disabled", true).text("Processing...");
                    
                    $.ajax({
                        url: ajaxurl,
                        type: "POST",
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            if (response.success) {
                                $("#roster-preview").html(response.data.html).show();
                                $("#roster-upload-form").hide();
                            } else {
                                alert("Error: " + response.data.message);
                            }
                        },
                        error: function() {
                            alert("Upload failed. Please try again.");
                        },
                        complete: function() {
                            $("#preview-roster").prop("disabled", false).text("Preview Upload");
                        }
                    });
                });
            });
        ');
    }
    
    public function ajax_roster_preview() {
        check_ajax_referer('spat_roster_preview', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_die(__('Insufficient permissions.', 'sportspress-admin-tools'));
        }
        
        try {
            $preview_data = $this->process_roster_file($_FILES['roster_file'], $_POST['roster_team'], $_POST['roster_season']);
            
            ob_start();
            $this->render_roster_preview($preview_data);
            $html = ob_get_clean();
            
            wp_send_json_success(array('html' => $html, 'data' => $preview_data));
        } catch (Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }
    
    private function process_roster_file($file, $team_id, $season_id) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception(__('File upload failed.', 'sportspress-admin-tools'));
        }
        
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($file_ext, ['csv', 'xlsx'])) {
            throw new Exception(__('Invalid file type. Please upload CSV or XLSX files only.', 'sportspress-admin-tools'));
        }
        
        $upload_dir = wp_upload_dir();
        $temp_file = $upload_dir['path'] . '/' . sanitize_file_name($file['name']);
        
        if (!move_uploaded_file($file['tmp_name'], $temp_file)) {
            throw new Exception(__('Failed to save uploaded file.', 'sportspress-admin-tools'));
        }
        
        $rows = $this->parse_roster_file($temp_file, $file_ext);
        unlink($temp_file);
        
        if (empty($rows)) {
            throw new Exception(__('No valid data found in file.', 'sportspress-admin-tools'));
        }
        
        return $this->analyze_roster_data($rows, $team_id, $season_id);
    }
    
    private function parse_roster_file($file_path, $file_ext) {
        $rows = array();
        
        if ($file_ext === 'csv') {
            if (($handle = fopen($file_path, 'r')) !== FALSE) {
                $header = fgetcsv($handle);
                while (($data = fgetcsv($handle)) !== FALSE) {
                    if (!empty(array_filter($data))) {
                        $rows[] = array_combine($header, $data);
                    }
                }
                fclose($handle);
            }
        } else {
            if (!class_exists('SimpleXLSX')) {
                require_once SPAT_PLUGIN_PATH . 'includes/SimpleXLSX.php';
            }
            
            $xlsx = SimpleXLSX::parse($file_path);
            if ($xlsx) {
                $data = $xlsx->rows();
                if (!empty($data)) {
                    $header = array_shift($data);
                    foreach ($data as $row) {
                        if (!empty(array_filter($row))) {
                            $rows[] = array_combine($header, $row);
                        }
                    }
                }
            }
        }
        
        return $rows;
    }
    
    private function analyze_roster_data($rows, $team_id, $season_id) {
        $analysis = array(
            'rows' => array(),
            'team_id' => $team_id,
            'season_id' => $season_id,
            'stats' => array(
                'total' => 0,
                'found_email' => 0,
                'found_name' => 0,
                'found_number' => 0,
                'create_new' => 0,
                'conflicts' => 0
            )
        );
        
        foreach ($rows as $index => $row) {
            $player_data = $this->normalize_row_data($row);
            
            if (empty($player_data['name'])) {
                continue;
            }
            
            $match_result = $this->match_player($player_data, $team_id, $season_id);
            $conflicts = $this->detect_conflicts($match_result, $team_id, $season_id);
            
            $analysis['rows'][] = array(
                'index' => $index + 1,
                'data' => $player_data,
                'match' => $match_result,
                'conflicts' => $conflicts
            );
            
            $analysis['stats']['total']++;
            $analysis['stats'][$match_result['method']]++;
            
            if (!empty($conflicts)) {
                $analysis['stats']['conflicts']++;
            }
        }
        
        return $analysis;
    }
    
    private function normalize_row_data($row) {
        $data = array();
        
        // Map column headers to standardized keys
        $column_map = array(
            'name' => array('name', 'player_name', 'full_name', 'player'),
            'email' => array('email', 'email_address', 'player_email'),
            'number' => array('number', 'jersey_number', 'squad_number', '#'),
            'position' => array('position', 'pos'),
            'notes' => array('notes', 'comments', 'note')
        );
        
        foreach ($column_map as $key => $possible_headers) {
            foreach ($possible_headers as $header) {
                if (isset($row[$header])) {
                    $data[$key] = trim($row[$header]);
                    break;
                }
            }
        }
        
        return $data;
    }
    
    private function match_player($player_data, $team_id, $season_id) {
        // 1. Email match (highest priority)
        if (!empty($player_data['email'])) {
            $players = get_posts(array(
                'post_type' => 'sp_player',
                'post_status' => 'publish',
                'posts_per_page' => 1,
                'meta_query' => array(
                    array(
                        'key' => 'spat_email',
                        'value' => strtolower($player_data['email']),
                        'compare' => '='
                    )
                )
            ));
            
            if (!empty($players)) {
                return array('player' => $players[0], 'method' => 'found_email');
            }
        }
        
        // 2. Jersey number + team match
        if (!empty($player_data['number'])) {
            $players = get_posts(array(
                'post_type' => 'sp_player',
                'post_status' => 'publish',
                'posts_per_page' => -1,
                'meta_query' => array(
                    array(
                        'key' => 'sp_number',
                        'value' => $player_data['number'],
                        'compare' => '='
                    ),
                    array(
                        'key' => 'sp_current_team',
                        'value' => $team_id,
                        'compare' => '='
                    )
                )
            ));
            
            if (!empty($players)) {
                return array('player' => $players[0], 'method' => 'found_number');
            }
        }
        
        // 3. Name match
        $players = get_posts(array(
            'post_type' => 'sp_player',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            's' => $player_data['name']
        ));
        
        if (count($players) === 1) {
            return array('player' => $players[0], 'method' => 'found_name');
        } elseif (count($players) > 1) {
            return array('players' => $players, 'method' => 'multiple_matches');
        }
        
        // 4. No match - create new
        return array('method' => 'create_new');
    }
    
    private function detect_conflicts($match_result, $team_id, $season_id) {
        if (!isset($match_result['player'])) {
            return array();
        }
        
        $player_id = $match_result['player']->ID;
        $conflicts = array();
        
        // Check if player is on other team lists for same season
        $existing_lists = get_posts(array(
            'post_type' => 'sp_list',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => 'sp_player',
                    'value' => $player_id,
                    'compare' => '='
                )
            ),
            'tax_query' => array(
                array(
                    'taxonomy' => 'sp_season',
                    'field' => 'term_id',
                    'terms' => $season_id
                )
            )
        ));
        
        foreach ($existing_lists as $list) {
            $list_teams = wp_get_object_terms($list->ID, 'sp_team');
            foreach ($list_teams as $list_team) {
                if ($list_team->term_id != $team_id) {
                    $conflicts[] = array(
                        'list_id' => $list->ID,
                        'list_name' => $list->post_title,
                        'team_name' => $list_team->name
                    );
                }
            }
        }
        
        return $conflicts;
    }
    
    private function render_roster_preview($data) {
        echo '<div id="roster-preview-content">';
        echo '<h3>' . __('Roster Upload Preview', 'sportspress-admin-tools') . '</h3>';
        
        $team = get_term($data['team_id'], 'sp_team');
        $season = get_term($data['season_id'], 'sp_season');
        
        echo '<p><strong>' . SPAT_Text_Helper::get_text('Team') . ':</strong> ' . esc_html($team->name) . '</p>';
        echo '<p><strong>' . SPAT_Text_Helper::get_text('Season') . ':</strong> ' . esc_html($season->name) . '</p>';
        
        // Stats summary
        echo '<div class="stats-summary" style="background: #f9f9f9; padding: 10px; margin: 10px 0; border-radius: 4px;">';
        echo '<strong>' . __('Summary:', 'sportspress-admin-tools') . '</strong> ';
        echo sprintf(__('%d total players', 'sportspress-admin-tools'), $data['stats']['total']) . ' | ';
        echo sprintf(__('%d found by email', 'sportspress-admin-tools'), $data['stats']['found_email']) . ' | ';
        echo sprintf(__('%d found by name', 'sportspress-admin-tools'), $data['stats']['found_name']) . ' | ';
        echo sprintf(__('%d found by number', 'sportspress-admin-tools'), $data['stats']['found_number']) . ' | ';
        echo sprintf(__('%d new players', 'sportspress-admin-tools'), $data['stats']['create_new']);
        
        if ($data['stats']['conflicts'] > 0) {
            echo ' | <span style="color: #d63638;">' . sprintf(__('%d conflicts', 'sportspress-admin-tools'), $data['stats']['conflicts']) . '</span>';
        }
        echo '</div>';
        
        // Preview table
        echo '<table class="wp-list-table widefat fixed striped" style="margin: 10px 0;">';
        echo '<thead><tr>';
        echo '<th>' . __('Row', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Name', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Email', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Number', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Status', 'sportspress-admin-tools') . '</th>';
        echo '<th>' . __('Action', 'sportspress-admin-tools') . '</th>';
        echo '</tr></thead><tbody>';
        
        foreach ($data['rows'] as $row) {
            $status_class = $this->get_status_class($row['match']['method']);
            $status_text = $this->get_status_text($row['match']['method']);
            
            echo '<tr>';
            echo '<td>' . $row['index'] . '</td>';
            echo '<td>' . esc_html($row['data']['name']) . '</td>';
            echo '<td>' . esc_html($row['data']['email'] ?? '-') . '</td>';
            echo '<td>' . esc_html($row['data']['number'] ?? '-') . '</td>';
            echo '<td><span class="' . $status_class . '">' . $status_text . '</span></td>';
            echo '<td>';
            
            if (!empty($row['conflicts'])) {
                echo '<span style="color: #d63638;">' . __('Conflict detected', 'sportspress-admin-tools') . '</span>';
            } else {
                echo '<span style="color: #00a32a;">' . __('Ready to process', 'sportspress-admin-tools') . '</span>';
            }
            
            echo '</td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
        
        // Action buttons
        echo '<div class="preview-actions" style="margin: 20px 0;">';
        echo '<button type="button" id="process-roster" class="button button-primary">' . __('Process Roster', 'sportspress-admin-tools') . '</button> ';
        echo '<button type="button" id="cancel-preview" class="button">' . __('Cancel', 'sportspress-admin-tools') . '</button>';
        echo '</div>';
        
        echo '</div>';
        
        // Add CSS styling
        echo '<style>
        .status-found { color: #00a32a; font-weight: bold; }
        .status-new { color: #0073aa; font-weight: bold; }
        .status-multiple { color: #dba617; font-weight: bold; }
        .status-unknown { color: #d63638; font-weight: bold; }
        #roster-preview-content { max-height: 500px; overflow-y: auto; }
        .stats-summary { font-size: 14px; }
        .preview-actions { text-align: center; }
        </style>';
        
        // Add JavaScript for actions
        echo '<script>
        jQuery(document).ready(function($) {
            $("#cancel-preview").click(function() {
                $("#roster-preview").hide();
                $("#roster-upload-form").show();
            });
            
            $("#process-roster").click(function() {
                if (!confirm("' . esc_js(__('This will create/update player records and lists. Continue?', 'sportspress-admin-tools')) . '")) {
                    return;
                }
                
                $(this).prop("disabled", true).text("Processing...");
                
                $.post(ajaxurl, {
                    action: "spat_roster_process",
                    nonce: "' . wp_create_nonce('spat_roster_process') . '",
                    preview_data: ' . json_encode($data) . '
                }, function(response) {
                    if (response.success) {
                        alert("Roster processed successfully! " + response.data.message);
                        location.reload();
                    } else {
                        alert("Error: " + response.data.message);
                        $("#process-roster").prop("disabled", false).text("Process Roster");
                    }
                });
            });
        });
        </script>';
    }
    
    private function get_status_class($method) {
        switch ($method) {
            case 'found_email':
            case 'found_name':
            case 'found_number':
                return 'status-found';
            case 'create_new':
                return 'status-new';
            case 'multiple_matches':
                return 'status-multiple';
            default:
                return 'status-unknown';
        }
    }
    
    private function get_status_text($method) {
        switch ($method) {
            case 'found_email':
                return __('Found by email', 'sportspress-admin-tools');
            case 'found_name':
                return __('Found by name', 'sportspress-admin-tools');
            case 'found_number':
                return __('Found by number', 'sportspress-admin-tools');
            case 'create_new':
                return __('Will create new', 'sportspress-admin-tools');
            case 'multiple_matches':
                return __('Multiple matches', 'sportspress-admin-tools');
            default:
                return __('Unknown', 'sportspress-admin-tools');
        }
    }
    
    public function ajax_roster_process() {
        check_ajax_referer('spat_roster_process', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_die(__('Insufficient permissions.', 'sportspress-admin-tools'));
        }
        
        try {
            $preview_data = json_decode(stripslashes($_POST['preview_data']), true);
            $result = $this->process_roster_data($preview_data);
            
            wp_send_json_success(array(
                'message' => sprintf(__('Processed %d players successfully!', 'sportspress-admin-tools'), $result['processed'])
            ));
        } catch (Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }
    
    private function process_roster_data($data) {
        $processed = 0;
        $team_id = $data['team_id'];
        $season_id = $data['season_id'];
        
        // Get team's league for player assignments
        $team_leagues = wp_get_object_terms($team_id, 'sp_league');
        $league_id = !empty($team_leagues) ? $team_leagues[0]->term_id : null;
        
        // Create or find the player list
        $list_id = $this->create_or_update_player_list($team_id, $season_id);
        
        foreach ($data['rows'] as $row) {
            $player_data = $row['data'];
            $match = $row['match'];
            
            $player_id = null;
            
            if ($match['method'] === 'create_new') {
                $player_id = $this->create_player($player_data);
            } elseif (isset($match['player'])) {
                $player_id = $match['player']->ID;
            }
            
            if ($player_id) {
                $this->update_player_record($player_id, $team_id, $season_id, $league_id, $player_data);
                $this->add_player_to_list($list_id, $player_id);
                $processed++;
            }
        }
        
        return array('processed' => $processed, 'list_id' => $list_id);
    }
    
    private function create_player($player_data) {
        $player_id = wp_insert_post(array(
            'post_type' => 'sp_player',
            'post_title' => $player_data['name'],
            'post_status' => 'publish'
        ));
        
        if ($player_id && !empty($player_data['email'])) {
            update_post_meta($player_id, 'spat_email', strtolower($player_data['email']));
        }
        
        return $player_id;
    }
    
    private function update_player_record($player_id, $team_id, $season_id, $league_id, $player_data) {
        // Update current team
        $current_teams = get_post_meta($player_id, 'sp_current_team', false);
        if (!in_array($team_id, $current_teams)) {
            add_post_meta($player_id, 'sp_current_team', $team_id);
        }
        
        // Update jersey number if provided
        if (!empty($player_data['number'])) {
            update_post_meta($player_id, 'sp_number', $player_data['number']);
        }
        
        // Update email if provided
        if (!empty($player_data['email'])) {
            update_post_meta($player_id, 'spat_email', strtolower($player_data['email']));
        }
        
        // Add taxonomies
        wp_set_object_terms($player_id, array($team_id), 'sp_team', true);
        wp_set_object_terms($player_id, array($season_id), 'sp_season', true);
        
        if ($league_id) {
            wp_set_object_terms($player_id, array($league_id), 'sp_league', true);
            
            // Update sp_leagues meta for statistics
            $leagues_data = get_post_meta($player_id, 'sp_leagues', true);
            if (!is_array($leagues_data)) {
                $leagues_data = array();
            }
            
            if (!isset($leagues_data[$league_id])) {
                $leagues_data[$league_id] = array();
            }
            
            $leagues_data[$league_id][$season_id] = $team_id;
            update_post_meta($player_id, 'sp_leagues', $leagues_data);
            
            // Create sp_assignments
            $assignment = $league_id . '_' . $season_id . '_' . $team_id;
            $existing_assignments = get_post_meta($player_id, 'sp_assignments', false);
            if (!in_array($assignment, $existing_assignments)) {
                add_post_meta($player_id, 'sp_assignments', $assignment);
            }
        }
    }
    
    private function create_or_update_player_list($team_id, $season_id) {
        // Check if list exists for team+season
        $existing_lists = get_posts(array(
            'post_type' => 'sp_list',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'tax_query' => array(
                'relation' => 'AND',
                array(
                    'taxonomy' => 'sp_team',
                    'field' => 'term_id',
                    'terms' => $team_id
                ),
                array(
                    'taxonomy' => 'sp_season',
                    'field' => 'term_id',
                    'terms' => $season_id
                )
            )
        ));
        
        if (!empty($existing_lists)) {
            return $existing_lists[0]->ID;
        }
        
        // Create new list
        $team = get_term($team_id, 'sp_team');
        $season = get_term($season_id, 'sp_season');
        $list_name = $team->name . ' ' . $season->name . ' Roster';
        
        $list_id = wp_insert_post(array(
            'post_type' => 'sp_list',
            'post_title' => $list_name,
            'post_status' => 'publish'
        ));
        
        if ($list_id) {
            wp_set_object_terms($list_id, array($team_id), 'sp_team');
            wp_set_object_terms($list_id, array($season_id), 'sp_season');
            
            // Add team leagues to list
            $team_leagues = wp_get_object_terms($team_id, 'sp_league');
            if (!empty($team_leagues)) {
                wp_set_object_terms($list_id, wp_list_pluck($team_leagues, 'term_id'), 'sp_league');
            }
        }
        
        return $list_id;
    }
    
    private function add_player_to_list($list_id, $player_id) {
        $existing_players = get_post_meta($list_id, 'sp_player', false);
        if (!in_array($player_id, $existing_players)) {
            add_post_meta($list_id, 'sp_player', $player_id);
        }
    }
    
    public function handle_roster_upload() {
        // This method can be used for additional upload handling if needed
    }
}