# SportsPress Admin Tools

Administrative tools for SportsPress WordPress plugin providing automated player registration and e-Transfer payment processing.

## Features

### Player Registration Module
- **Automatic Player Creation**: Creates SportsPress player records from WooCommerce registration orders
- **User Account Linking**: Links WordPress user accounts to player records
- **Season Management**: Automatically assigns players to seasons based on product categories
- **Role Assignment**: Adds "player" role to registered users
- **Manual Sync**: Tools for linking existing players to user accounts
- **Comprehensive Logging**: Tracks all registration activities

### Player Modifications Module
- **Email Metadata**: Add email fields to player records for administrative use
- **Squad Number Editing**: Allow players to update their jersey numbers via WooCommerce account
- **Captain Role Selection**: Designate team captains with "C" indicator on frontend
- **Roster Upload**: Bulk import players from CSV/XLSX files with smart matching and conflict resolution

### e-Transfer Automation Module
- **Webhook Processing**: Automatically processes Interac e-Transfer notifications
- **Multiple Providers**: Supports Generic, deliverhook.com, and Cloudflare Email Routing
- **Smart Order Matching**: Three-tier matching strategy (Order Number → Email → Name)
- **Manual Management**: Interface for handling unmatched payments
- **Notification System**: Menu counter shows pending manual matches
- **Audit Trail**: Complete logging with hide functionality for invalid records
- **Security**: HMAC SHA256 signature verification

## Installation

1. Download the plugin
2. Upload to `/wp-content/plugins/sportspress-admin-tools/`
3. Activate through WordPress admin
4. Configure modules in Settings → SportsPress Admin Tools

## Requirements

- WordPress 5.0+
- SportsPress plugin (for player registration)
- WooCommerce plugin (for both modules)

## Configuration

### Player Registration
1. Go to Settings → SportsPress Admin Tools → Player Registration
2. Configure automatic player creation and role assignment
3. Set up product categories with season format (W2024-25, S2025)
4. Use "player" or "goalie" product tags for position assignment

### e-Transfer Automation
1. Go to Settings → SportsPress Admin Tools → e-Transfer
2. Choose your email service provider
3. Copy the webhook URL to your email forwarding service
4. Configure webhook secret for security
5. Monitor WooCommerce → e-Transfer Webhooks for unmatched payments

## Usage

### Player Registration Workflow
1. Customer completes WooCommerce order for registration product
2. Order status changes to "completed" (triggers player creation)
3. System creates/finds player record with proper case formatting
4. Links user account to player (if not guest checkout)
5. Assigns "player" role and sets email address
6. Logs activity for audit purposes

### Roster Upload Workflow
1. Navigate to any SportsPress List edit page
2. Use "Roster Upload" meta box to select team, season, and CSV/XLSX file
3. Preview upload shows player matching results and potential conflicts
4. System matches players by email, jersey number, or name
5. Creates new player records or updates existing ones
6. Automatically creates or updates player lists with proper team/season assignments

### e-Transfer Processing Workflow
1. Customer sends e-Transfer with order number in message
2. Email forwarding service sends webhook to plugin
3. System extracts payment data and matches to WooCommerce order
4. Order status updates from "on-hold" to "completed"
5. Unmatched payments appear in management interface
6. Admin can manually match payments or hide invalid records

## Support

For issues or questions:
1. Check WordPress debug log for error messages
2. Review activity logs in plugin settings
3. Verify all dependencies are active and updated
4. Test webhook endpoints with provided test scripts

## License

GPL v2 or later
